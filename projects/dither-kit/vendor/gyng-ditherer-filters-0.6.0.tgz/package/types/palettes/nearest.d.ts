import type { PaletteDefinition } from "./types";
declare const defaults: {
    levels: number;
};
declare const nearest: PaletteDefinition<typeof defaults>;
export default nearest;
