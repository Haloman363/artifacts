import type { PaletteDefinition } from "./types";
export declare const THEMES: Record<string, number[][]>;
export declare const THEME_CATEGORIES: Record<string, Array<{
    key: string;
    desc: string;
}>>;
export declare const findMatchingThemeKey: (colors?: number[][] | null) => string | null;
export declare const getThemeDescription: (themeKey: string) => string | null;
declare const defaults: {
    colors: number[][];
    colorDistanceAlgorithm: string;
};
declare const user: PaletteDefinition<typeof defaults>;
export default user;
export declare const createPalette: (colors: number[][]) => {
    name: string;
    getColor: (color: number[], options?: {
        colors: number[][];
        colorDistanceAlgorithm: string;
    } | undefined) => number[];
    defaults?: {
        colors: number[][];
        colorDistanceAlgorithm: string;
    };
    optionTypes?: Record<string, unknown>;
    options: {
        colorDistanceAlgorithm: string;
        colors: number[][];
        defaults: number[][];
    };
};
