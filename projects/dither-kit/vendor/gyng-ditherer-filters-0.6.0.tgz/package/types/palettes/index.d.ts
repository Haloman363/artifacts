import type { PaletteDefinition, PaletteListEntry, SerializedPalette } from "./types";
export { default as nearest } from "./nearest";
export { default as user } from "./user";
export type { PaletteDefinition, PaletteListEntry, SerializedPalette } from "./types";
export declare const paletteList: PaletteListEntry[];
export declare const serializePalette: (palette: PaletteDefinition) => SerializedPalette;
export declare const deserializePalette: (serialized: Partial<SerializedPalette> | null | undefined) => PaletteDefinition;
