type PaletteLike = {
    name?: string;
    options?: Record<string, unknown> & {
        levels?: number;
        colors?: unknown;
    };
    getColor?: {
        bivarianceHack(color: number[], options?: unknown): number[];
    }["bivarianceHack"];
};
export declare const paletteIsIdentity: (palette: PaletteLike | undefined) => boolean;
export declare const buildNearestLUT: (levels: number) => Uint8Array;
export declare const applyPaletteToBuffer: (input: Uint8ClampedArray | Uint8Array, output: Uint8ClampedArray | Uint8Array, _width: number, _height: number, palette: PaletteLike | undefined, wasmAcceleration?: boolean) => void;
export declare const applyPalettePassToCanvas: (canvas: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, palette: PaletteLike | undefined, wasmAcceleration?: boolean) => HTMLCanvasElement | OffscreenCanvas | null;
export declare const applyLinearPalettePassToCanvas: (canvas: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, palette: PaletteLike | undefined) => HTMLCanvasElement | OffscreenCanvas | null;
export declare const PALETTE_NEAREST_GLSL = "\nfloat applyNearestLevels(float v, int levels) {\n  if (levels >= 2 && levels < 256) {\n    float step_v = 255.0 / float(levels - 1);\n    return floor(floor(v / step_v + 0.5) * step_v + 0.5);\n  }\n  return v;\n}\nvec3 applyNearestLevelsRGB(vec3 c, int levels) {\n  return vec3(\n    applyNearestLevels(c.r, levels),\n    applyNearestLevels(c.g, levels),\n    applyNearestLevels(c.b, levels)\n  );\n}\n";
export {};
