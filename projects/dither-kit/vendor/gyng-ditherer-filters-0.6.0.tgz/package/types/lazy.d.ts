import type { FilterDefinition } from "./filters/types";
export declare const lazyFilterNames: readonly string[];
export declare const loadFilter: (name: string) => Promise<FilterDefinition>;
