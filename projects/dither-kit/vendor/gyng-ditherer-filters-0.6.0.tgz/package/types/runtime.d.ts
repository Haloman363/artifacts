import type { FilterCanvas, FilterDefinition, FilterOptionValues } from "./filters/types";
export interface FilterChainEntry {
    id: string;
    filter: string | FilterDefinition;
    displayName?: string;
    options?: FilterOptionValues;
    enabled?: boolean;
}
export interface TemporalFilterState {
    prevOutputs: Map<string, Uint8ClampedArray>;
    prevInputs: Map<string, Uint8ClampedArray>;
    ema: Map<string, Float32Array>;
    frameIndex: number;
}
export interface FilterRuntimeOptions {
    linearize?: boolean;
    wasmAcceleration?: boolean;
    webglAcceleration?: boolean;
    emaAlpha?: number;
    onError?: (error: Error, entry: FilterChainEntry) => void;
}
export interface FilterStepResult {
    id: string;
    name: string;
    filterName: string;
    canvas: FilterCanvas;
    ms: number;
    backend?: string;
    error?: string;
}
export interface ProcessFrameOptions {
    frameIndex?: number;
    isAnimating?: boolean;
    linearize?: boolean;
    wasmAcceleration?: boolean;
    webglAcceleration?: boolean;
    hasVideoInput?: boolean;
    degaussFrame?: number;
    startIndex?: number;
    dispatch?: unknown;
    temporalState?: TemporalFilterState;
    resolveOptions?: (entry: FilterChainEntry, index: number, defaults: FilterOptionValues) => FilterOptionValues | undefined;
    onStep?: (step: FilterStepResult, index: number) => void;
    shouldAbort?: () => boolean;
    /**
     * Keep every step canvas checked out for preview/result consumers. Defaults
     * to true for API compatibility. When false, superseded step canvases are
     * ephemeral and must not be read from `result.steps` after processing.
     */
    retainStepCanvases?: boolean;
}
export interface FilterChainResult {
    canvas: FilterCanvas;
    steps: FilterStepResult[];
    totalTime: number;
    frameIndex: number;
}
export interface FilterSession {
    readonly state: TemporalFilterState;
    getChain(): readonly FilterChainEntry[];
    setChain(chain: readonly FilterChainEntry[]): void;
    process(input: FilterCanvas, options?: ProcessFrameOptions): Promise<FilterChainResult>;
    reset(): void;
    dispose(): void;
}
export declare const runFilterChain: (input: FilterCanvas, chain: readonly FilterChainEntry[], runtime?: FilterRuntimeOptions, frame?: ProcessFrameOptions) => Promise<FilterChainResult>;
export declare const createFilterSession: (initialChain?: readonly FilterChainEntry[], runtime?: FilterRuntimeOptions) => FilterSession;
export declare const disposeSharedFilterResources: () => void;
