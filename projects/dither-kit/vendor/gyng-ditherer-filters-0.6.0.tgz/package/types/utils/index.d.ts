export declare const srgbBufToLinearFloat: (buf: Uint8ClampedArray | Uint8Array) => Float32Array<ArrayBuffer>;
export declare const linearFloatToSrgbBuf: (floats: Float32Array, out: Uint8ClampedArray | Uint8Array) => void;
export declare const linearizeColorF: (c: RgbaLike) => [number, number, number, number];
export declare const delinearizeColorF: (c: RgbaLike) => [number, number, number, number];
export declare const LINEAR_TO_SRGB: Uint8Array<ArrayBuffer>;
export declare const linearizeBuffer: (buf: NumericBuffer) => void;
export declare const delinearizeBuffer: (buf: NumericBuffer) => void;
/** Pixel in sRGB space, channels 0-255. Alias for documentation; use
 *  srgbPaletteGetColor with this type. */
export type SrgbPixel = number[];
/** Pixel in linear-light space, channels 0.0-1.0. Alias for documentation;
 *  use linearPaletteGetColor with this type. */
export type LinearPixel = number[];
type NumericBuffer = {
    [index: number]: number;
    length: number;
};
type RgbaLike = readonly number[];
export declare const srgbPaletteGetColor: (palette: any, pixel: SrgbPixel, options: any) => any;
export declare const linearPaletteGetColor: (palette: any, pixel: LinearPixel, options: any) => LinearPixel;
export declare const paletteGetColor: (palette: any, pixel: RgbaLike, options: any, isLinear: boolean) => any;
export declare const wasmIsLoaded: () => boolean;
export declare const wasmReady: Promise<boolean>;
export declare const initWasmFromBinary: (binary: BufferSource) => Promise<boolean>;
export declare const serializeState: (state: unknown) => string;
/**
 * Create a 2D canvas pre-tagged for frequent readback.
 *
 * Any canvas that gets `getImageData` called on it more than once per frame
 * (the full filter pipeline reads its input canvas every filter, every frame)
 * should be created through this helper. The browser otherwise keeps the
 * backing store on the GPU and pays an expensive readback on each call, and
 * warns about it in the console.
 *
 * NOTE: `willReadFrequently` can only be honoured if it is set on the very
 * first `getContext("2d")` call for a given canvas — retrofitting an existing
 * canvas doesn't work, so prefer this helper at canvas creation time.
 */
export declare const createReadbackCanvas: (width?: number, height?: number) => HTMLCanvasElement;
export declare const getReadbackContext: (canvas: HTMLCanvasElement) => CanvasRenderingContext2D | null;
export declare const luminanceItuBt709: (c: RgbaLike, linear?: boolean) => number;
export declare const luminance: (c: RgbaLike, linear?: boolean) => number;
export declare const quantizeValue: (value: number, levels: number) => number;
export declare const clamp: (min: number, max: number, value: number) => number;
export declare const rgba: (r: number, g: number, b: number, a: number) => [number, number, number, number];
export declare const equalize: (input: NumericBuffer) => void;
export declare const referenceTable: {
    CIE_1931: {
        D65: {
            x: number;
            y: number;
            z: number;
        };
    };
    CIE_1964: {
        D65: {
            x: number;
            y: number;
            z: number;
        };
    };
};
export declare const rgba2hsva: (input: RgbaLike) => number[];
export declare const rgba2laba: (input: RgbaLike, ref?: {
    x: number;
    y: number;
    z: number;
}) => number[];
export declare const rgba2oklaba: (input: RgbaLike) => number[];
export declare const rgba2labaMemo: (input: RgbaLike, ref?: any) => any;
export declare const rgba2hsvaMemo: (input: RgbaLike, ref?: any) => any;
export declare const rgba2oklabaMemo: (input: RgbaLike, ref?: any) => any;
export declare const wasmNearestLabPrecomputed: (pixel: number[], palette: number[][], ref?: {
    x: number;
    y: number;
    z: number;
}) => number;
export declare const wasmQuantizeBufferRgb: (buffer: Uint8ClampedArray | Uint8Array, palette: number[][]) => Uint8Array;
export declare const wasmQuantizeBufferLab: (buffer: Uint8ClampedArray | Uint8Array, palette: number[][], ref?: {
    x: number;
    y: number;
    z: number;
}) => Uint8Array;
export declare const wasmQuantizeBufferRgbApprox: (buffer: Uint8ClampedArray | Uint8Array, palette: number[][]) => Uint8Array;
export declare const wasmQuantizeBufferHsv: (buffer: Uint8ClampedArray | Uint8Array, palette: number[][]) => Uint8Array;
export declare const wasmQuantizeBufferOklab: (buffer: Uint8ClampedArray | Uint8Array, palette: number[][]) => Uint8Array;
export declare const resolvePaletteColorAlgorithm: (palette: unknown) => string | null;
export type FilterWasmStatus = {
    didWasm: boolean;
    reason: string;
    label: string;
};
export declare const subscribeFilterBackends: (listener: () => void) => () => void;
export declare const logFilterWasmStatus: (filterName: string, didWasm: boolean, reason: string) => void;
export declare const logFilterBackend: (filterName: string, backend: string, reason: string) => void;
export declare const logFilterDispatched: (filterName: string, capabilities?: {
    noGL?: string | undefined;
    noWASM?: string | undefined;
}) => void;
export declare const getFilterWasmStatuses: () => Map<string, FilterWasmStatus>;
export declare const getFilterBackends: () => Map<string, Set<string>>;
export declare const resetFilterWasmStatus: (filterName: string) => void;
export declare const WASM_PALETTE_MODE: {
    readonly LEVELS: 0;
    readonly RGB: 1;
    readonly RGB_APPROX: 2;
    readonly HSV: 3;
    readonly LAB: 4;
    readonly OKLAB: 5;
};
export declare const colorAlgorithmToWasmMode: (algo: string | undefined) => number | null;
export declare const wasmErrorDiffuseBuffer: (input: Uint8ClampedArray | Uint8Array, output: Uint8ClampedArray | Uint8Array, width: number, height: number, kernel: Float64Array, kernelWidth: number, kernelHeight: number, offsetX: number, offsetY: number, serpentine: boolean, rowAlt: number, linearize: boolean, prevInput: Uint8ClampedArray | Uint8Array | null, prevOutput: Uint8ClampedArray | Uint8Array | null, temporalBleed: number, paletteMode: number, levels: number, palette: number[][] | null, ref?: {
    x: number;
    y: number;
    z: number;
}) => void;
export declare const wasmErrorDiffuseCustomOrder: (input: Uint8ClampedArray | Uint8Array, output: Uint8ClampedArray | Uint8Array, width: number, height: number, visitOrder: Uint32Array, tuples: Float32Array, kernelStarts: Uint32Array, kernelLens: Uint32Array, kernelTotals: Float32Array, errStrategy: number, linearize: boolean, prevInput: Uint8ClampedArray | Uint8Array | null, prevOutput: Uint8ClampedArray | Uint8Array | null, temporalBleed: number, paletteMode: number, levels: number, palette: number[][] | null, ref?: {
    x: number;
    y: number;
    z: number;
}) => void;
export declare const wasmRiemersmaDither: (input: Uint8ClampedArray | Uint8Array, output: Uint8ClampedArray | Uint8Array, width: number, height: number, memoryLength: number, falloffRatio: number, errorStrength: number, linearize: boolean, paletteMode: number, levels: number, palette: number[][] | null, ref?: {
    x: number;
    y: number;
    z: number;
}) => void;
export declare const WASM_ERR_STRATEGY: {
    readonly RENORMALIZE: 0;
    readonly CLAMPED: 1;
    readonly DROP: 2;
    readonly ROTATE: 3;
    readonly SYMMETRIC: 4;
};
export declare const WASM_ROW_ALT: {
    readonly BOUSTROPHEDON: 0;
    readonly REVERSE: 1;
    readonly BLOCK2: 2;
    readonly BLOCK3: 3;
    readonly BLOCK4: 4;
    readonly BLOCK8: 5;
    readonly TRIANGULAR: 6;
    readonly GRAYCODE: 7;
    readonly BITREVERSE: 8;
    readonly PRIME: 9;
    readonly RANDOM: 10;
};
export declare const wasmApplyChannelLut: (input: Uint8ClampedArray | Uint8Array, output: Uint8ClampedArray | Uint8Array, lutR: Uint8Array, lutG: Uint8Array, lutB: Uint8Array) => void;
export declare const laba2rgba: (input: RgbaLike, ref?: {
    x: number;
    y: number;
    z: number;
}) => number[];
export declare const colorDistance: (a: RgbaLike, b: RgbaLike, colorDistanceAlgorithm: string) => number;
export declare const medianCutPalette: (buf: Uint8ClampedArray | Uint8Array, limit: number, ignoreAlpha: boolean, adaptMode: string, colorMode?: string) => number[][];
export declare const reducePaletteToCap: (colors: number[][], cap: number) => number[][];
export declare const uniqueColors: (buf: Uint8ClampedArray | Uint8Array, limit?: number) => number[][];
export declare const scaleMatrix: (mat: Array<Array<number | null>>, scale: number) => (number | null)[][];
export declare const add: (a: number[], b: number[]) => number[];
export declare const sub: (a: number[], b: number[]) => number[];
export declare const scale: (a: number[], scalar: number, alpha?: boolean) => number[];
export declare const contrast: (color: number[], factor: number) => number[];
export declare const brightness: (color: number[], factor: number, exposure?: number) => number[];
export declare const gamma: (color: number[], g: number) => number[];
export declare const getBufferIndex: (x: number, y: number, width: number) => number;
export declare const fillBufferPixel: (buf: Uint8ClampedArray | Uint8Array | Float32Array | number[], i: number, r: number, g: number, b: number, a: number) => void;
export declare const addBufferPixel: (buf: Uint8ClampedArray | Uint8Array | Float32Array | number[], i: number, color: number[]) => void;
export type CanvasPoolStats = {
    allocations: number;
    reuses: number;
    releases: number;
    pooled: number;
    /** Estimated RGBA backing-store bytes held by idle canvases. */
    pooledBytes: number;
    buckets: number;
};
export declare const getCanvasPoolStats: () => Readonly<CanvasPoolStats>;
export declare const resetCanvasPoolStats: () => void;
/** Release idle backing stores without touching canvases still owned by callers. */
export declare const clearCanvasPool: () => void;
export declare const takePooledCanvas: (w: number, h: number) => HTMLCanvasElement | OffscreenCanvas;
export declare const releasePooledCanvas: (canvas: HTMLCanvasElement | OffscreenCanvas | null | undefined) => void;
export declare const withPooledCanvasCleanup: <T>(canvases: readonly (HTMLCanvasElement | OffscreenCanvas | null | undefined)[], operation: () => T) => T;
export declare const cloneCanvas: (original: HTMLCanvasElement | OffscreenCanvas, copyData?: boolean) => HTMLCanvasElement;
export * from "./sampling";
export * from "./motionVectors";
export * from "./workerFrames";
