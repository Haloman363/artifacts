type PaletteLike = {
    getColor?: unknown;
    options?: unknown;
    [key: string]: unknown;
};
export declare const normalizeRangeOption: (value: unknown, fallback: number, minimum: number, maximum: number, integer?: boolean) => number;
export declare const normalizeBooleanOption: (value: unknown, fallback: boolean) => boolean;
/** Validate a COLOR option to a 3-element 0..255 integer array, else fallback. */
export declare const normalizeColorOption: (value: unknown, fallback: readonly number[]) => number[];
export declare const normalizeEnumOption: <T>(value: unknown, allowed: readonly T[], fallback: T) => T;
export declare const normalizePaletteOption: <T extends PaletteLike>(value: unknown, fallback: T) => T;
export {};
