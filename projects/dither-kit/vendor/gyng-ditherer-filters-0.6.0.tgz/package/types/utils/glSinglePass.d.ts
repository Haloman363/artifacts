import type { FilterCanvas } from "../filters/types";
type UniformSetter = (gl: WebGL2RenderingContext, uniforms: Record<string, WebGLUniformLocation | null>) => void;
type SinglePassOptions = {
    source: FilterCanvas;
    width: number;
    height: number;
    key: string;
    fragmentShader: string;
    uniformNames: readonly string[];
    setUniforms?: UniformSetter;
};
/**
 * Render a source-backed, full-screen WebGL2 filter pass. The helper owns only
 * shared pipeline plumbing; filter modules continue to own shader source,
 * controls, and all effect-specific uniforms.
 */
export declare const renderGLSinglePass: ({ source, width, height, key, fragmentShader, uniformNames, setUniforms, }: SinglePassOptions) => FilterCanvas | null;
export {};
