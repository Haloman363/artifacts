import { type TexEntry } from "../gl/index";
import type { FilterCanvas } from "../filters/types";
export type SdfFieldOptions = {
    gl: WebGL2RenderingContext;
    sourceTexture: TexEntry;
    width: number;
    height: number;
    threshold: number;
    key: string;
};
/** Build an approximate signed-distance feature transform on the GPU. */
export declare const buildSdfField: ({ gl, sourceTexture, width, height, threshold, key, }: SdfFieldOptions) => TexEntry | null;
export declare const SDF_GLSL = "\nfloat sdfMask(sampler2D source, ivec2 p, vec2 res, float threshold) {\n  vec3 c = texelFetch(source, clamp(p, ivec2(0), ivec2(res) - 1), 0).rgb;\n  return dot(c, vec3(0.2126, 0.7152, 0.0722)) >= threshold ? 1.0 : 0.0;\n}\n\nfloat signedDistanceAt(\n  sampler2D field,\n  sampler2D source,\n  ivec2 p,\n  vec2 res,\n  float threshold\n) {\n  ivec2 q = clamp(p, ivec2(0), ivec2(res) - 1);\n  vec4 site = texelFetch(field, q, 0);\n  float distancePx = site.x < 0.0\n    ? max(res.x, res.y)\n    : length((site.rg - (vec2(q) + 0.5) / res) * res);\n  return sdfMask(source, q, res, threshold) > 0.5 ? -distancePx : distancePx;\n}\n";
type UniformSetter = (gl: WebGL2RenderingContext, uniforms: Record<string, WebGLUniformLocation | null>) => void;
type RenderSdfEffectOptions = {
    source: FilterCanvas;
    width: number;
    height: number;
    key: string;
    threshold: number;
    fragmentShader: string;
    uniformNames: readonly string[];
    setUniforms?: UniformSetter;
};
/** Render a full-screen effect backed by the shared boundary feature field. */
export declare const renderSdfEffect: ({ source, width, height, key, threshold, fragmentShader, uniformNames, setUniforms, }: RenderSdfEffectOptions) => FilterCanvas | null;
export {};
