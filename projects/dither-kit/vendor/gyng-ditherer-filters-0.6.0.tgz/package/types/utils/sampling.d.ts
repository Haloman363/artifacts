export declare const sampleNearest: (buf: Uint8ClampedArray | Uint8Array, width: number, height: number, x: number, y: number, out?: number[]) => number[];
export declare const sampleBilinear: (buf: Uint8ClampedArray | Uint8Array, width: number, height: number, x: number, y: number, out?: number[]) => number[];
