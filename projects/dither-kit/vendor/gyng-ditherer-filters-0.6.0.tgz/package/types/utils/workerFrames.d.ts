export type WorkerPrevOutputPayload = ArrayBuffer | {
    imageData: ArrayBuffer;
    width: number;
    height: number;
};
export declare const getWorkerPrevOutputFrame: (payload: WorkerPrevOutputPayload, fallbackWidth: number, fallbackHeight: number) => {
    pixels: Uint8ClampedArray<ArrayBuffer>;
    width: number;
    height: number;
};
