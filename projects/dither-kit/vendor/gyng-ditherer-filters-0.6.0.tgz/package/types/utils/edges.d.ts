/** Compute per-pixel luminance from RGBA buffer */
export declare const computeLuminance: (buf: Uint8ClampedArray, W: number, H: number) => Float32Array;
/** Sobel edge detection — returns magnitude and direction per pixel */
export declare const sobelEdges: (lum: Float32Array, W: number, H: number) => {
    magnitude: Float32Array;
    direction: Float32Array;
};
