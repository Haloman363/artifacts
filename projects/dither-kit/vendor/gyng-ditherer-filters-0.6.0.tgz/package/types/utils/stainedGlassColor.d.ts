export type StainedGlassColorMode = "AVERAGE" | "MEDIAN" | "DOMINANT";
/** Resolve one representative RGBA color per Voronoi cell.
 *
 * Fully transparent RGB is excluded from every statistic. Partial alpha is a
 * statistical weight; the caller still preserves the source pixel's alpha
 * when compositing the representative back into the image.
 */
export declare const resolveStainedGlassCellColors: (cellIds: ArrayLike<number>, pixels: Uint8ClampedArray | Uint8Array, cellCount: number, requestedMode: string) => Uint8Array;
