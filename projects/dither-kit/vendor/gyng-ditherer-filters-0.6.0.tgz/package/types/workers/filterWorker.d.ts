import type { FilterCanvas } from "../filters/types";
import type { WorkerFilterRequest, WorkerFilterResult } from "./types";
type WorkerCanvasLike = FilterCanvas & {
    width: number;
    height: number;
    getContext: (contextId: "2d") => OffscreenCanvasRenderingContext2D | CanvasRenderingContext2D | null;
};
type WorkerCanvasFactory = (width: number, height: number) => WorkerCanvasLike;
export declare const runWorkerFilterRequest: ({ imageData, width, height, chain, frameIndex, isAnimating, linearize, wasmAcceleration, webglAcceleration, convertGrayscale, prevOutputs, prevInputs, emaMaps, degaussFrame, }: WorkerFilterRequest, createCanvas?: WorkerCanvasFactory) => Promise<WorkerFilterResult>;
export {};
