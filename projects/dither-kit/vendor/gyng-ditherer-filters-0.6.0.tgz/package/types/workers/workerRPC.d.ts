import type { WorkerFilterRequest, WorkerFilterResult } from "./types";
export declare const workerRPC: (payload: WorkerFilterRequest, transfer?: Transferable[]) => Promise<WorkerFilterResult>;
export declare const disposeFilterWorker: () => void;
export declare const USE_WORKER: boolean;
