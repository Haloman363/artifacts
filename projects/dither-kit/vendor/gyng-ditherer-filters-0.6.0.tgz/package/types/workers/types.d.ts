export type SerializedOptionMap = Record<string, unknown>;
export interface WorkerChainEntry {
    id: string;
    filterName: string;
    displayName: string;
    options: SerializedOptionMap | undefined;
}
export interface WorkerFilterRequest {
    imageData: ArrayBuffer;
    width: number;
    height: number;
    chain: WorkerChainEntry[];
    frameIndex: number;
    isAnimating: boolean;
    linearize: boolean;
    wasmAcceleration: boolean;
    webglAcceleration: boolean;
    convertGrayscale: boolean;
    prevOutputs: Record<string, ArrayBuffer>;
    prevInputs: Record<string, ArrayBuffer>;
    emaMaps: Record<string, ArrayBuffer>;
    degaussFrame: number;
}
export interface WorkerPrevOutputFrame {
    imageData: ArrayBuffer;
    width: number;
    height: number;
}
export interface WorkerStepTime {
    name: string;
    filterName?: string;
    ms: number;
    backend?: string;
}
export interface WorkerFilterResult {
    imageData: ArrayBuffer;
    width: number;
    height: number;
    stepTimes: WorkerStepTime[];
    prevOutputs: Record<string, WorkerPrevOutputFrame>;
    prevInputs: Record<string, ArrayBuffer>;
    emaMaps: Record<string, ArrayBuffer>;
}
export interface WorkerRequestMessage extends WorkerFilterRequest {
    id: number;
}
export interface WorkerSuccessMessage {
    id: number;
    result: WorkerFilterResult;
}
export interface WorkerErrorMessage {
    id: number;
    error: string;
}
export type WorkerResponseMessage = WorkerSuccessMessage | WorkerErrorMessage;
