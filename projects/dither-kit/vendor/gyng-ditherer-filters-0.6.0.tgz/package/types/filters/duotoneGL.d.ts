export declare const duotoneGLAvailable: () => boolean;
export declare const renderDuotoneGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, shadow: [number, number, number], highlight: [number, number, number], paper: [number, number, number], shadowCurve: number, highlightCurve: number) => HTMLCanvasElement | OffscreenCanvas | null;
