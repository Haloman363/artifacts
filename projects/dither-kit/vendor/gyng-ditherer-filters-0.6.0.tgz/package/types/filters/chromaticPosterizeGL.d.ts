export declare const chromaticPosterizeGLAvailable: () => boolean;
export declare const renderChromaticPosterizeGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, levelsR: number, levelsG: number, levelsB: number) => HTMLCanvasElement | OffscreenCanvas | null;
