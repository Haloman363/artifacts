import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    source: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    renderMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sensitivity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    backgroundColor: {
        type: string;
        default: number[];
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    colorMap: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    accumRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    coolRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    source: string;
    renderMode: string;
    threshold: number;
    sensitivity: number;
    backgroundColor: number[];
    colorMap: string;
    accumRate: number;
    coolRate: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
