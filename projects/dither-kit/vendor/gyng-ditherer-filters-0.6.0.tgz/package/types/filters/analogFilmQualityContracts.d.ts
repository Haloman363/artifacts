/** Display-domain grain excursion derived from density and user amount. */
export declare const filmGrainAmplitude: (luminance: number, amount: number) => number;
/** Four-field sum approximating a bounded Gaussian density fluctuation. */
export declare const filmDensityNoise: (x: number, y: number, seed: number) => number;
/** Stable artifact counts at a reference 640×480 projected frame. */
export declare const projectionArtifactCounts: (width: number, height: number, dustAmount: number, scratchAmount: number, dustJitter?: number, scratchJitter?: number) => {
    dust: number;
    scratches: number;
};
/** Add leak exposure in linear light without hidden channel weighting. */
export declare const linearLightLeakChannel: (sourceSrgb: number, leakSrgb: number, exposure: number) => number;
