export declare const waveGLAvailable: () => boolean;
export declare const renderWaveGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, amplitudeX: number, frequencyX: number, amplitudeY: number, frequencyY: number, phaseX: number, phaseY: number, diagonal: boolean) => HTMLCanvasElement | OffscreenCanvas | null;
