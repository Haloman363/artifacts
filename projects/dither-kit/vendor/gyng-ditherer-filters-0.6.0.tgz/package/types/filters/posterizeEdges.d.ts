export declare const optionTypes: {
    levels: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeThreshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    levels: number;
    edgeThreshold: number;
    edgeWidth: number;
    edgeColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
