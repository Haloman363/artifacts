export declare const optionTypes: {
    scale: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    color1: {
        type: string;
        default: number[];
        desc: string;
    };
    color2: {
        type: string;
        default: number[];
        desc: string;
    };
    mix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    seed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    scale: number;
    color1: number[];
    color2: number[];
    mix: number;
    seed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
