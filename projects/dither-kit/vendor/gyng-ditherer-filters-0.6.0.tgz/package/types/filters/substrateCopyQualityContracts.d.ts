/**
 * Continuous monochrome transfer curve for a repeated xerographic copy.
 * Generation loss suppresses local detail and increases density contrast; it
 * deliberately never quantizes the tone ramp.
 */
export declare const photocopierGenerationTone: (luminance: number, neighborhoodMean: number, contrast: number, generationLoss: number) => number;
/** Cycles at or below 90% of the pixel Nyquist limit. */
export declare const substratePatternFrequency: (scale: number, resolution: number, repeatsPerScale: number) => number;
/** Directionally correlated long-fibre paper variation in the range [-1, 1]. */
export declare const washiFiberVariation: (x: number, y: number) => number;
