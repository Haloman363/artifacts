import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cadenceDrift: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    strength: number;
    threshold: number;
    cadenceDrift: number;
    animSpeed: number;
};
type AbaReboundOptions = FilterOptionValues & typeof defaults & {
    _frameIndex?: number;
};
declare const _default: import("./types").FilterDefinition<AbaReboundOptions>;
export default _default;
