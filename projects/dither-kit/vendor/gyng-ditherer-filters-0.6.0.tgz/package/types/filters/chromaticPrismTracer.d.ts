export declare const optionTypes: {
    centerX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    centerY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    size: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    angle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ior: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dispersion: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    reflections: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    blend: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    centerX: number;
    centerY: number;
    size: number;
    angle: number;
    ior: number;
    dispersion: number;
    reflections: number;
    blend: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
