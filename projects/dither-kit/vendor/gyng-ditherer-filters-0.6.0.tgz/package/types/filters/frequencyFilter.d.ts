import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    radius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bandWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    mode: string;
    radius: number;
    bandWidth: number;
    gain: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
