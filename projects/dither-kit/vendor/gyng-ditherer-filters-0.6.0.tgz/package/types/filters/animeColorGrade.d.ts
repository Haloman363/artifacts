export declare const ANIME_LOOK: {
    readonly BALANCED: "BALANCED";
    readonly CLEAR_DAY: "CLEAR_DAY";
    readonly GOLDEN_HOUR: "GOLDEN_HOUR";
    readonly BLUE_HOUR: "BLUE_HOUR";
    readonly NEON_NIGHT: "NEON_NIGHT";
};
export declare const optionTypes: {
    look: {
        type: string;
        options: ({
            name: string;
            value: "BALANCED";
        } | {
            name: string;
            value: "CLEAR_DAY";
        } | {
            name: string;
            value: "GOLDEN_HOUR";
        } | {
            name: string;
            value: "BLUE_HOUR";
        } | {
            name: string;
            value: "NEON_NIGHT";
        })[];
        default: "CLEAR_DAY";
        desc: string;
    };
    shadowCool: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    highlightWarm: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    blackPoint: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    whitePoint: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    contrast: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    midtoneLift: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    highlightRollOff: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    vibrance: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    chromaDensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    skinProtect: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    mix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    look: "CLEAR_DAY";
    shadowCool: number;
    highlightWarm: number;
    blackPoint: number;
    whitePoint: number;
    contrast: number;
    midtoneLift: number;
    highlightRollOff: number;
    vibrance: number;
    chromaDensity: number;
    skinProtect: number;
    mix: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
