export declare const optionTypes: {
    thresholdMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    radius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    thresholdMode: string;
    threshold: number;
    strength: number;
    radius: number;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
