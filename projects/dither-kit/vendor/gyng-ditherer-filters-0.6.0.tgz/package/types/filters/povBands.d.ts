import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    bands: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    framesPerBand: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    bands: number;
    framesPerBand: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
