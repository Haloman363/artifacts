export declare const optionTypes: {
    depth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    viewAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    viewTilt: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lightAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    specular: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    shadow: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    steps: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    depth: number;
    viewAngle: number;
    viewTilt: number;
    lightAngle: number;
    specular: number;
    shadow: number;
    steps: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
