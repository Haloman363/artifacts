export declare const kuwaharaGLAvailable: () => boolean;
export declare const renderKuwaharaGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, radius: number) => HTMLCanvasElement | OffscreenCanvas | null;
