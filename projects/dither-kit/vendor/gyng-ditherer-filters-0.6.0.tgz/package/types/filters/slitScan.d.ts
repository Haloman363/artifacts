import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    direction: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    depth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    reverse: {
        type: string;
        default: boolean;
        desc: string;
    };
    scanLine: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    direction: string;
    depth: number;
    reverse: boolean;
    scanLine: string;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
