import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    tracking: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    trackingSpread: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flagging: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flaggingHeight: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    verticalJitter: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    chromaDelay: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    headSwitching: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    headSwitchingHeight: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dropout: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    tapeNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ghosting: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    brightness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    saturation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    chromaBandwidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    blur: {
        type: string;
        default: boolean;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    tracking: number;
    trackingSpread: number;
    flagging: number;
    flaggingHeight: number;
    verticalJitter: number;
    chromaDelay: number;
    headSwitching: number;
    headSwitchingHeight: number;
    dropout: number;
    tapeNoise: number;
    ghosting: number;
    brightness: number;
    saturation: number;
    chromaBandwidth: number;
    animSpeed: number;
    blur: boolean;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
export declare const stochasticEventCount: (expected: number, roll: number) => number;
export declare const buildTrackingRowShift: (height: number, tracking: number, trackingSpread: number, frameIndex: number) => Int32Array;
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
