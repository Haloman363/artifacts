import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    noiseAmount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    barHeight: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    barIntensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    verticalHold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ghosting: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ghostDelay: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    color: {
        type: string;
        default: boolean;
        desc: string;
    };
    persistence: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    noiseAmount: number;
    barHeight: number;
    barIntensity: number;
    verticalHold: number;
    ghosting: number;
    ghostDelay: number;
    color: boolean;
    persistence: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
