export declare const metadataMismatchDecodeGLAvailable: () => boolean;
export declare const renderMetadataMismatchDecodeGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, matrixInt: number, rangeInt: number, chromaInt: number, gamma: number, recoveryMix: number) => HTMLCanvasElement | OffscreenCanvas | null;
