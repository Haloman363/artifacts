export declare const optionTypes: {
    density: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    depth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    detail: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    scatter: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lightAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    steps: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    speed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    background: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    density: number;
    depth: number;
    detail: number;
    scatter: number;
    lightAngle: number;
    steps: number;
    speed: number;
    background: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
