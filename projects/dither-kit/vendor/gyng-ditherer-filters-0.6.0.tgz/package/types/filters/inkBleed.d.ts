export declare const optionTypes: {
    spread: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    absorbency: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    paperTint: {
        type: string;
        default: number[];
        desc: string;
    };
    inkColor: {
        type: string;
        default: number[];
        desc: string;
    };
    grain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    fiberAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    anisotropy: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    feather: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    spread: number;
    absorbency: number;
    paperTint: number[];
    inkColor: number[];
    grain: number;
    fiberAngle: number;
    anisotropy: number;
    feather: number;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
