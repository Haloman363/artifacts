export declare const gradientMapGLAvailable: () => boolean;
export declare const renderGradientMapGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, color1: [number, number, number], color2: [number, number, number], color3: [number, number, number], mixAmount: number) => HTMLCanvasElement | OffscreenCanvas | null;
