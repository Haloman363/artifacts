export declare const sepiaGLAvailable: () => boolean;
export declare const renderSepiaGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, intensity: number) => HTMLCanvasElement | OffscreenCanvas | null;
