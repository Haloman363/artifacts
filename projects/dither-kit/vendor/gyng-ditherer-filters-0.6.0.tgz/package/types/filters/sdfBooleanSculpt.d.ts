export declare const optionTypes: {
    operation: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    shape: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    centerX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    centerY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    size: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    aspect: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    angle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    rounding: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    smoothness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sourceMix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    insideColor: {
        type: string;
        default: number[];
        desc: string;
    };
    edgeColor: {
        type: string;
        default: number[];
        desc: string;
    };
    outsideColor: {
        type: string;
        default: number[];
        desc: string;
    };
};
export declare const defaults: { [K in keyof typeof optionTypes]: (typeof optionTypes)[K]["default"]; };
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
