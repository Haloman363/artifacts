type JpegFloatTexture = {
    tex: WebGLTexture;
    fbo: WebGLFramebuffer;
    w: number;
    h: number;
};
export declare const ensureJpegFloatTexture: (gl: WebGL2RenderingContext, name: string, w: number, h: number) => JpegFloatTexture | null;
export declare const releaseJpegFloatTexturesForContext: (gl: WebGL2RenderingContext) => number;
export declare const getJpegFloatTextureCountForContext: (gl: WebGL2RenderingContext) => number;
export declare const releaseJpegArtifactFloatTextures: () => number;
export declare const getJpegArtifactFloatTextureCount: () => number;
export declare const jpegArtifactGLAvailable: () => boolean;
export declare const renderJpegArtifactGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, qualityLumaScale: number, qualityChromaScale: number, subsampling: "444" | "422" | "420", gridJitter: number, corruptBurstChance: number, deblock: number, ringing: number, mosquito: number, frameIndex: number, preserveAlpha: boolean) => HTMLCanvasElement | OffscreenCanvas | null;
export {};
