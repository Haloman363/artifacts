export declare const motionBlurGLAvailable: () => boolean;
export declare const renderMotionBlurGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, angle: number, length: number, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
