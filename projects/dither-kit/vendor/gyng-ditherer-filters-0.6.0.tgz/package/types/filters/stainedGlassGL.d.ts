import { type StainedGlassColorMode } from "../utils/stainedGlassColor";
export declare const stainedGlassGLAvailable: () => boolean;
export declare const renderStainedGlassGL: (source: HTMLCanvasElement | OffscreenCanvas, sourcePixels: Uint8ClampedArray, width: number, height: number, seeds: {
    x: number;
    y: number;
}[], gridCols: number, gridRows: number, cellSize: number, leadingWidth: number, leadingColor: [number, number, number], colorMode: StainedGlassColorMode, mapCellColor: (r: number, g: number, b: number) => readonly number[]) => HTMLCanvasElement | OffscreenCanvas | null;
