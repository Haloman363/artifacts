import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    paletteSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    driftMode: {
        type: string;
        default: string;
        options: {
            name: string;
            value: string;
        }[];
        desc: string;
    };
    driftRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lockLuma: {
        type: string;
        default: boolean;
        desc: string;
    };
    ditherBeforeIndex: {
        type: string;
        default: boolean;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
};
export declare const defaults: {
    paletteSize: number;
    driftMode: string;
    driftRate: number;
    lockLuma: boolean;
    ditherBeforeIndex: boolean;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
