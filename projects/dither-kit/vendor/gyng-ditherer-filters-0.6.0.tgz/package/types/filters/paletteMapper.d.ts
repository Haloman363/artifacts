export declare const optionTypes: {
    bandCount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    hueOffset: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    preserveLuma: {
        type: string;
        default: boolean;
        desc: string;
    };
    saturationBoost: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    bandCount: number;
    hueOffset: number;
    preserveLuma: boolean;
    saturationBoost: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
