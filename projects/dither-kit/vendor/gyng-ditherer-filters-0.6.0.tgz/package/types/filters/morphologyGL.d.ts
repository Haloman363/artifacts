export declare const morphologyGLAvailable: () => boolean;
export type MorphMode = "DILATE" | "ERODE" | "OPEN" | "CLOSE";
export declare const renderMorphologyGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, mode: MorphMode, radius: number) => HTMLCanvasElement | OffscreenCanvas | null;
