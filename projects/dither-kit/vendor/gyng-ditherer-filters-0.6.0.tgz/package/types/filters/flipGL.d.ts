export declare const flipGLAvailable: () => boolean;
export declare const renderFlipGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, flipX: boolean, flipY: boolean) => HTMLCanvasElement | OffscreenCanvas | null;
