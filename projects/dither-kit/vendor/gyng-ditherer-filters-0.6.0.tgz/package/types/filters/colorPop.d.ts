export declare const optionTypes: {
    targetHue: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    hueWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    desaturateOthers: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    softness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    targetHue: number;
    hueWidth: number;
    desaturateOthers: number;
    softness: number;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
