export declare const optionTypes: {
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    length: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    decay: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    direction: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    antiBlooming: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    threshold: number;
    strength: number;
    length: number;
    decay: number;
    direction: string;
    antiBlooming: number;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
