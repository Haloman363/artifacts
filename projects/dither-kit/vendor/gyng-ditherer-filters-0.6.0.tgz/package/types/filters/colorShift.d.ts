export declare const optionTypes: {
    hue: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    saturation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    value: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    hue: number;
    saturation: number;
    value: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
