export type MazeCell = {
    x: number;
    y: number;
};
export declare const traceMazeSolution: (grid: number, seed: number) => MazeCell[];
export declare const optionTypes: {
    grid: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    seed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    journey: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    speed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    wallHeight: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    fog: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    steps: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    torchColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    grid: number;
    seed: number;
    journey: number;
    speed: number;
    wallHeight: number;
    fog: number;
    steps: number;
    torchColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
