export declare const optionTypes: {
    type: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    zoom: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    centerX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    centerY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    iterations: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    juliaR: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    juliaI: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    colorSource: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    type: string;
    zoom: number;
    centerX: number;
    centerY: number;
    iterations: number;
    juliaR: number;
    juliaI: number;
    colorSource: string;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
