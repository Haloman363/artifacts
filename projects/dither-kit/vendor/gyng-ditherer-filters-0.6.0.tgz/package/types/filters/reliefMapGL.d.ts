export declare const reliefMapGLAvailable: () => boolean;
export declare const RELIEF_BASE_MODE_ID: Record<string, number>;
export declare const renderReliefMapGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, lightAngle: number, heightScale: number, specular: number, baseMode: string, tint: [number, number, number], levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
