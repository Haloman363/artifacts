import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    intensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    warp: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    misconvergence: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    hueShimmer: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flash: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    triggerMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    triggerThreshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cooldownFrames: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    duration: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    degauss: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    intensity: number;
    warp: number;
    misconvergence: number;
    hueShimmer: number;
    flash: number;
    triggerMode: string;
    triggerThreshold: number;
    cooldownFrames: number;
    duration: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
