export declare const optionTypes: {
    dotSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        label: string;
        desc: string;
    };
    angleC: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    angleM: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    angleY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    angleK: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    paperColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    dotSize: number;
    angleC: number;
    angleM: number;
    angleY: number;
    angleK: number;
    paperColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
