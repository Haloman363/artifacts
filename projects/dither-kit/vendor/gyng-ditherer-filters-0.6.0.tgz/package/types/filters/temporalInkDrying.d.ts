import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    style: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    inkThreshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dryRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    darkenAmount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeShrink: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    paperBleed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    paperWarmth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
};
export declare const defaults: {
    style: string;
    inkThreshold: number;
    dryRate: number;
    darkenAmount: number;
    edgeShrink: number;
    paperBleed: number;
    paperWarmth: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
