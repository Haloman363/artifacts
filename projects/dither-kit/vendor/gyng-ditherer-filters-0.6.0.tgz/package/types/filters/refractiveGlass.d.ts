export declare const optionTypes: {
    surface: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    refraction: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    relief: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    roughness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dispersion: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    highlight: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    surface: string;
    refraction: number;
    relief: number;
    roughness: number;
    dispersion: number;
    highlight: number;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
