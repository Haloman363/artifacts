export declare const lcdDisplayGLAvailable: () => boolean;
export declare const LCD_LAYOUT_ID: Record<string, number>;
export declare const renderLcdDisplayGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, pixelSize: number, subpixelLayout: string, brightness: number, gapDarkness: number, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
