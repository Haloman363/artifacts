export declare const optionTypes: {
    captureMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    quality: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    sceneMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    pictureEffect: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    lighting: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    flash: {
        type: string;
        default: boolean;
        desc: string;
    };
    flashPower: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flashFalloff: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flashOffsetX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flashOffsetY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    smear: {
        type: string;
        default: boolean;
        desc: string;
    };
    nativeVgaOutput: {
        type: string;
        label: string;
        default: boolean;
        desc: string;
    };
    frameJitter: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
};
export declare const defaults: {
    captureMode: string;
    quality: string;
    sceneMode: string;
    pictureEffect: string;
    lighting: string;
    flash: boolean;
    flashPower: number;
    flashFalloff: number;
    flashOffsetX: number;
    flashOffsetY: number;
    smear: boolean;
    nativeVgaOutput: boolean;
    frameJitter: string;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
