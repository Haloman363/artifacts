export declare const fsKernel: {
    offset: number[];
    kernel: (number | null)[][];
};
export declare const floydSteinberg: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export declare const falseFsKernel: {
    offset: number[];
    kernel: (number | null)[][];
};
export declare const falseFloydSteinberg: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export declare const sierra3kernel: {
    offset: number[];
    kernel: (number | null)[][];
};
export declare const sierra: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export declare const sierra2kernel: {
    offset: number[];
    kernel: (number | null)[][];
};
export declare const sierra2: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export declare const sierraLiteKernel: {
    offset: number[];
    kernel: (number | null)[][];
};
export declare const sierraLite: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export declare const atkinsonKernel: {
    offset: number[];
    kernel: (number | null)[][];
};
export declare const atkinson: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export declare const jarvisKernel: {
    offset: number[];
    kernel: (number | null)[][];
};
export declare const jarvis: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export declare const stuckiKernel: {
    offset: number[];
    kernel: (number | null)[][];
};
export declare const stucki: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export declare const burkesKernel: {
    offset: number[];
    kernel: (number | null)[][];
};
export declare const burkes: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export declare const horizontalStripeKernel: {
    offset: number[];
    kernel: (number | null)[][];
};
export declare const horizontalStripe: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export declare const verticalStripeKernel: {
    offset: number[];
    kernel: (number | null)[][];
};
export declare const verticalStripe: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
