import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sensitivity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    accumulate: {
        type: string;
        default: boolean;
        desc: string;
    };
    decayRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    threshold: number;
    sensitivity: number;
    accumulate: boolean;
    decayRate: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
