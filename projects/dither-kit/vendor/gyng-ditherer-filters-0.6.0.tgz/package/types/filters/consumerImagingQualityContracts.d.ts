/** Map normalized luminance into the 16 optical states of a GC16 waveform. */
export declare const einkReflectanceLevel: (luminance: number, inkBlack: number, paperWhite: number) => number;
/** Four-bit channel quantization: 16³ combinations form a 4096-color cube. */
export declare const kaleidoChannelLevel: (channel: number) => number;
/** Centre sample of the three-monochrome-pixel-wide Kaleido color cell. */
export declare const kaleidoColorCell: (pixel: number) => number;
/** Resolution-independent Gaussian raster-beam transmission. */
export declare const vintageTvRasterGain: (pixelY: number, outputHeight: number, sourceLines: number, strength: number) => number;
/** Add ambient and flash exposure in linear-light reflectance units. */
export declare const flashLinearChannel: (sourceReflectance: number, ambientExposure: number, flashExposure: number, flashTint: number, sensorSaturation: number) => number;
/** Round a centered frame-jitter sample without floor's negative bias. */
export declare const mavicaFrameJitterOffset: (unitSample: number, strength: number, span: number) => number;
