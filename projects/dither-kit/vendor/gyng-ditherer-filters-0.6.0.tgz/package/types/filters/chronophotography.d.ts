import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    exposures: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    interval: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    blendMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    fadeMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    isolateSubject: {
        type: string;
        default: boolean;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    exposures: number;
    interval: number;
    blendMode: string;
    fadeMode: string;
    isolateSubject: boolean;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
