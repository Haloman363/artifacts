export declare const colorHalftoneSeparateGLAvailable: () => boolean;
export declare const renderColorHalftoneSeparateGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, dotSize: number, offsetR: number, offsetG: number, offsetB: number) => HTMLCanvasElement | OffscreenCanvas | null;
