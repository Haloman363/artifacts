export declare const optionTypes: {
    kernel: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    sigma: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    motionLen: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    motionAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    noise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    kernel: string;
    sigma: number;
    motionLen: number;
    motionAngle: number;
    noise: number;
    gain: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
