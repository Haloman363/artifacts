export declare const optionTypes: {
    mode: {
        type: string;
        options: ({
            name: string;
            value: "GRADIENT";
        } | {
            name: string;
            value: "CLOUDS";
        })[];
        default: "CLOUDS";
        desc: string;
    };
    skyStart: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gradientTop: {
        type: string;
        default: number[];
        desc: string;
    };
    gradientBottom: {
        type: string;
        default: number[];
        desc: string;
    };
    cloudAmount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cloudSoftness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cloudScale: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    horizonGlow: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    maskTolerance: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    blend: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    mode: "CLOUDS";
    skyStart: number;
    gradientTop: number[];
    gradientBottom: number[];
    cloudAmount: number;
    cloudSoftness: number;
    cloudScale: number;
    horizonGlow: number;
    maskTolerance: number;
    blend: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
