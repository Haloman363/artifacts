/** Ink coverage at paper position after capillary transfer from a neighbor. */
export declare const inkBleedCoverage: (centerLuminance: number, neighborLuminance: number, absorbency: number, distanceWeight: number) => number;
