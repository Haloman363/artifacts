export declare const optionTypes: {
    aRe: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    aIm: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bRe: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bIm: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cRe: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cIm: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dRe: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dIm: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    aRe: number;
    aIm: number;
    bRe: number;
    bIm: number;
    cRe: number;
    cIm: number;
    dRe: number;
    dIm: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
