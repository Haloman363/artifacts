/** Project a two-dimensional refractive gradient onto the knife-edge normal. */
export declare const knifeEdgeResponse: (gradientX: number, gradientY: number, angleDegrees: number) => number;
/** Goodman contrast law for averaging independent speckle intensity patterns. */
export declare const speckleContrastForDiversity: (modes: number) => number;
/** Unit wave vectors used by the plane-wave quasicrystal construction. */
export declare const quasicrystalDirections: (order: number) => Array<{
    x: number;
    y: number;
}>;
