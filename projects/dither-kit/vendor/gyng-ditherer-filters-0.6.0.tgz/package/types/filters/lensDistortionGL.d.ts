export declare const lensDistortionGLAvailable: () => boolean;
export declare const renderLensDistortionGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, k1: number, k2: number, zoom: number, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
