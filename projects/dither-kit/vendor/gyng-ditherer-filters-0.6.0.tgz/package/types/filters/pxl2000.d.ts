import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    autoIris: {
        type: string;
        default: boolean;
        desc: string;
    };
    exposure: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    contrast: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    signalBandwidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cassetteNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dropout: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    tracking: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
};
export declare const defaults: {
    autoIris: boolean;
    exposure: number;
    contrast: number;
    signalBandwidth: number;
    cassetteNoise: number;
    dropout: number;
    tracking: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
