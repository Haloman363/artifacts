export declare const mezzotintGLAvailable: () => boolean;
export declare const renderMezzotintGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, density: number, dotSize: number, burnish: number, burrStrength: number, plateWear: number, inkColor: [number, number, number], paperColor: [number, number, number]) => HTMLCanvasElement | OffscreenCanvas | null;
