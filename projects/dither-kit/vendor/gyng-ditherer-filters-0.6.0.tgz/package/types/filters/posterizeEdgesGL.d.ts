export declare const posterizeEdgesGLAvailable: () => boolean;
export declare const renderPosterizeEdgesGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, levels: number, edgeThreshold: number, edgeWidth: number, edgeColor: [number, number, number]) => HTMLCanvasElement | OffscreenCanvas | null;
