import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    axis: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    direction: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    readout: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    skew: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    wobble: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    exposureBlend: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    axis: string;
    direction: string;
    readout: number;
    skew: number;
    wobble: number;
    exposureBlend: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
