export declare const oscilloscopeGLAvailable: () => boolean;
export declare const renderOscilloscopeGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, params: {
    display: string;
    phosphorColor: [number, number, number];
    beamWidth: number;
    intensity: number;
    bloom: number;
    bloomStrength: number;
    persistence: number;
    graticule: boolean;
    graticuleDivs: number;
    noiseFloor: number;
    frameIndex: number;
    prevOutput: Uint8ClampedArray | null;
}) => HTMLCanvasElement | OffscreenCanvas | null;
