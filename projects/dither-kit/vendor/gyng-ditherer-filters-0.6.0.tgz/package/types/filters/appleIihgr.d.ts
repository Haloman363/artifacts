import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dither: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    phase: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    monitor: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    colorBleed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    threshold: number;
    dither: number;
    phase: string;
    monitor: string;
    colorBleed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
