import { type FilterOptionValues } from "./types";
export declare const PHOSPHOR_PROFILE: {
    readonly P22_COLOR: "P22_COLOR";
    readonly LONG_PERSISTENCE: "LONG_PERSISTENCE";
    readonly CUSTOM_T10: "CUSTOM_T10";
    readonly LEGACY_FRAME: "LEGACY_FRAME";
};
export declare const optionTypes: {
    profile: {
        type: string;
        options: ({
            name: string;
            value: "P22_COLOR";
        } | {
            name: string;
            value: "LONG_PERSISTENCE";
        } | {
            name: string;
            value: "CUSTOM_T10";
        } | {
            name: string;
            value: "LEGACY_FRAME";
        })[];
        default: "P22_COLOR";
        desc: string;
    };
    refreshRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    redT10Ms: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    greenT10Ms: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    blueT10Ms: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    redDecay: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    greenDecay: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    blueDecay: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
        desc: string;
    };
};
export declare const defaults: {
    profile: "P22_COLOR";
    refreshRate: number;
    redT10Ms: number;
    greenT10Ms: number;
    blueT10Ms: number;
    redDecay: number;
    greenDecay: number;
    blueDecay: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
