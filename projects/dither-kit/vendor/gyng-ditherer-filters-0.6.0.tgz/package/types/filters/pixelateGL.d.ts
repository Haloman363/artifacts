export declare const pixelateGLAvailable: () => boolean;
export declare const renderPixelateGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, downW: number, downH: number) => HTMLCanvasElement | OffscreenCanvas | null;
