import { type FilterOptionValues } from "./types";
export declare const BAYER_2X2 = "BAYER_2X2";
export declare const BAYER_3X3 = "BAYER_3X3";
export declare const BAYER_4X4 = "BAYER_4X4";
export declare const BAYER_8X8 = "BAYER_8X8";
export declare const BAYER_16X16 = "BAYER_16X16";
export declare const SQUARE_5X5 = "SQUARE_5X5";
export declare const CORNER_4X4 = "CORNER_4X4";
export declare const BLOCK_VERTICAL_4X4 = "BLOCK_VERTICAL_4X4";
export declare const BLOCK_HORIZONTAL_4X4 = "BLOCK_HORIZONTAL_4X4";
export declare const HATCH_2X2 = "HATCH_2X2";
export declare const HATCH_3X3 = "HATCH_3X3";
export declare const HATCH_4X4 = "HATCH_4X4";
export declare const ALTERNATE_3X3 = "ALTERNATE_3X3";
export declare const DISPERSED_DOT_3X3 = "DISPERSED_DOT_3X3";
export declare const PATTERN_5X5 = "PATTERN_5X5";
export declare const BLUE_NOISE_16X16 = "BLUE_NOISE_16X16";
export declare const BLUE_NOISE_64X64 = "BLUE_NOISE_64X64";
export declare const WHITE_NOISE_64X64 = "WHITE_NOISE_64X64";
export declare const BAYER_2X2_T = "BAYER_2X2_T";
export declare const BAYER_4X4_T = "BAYER_4X4_T";
export declare const BAYER_8X8_T = "BAYER_8X8_T";
export declare const BAYER_16X16_T = "BAYER_16X16_T";
export declare const THRESHOLD_POLARITY: {
    readonly SHADOW: "SHADOW";
    readonly CLASSIC: "CLASSIC";
};
export declare const getOrderedThresholdMapPreview: (key: string, polarity?: string) => {
    key: string;
    name: string;
    width: number;
    height: number;
    levels: number;
    thresholdMap: number[][];
};
export declare const optionTypes: {
    thresholdMap: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    thresholdPolarity: {
        type: string;
        options: ({
            name: string;
            value: "SHADOW";
        } | {
            name: string;
            value: "CLASSIC";
        })[];
        default: "SHADOW";
        desc: string;
    };
    thresholdPreview: {
        type: string;
        label: string;
        sourceOption: string;
        polarityOption: string;
        desc: string;
    };
    thresholdMapScaleX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    thresholdMapScaleY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    temporalPhases: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
