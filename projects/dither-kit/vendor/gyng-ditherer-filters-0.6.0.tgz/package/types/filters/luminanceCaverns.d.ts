export declare const optionTypes: {
    radius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    relief: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    twist: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    glow: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    steps: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    speed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lightColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    radius: number;
    relief: number;
    twist: number;
    glow: number;
    steps: number;
    speed: number;
    lightColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
