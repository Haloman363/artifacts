export declare const optionTypes: {
    logScale: {
        type: string;
        default: boolean;
        desc: string;
    };
    samples: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    showGrid: {
        type: string;
        default: boolean;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    logScale: boolean;
    samples: number;
    showGrid: boolean;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
