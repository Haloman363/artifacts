export declare const lightLeakGLAvailable: () => boolean;
export declare const renderLightLeakGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, cornerX: number, cornerY: number, color: [number, number, number], intensity: number, maxDist: number) => HTMLCanvasElement | OffscreenCanvas | null;
