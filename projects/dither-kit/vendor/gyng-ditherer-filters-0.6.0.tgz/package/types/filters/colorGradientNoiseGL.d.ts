export declare const colorGradientNoiseGLAvailable: () => boolean;
export declare const renderColorGradientNoiseGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, scale: number, color1: [number, number, number], color2: [number, number, number], mix: number, seed: number) => HTMLCanvasElement | OffscreenCanvas | null;
export declare const __testing: {
    FS: string;
};
