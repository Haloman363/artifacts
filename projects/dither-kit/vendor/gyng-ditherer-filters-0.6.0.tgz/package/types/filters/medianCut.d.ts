/** Build an adaptive palette with an explicit maximum rather than a power-of-two depth. */
export declare const buildMedianCutPalette: (buf: Uint8ClampedArray | Uint8Array, requestedColors: number, requestedAdaptMode: string, requestedColorMode?: string) => number[][];
export declare const optionTypes: {
    levels: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sampleRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    adaptMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    colorMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
};
export declare const defaults: {
    levels: number;
    sampleRate: number;
    adaptMode: string;
    colorMode: string;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
