export declare const liquifyGLAvailable: () => boolean;
export declare const renderLiquifyGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, strength: number, smoothness: number, direction: number, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
