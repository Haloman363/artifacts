export declare const fractalGLAvailable: () => boolean;
export declare const renderFractalGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, typeIsJulia: boolean, colorFromImage: boolean, zoom: number, centreX: number, centreY: number, iterations: number, juliaR: number, juliaI: number) => HTMLCanvasElement | OffscreenCanvas | null;
