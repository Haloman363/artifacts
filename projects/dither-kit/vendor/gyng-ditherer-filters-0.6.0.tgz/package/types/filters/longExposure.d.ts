import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    blendFactor: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: LongExposureOptions) => boolean;
    };
    windowSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: LongExposureOptions) => boolean;
    };
    decay: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: LongExposureOptions) => boolean;
    };
    brightnessThreshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: LongExposureOptions) => boolean;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    mode: string;
    blendFactor: number;
    windowSize: number;
    decay: number;
    brightnessThreshold: number;
    animSpeed: number;
};
type LongExposureOptions = FilterOptionValues & {
    mode?: string;
    blendFactor?: number;
    windowSize?: number;
    decay?: number;
    brightnessThreshold?: number;
    animSpeed?: number;
    _prevOutput?: Uint8ClampedArray | null;
    _frameIndex?: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
