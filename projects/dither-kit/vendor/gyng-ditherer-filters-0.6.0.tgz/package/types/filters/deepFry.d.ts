export declare const optionTypes: {
    contrast: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    saturation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    posterize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    blockiness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    noise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sharpness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    glow: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    chromaShift: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    warmth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    contrast: number;
    saturation: number;
    posterize: number;
    blockiness: number;
    noise: number;
    sharpness: number;
    glow: number;
    chromaShift: number;
    warmth: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
