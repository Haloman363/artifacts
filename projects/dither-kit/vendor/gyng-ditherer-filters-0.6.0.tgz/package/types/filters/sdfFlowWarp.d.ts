export declare const optionTypes: {
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    frequency: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeRange: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    twist: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animateSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: { [K in keyof typeof optionTypes]: (typeof optionTypes)[K]["default"]; };
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
