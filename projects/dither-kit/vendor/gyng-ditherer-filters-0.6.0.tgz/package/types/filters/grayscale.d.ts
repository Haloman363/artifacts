import { type FilterOptionValues } from "./types";
export declare const optionTypes: {};
export declare const defaults: {};
type GrayscaleOptions = FilterOptionValues & {
    _linearize?: boolean;
    _webglAcceleration?: boolean;
};
declare const _default: import("./types").FilterDefinition<GrayscaleOptions>;
export default _default;
