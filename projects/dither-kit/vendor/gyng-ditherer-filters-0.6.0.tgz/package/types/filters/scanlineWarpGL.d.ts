export declare const scanlineWarpGLAvailable: () => boolean;
export declare const renderScanlineWarpGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, amplitude: number, frequency: number, phaseRad: number) => HTMLCanvasElement | OffscreenCanvas | null;
