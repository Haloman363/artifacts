export declare const optionTypes: {
    recursion: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    twist: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    scale: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    glow: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    steps: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    speed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    portalColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    recursion: number;
    twist: number;
    scale: number;
    glow: number;
    steps: number;
    speed: number;
    portalColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
