export declare const matrixRainGLAvailable: () => boolean;
export type MatrixRainGLParams = {
    charBitmaps: Uint8Array[];
    bitmapCellSize: number;
    laneCount: number;
    rows: number;
    charH: number;
    laneInfo: Float32Array;
    cellData: Float32Array;
    sourceInfluence: number;
    classicGreen: boolean;
};
export declare const renderMatrixRainGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, params: MatrixRainGLParams) => HTMLCanvasElement | OffscreenCanvas | null;
