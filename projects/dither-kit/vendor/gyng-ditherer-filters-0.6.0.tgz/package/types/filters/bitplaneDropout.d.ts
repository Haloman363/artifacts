import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    mode: {
        type: string;
        default: string;
        options: {
            name: string;
            value: string;
        }[];
        desc: string;
    };
    targetBits: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    perChannel: {
        type: string;
        default: boolean;
        desc: string;
    };
    burstChance: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    burstLength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    recoverRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    mode: string;
    targetBits: number;
    perChannel: boolean;
    burstChance: number;
    burstLength: number;
    recoverRate: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
