import { type FilterOptionValues } from "./types";
/** Below this the secant law is treated as saturated; keeps yield finite. */
export declare const SEM_COS_EPSILON = 0.02;
/**
 * Fraction of δ₀ that survives on a black pixel. Source luminance stands in for
 * composition contrast (δ₀ really is material dependent), but a pixel of zero
 * luminance is not a material with zero yield, so the modulation has a floor.
 */
export declare const SEM_MATERIAL_FLOOR = 0.06;
/**
 * Secant-law secondary-electron yield: δ(θ) = δ₀ · sec θ = δ₀ / cos θ.
 *
 * `cosTheta` is dot(surfaceNormal, beamDirection) with the beam along +Z, so
 * cos θ = 1 is normal incidence (yield = δ₀) and cos θ → 0 is grazing incidence
 * (yield → ∞ in theory, floored at SEM_COS_EPSILON here so a rim pixel bloomed
 * to its clamp instead of producing Infinity/NaN).
 */
export declare const secondaryElectronYield: (cosTheta: number, delta0: number) => number;
/**
 * Soft-knee saturation of the raw yield, `ceiling · δ / (ceiling + δ)`. Linear
 * (≈ δ) for small yields, asymptotic to `ceiling` as δ → ∞ — the detector and
 * video chain running out of headroom, so edges bloom without blowing up.
 */
export declare const softSaturateYield: (yieldValue: number, ceiling: number) => number;
/**
 * Local δ₀ for a pixel: the material-dependent normal-incidence yield, with the
 * source's linear luminance standing in for composition contrast.
 */
export declare const semLocalBaseYield: (height: number, baseYield: number) => number;
/**
 * Surface normal of the invented heightfield: N = normalize(-dh/dx, -dh/dy,
 * 1/heightScale). `dhdx`/`dhdy` are luminance-per-texel gradients; a larger
 * heightScale exaggerates relief and drives cos θ toward 0 at edges.
 *
 * Note the units: a per-texel central difference of LINEAR luminance is tiny on
 * ordinary imagery (|∇h| ≈ 0.01–0.05, only ~0.4 across a hard sRGB step), so
 * heightScale has to be well above 1 for the surface to tilt at all — at
 * heightScale 1 the steepest ordinary pixel still has cos θ ≈ 0.99 and the
 * secant law is inert. The `relief` control IS this scale (default 24), tuned so
 * stock settings put the steepest 5% of an ordinary frame at sec θ ≈ 2.7.
 */
export declare const surfaceNormalFromHeightGradient: (dhdx: number, dhdy: number, heightScale: number) => [number, number, number];
/**
 * Everhart–Thornley collection efficiency for a normal: dot(N, detectorDir),
 * clamped to the collector-grid floor so faces turned away from the detector
 * stay dim rather than black.
 */
export declare const everhartThornleyResponse: (normal: readonly [number, number, number], azimuthRad: number, elevationRad: number, floorTerm?: number) => number;
export declare const optionTypes: {
    relief: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    baseYield: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    yieldCeiling: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    detectorAzimuth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    detectorElevation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    detectorMix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    scanJitter: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    shotNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    charging: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    tint: {
        type: string;
        default: number[];
        desc: string;
    };
};
export declare const defaults: {
    relief: number;
    baseYield: number;
    yieldCeiling: number;
    detectorAzimuth: number;
    detectorElevation: number;
    detectorMix: number;
    gain: number;
    scanJitter: number;
    shotNoise: number;
    charging: number;
    tint: number[];
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
