export declare const optionTypes: {
    angle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    width: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    intensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    halo: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    color: {
        type: string;
        default: number[];
        desc: string;
    };
    protectHighlights: {
        type: string;
        default: boolean;
        desc: string;
    };
};
export declare const defaults: {
    angle: number;
    width: number;
    threshold: number;
    intensity: number;
    halo: number;
    color: number[];
    protectHighlights: boolean;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
