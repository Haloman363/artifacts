export declare const zigzagGLAvailable: () => boolean;
export declare const renderZigzagGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, lineSpacing: number, amplitude: number, angleRad: number) => HTMLCanvasElement | OffscreenCanvas | null;
