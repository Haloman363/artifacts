export declare const optionTypes: {
    color1: {
        type: string;
        default: number[];
        desc: string;
    };
    color2: {
        type: string;
        default: number[];
        desc: string;
    };
    color3: {
        type: string;
        default: number[];
        desc: string;
    };
    color4: {
        type: string;
        default: number[];
        desc: string;
    };
    layers: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    misregistration: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    grain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    color1: number[];
    color2: number[];
    color3: number[];
    color4: number[];
    layers: number;
    misregistration: number;
    grain: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
