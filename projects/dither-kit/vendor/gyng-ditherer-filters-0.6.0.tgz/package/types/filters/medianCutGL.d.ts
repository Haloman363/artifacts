export declare const MAX_PALETTE = 32;
export declare const medianCutGLAvailable: () => boolean;
export declare const renderMedianCutGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, palette: number[][]) => HTMLCanvasElement | OffscreenCanvas | null;
