export declare const optionTypes: {
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    roughness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    inkColor: {
        type: string;
        default: number[];
        desc: string;
    };
    paperColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    threshold: number;
    roughness: number;
    inkColor: number[];
    paperColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
