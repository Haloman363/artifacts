export declare const optionTypes: {
    thickness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ior: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    roughness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dispersion: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dropletScale: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sourceInfluence: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animateSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    thickness: number;
    ior: number;
    roughness: number;
    dispersion: number;
    dropletScale: number;
    sourceInfluence: number;
    animateSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
