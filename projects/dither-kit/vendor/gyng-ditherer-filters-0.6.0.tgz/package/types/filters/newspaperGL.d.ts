export declare const newspaperGLAvailable: () => boolean;
export declare const renderNewspaperGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, dotSize: number, screenAngle: number, yellowing: number, foldCrease: number, inkSmear: number) => HTMLCanvasElement | OffscreenCanvas | null;
