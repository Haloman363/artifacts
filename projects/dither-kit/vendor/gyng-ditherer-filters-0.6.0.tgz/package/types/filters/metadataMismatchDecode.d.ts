export declare const optionTypes: {
    gammaAssumption: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    matrixAssumption: {
        type: string;
        default: string;
        options: {
            name: string;
            value: string;
        }[];
        desc: string;
    };
    rangeAssumption: {
        type: string;
        default: string;
        options: {
            name: string;
            value: string;
        }[];
        desc: string;
    };
    chromaPlacement: {
        type: string;
        default: string;
        options: {
            name: string;
            value: string;
        }[];
        desc: string;
    };
    recoveryMix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    gammaAssumption: number;
    matrixAssumption: string;
    rangeAssumption: string;
    chromaPlacement: string;
    recoveryMix: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
