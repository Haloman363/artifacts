/** Pure geometry and timing contracts shared by unusual display simulations. */
export declare const bairdScanColumn: (normalizedX: number) => number;
export declare const bairdFrameIndex: (frameIndex: number, previewFps: number) => number;
export declare const cgaCarrierPhase: (pixel: number) => number;
export type PlatoGridCoordinate = {
    inside: boolean;
    x: number;
    y: number;
};
export declare const platoGridCoordinate: (outputX: number, outputY: number, outputWidth: number, outputHeight: number) => PlatoGridCoordinate;
export type DlpSubfieldOffsets = {
    red: {
        x: number;
        y: number;
    };
    green: {
        x: number;
        y: number;
    };
    blue: {
        x: number;
        y: number;
    };
};
export declare const dlpSubfieldOffsets: (motionX: number, motionY: number, colorCycles: number) => DlpSubfieldOffsets;
