export declare const optionTypes: {
    lightX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lightY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    density: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    decay: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    exposure: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    noise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animateSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    tint: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    lightX: number;
    lightY: number;
    density: number;
    decay: number;
    exposure: number;
    threshold: number;
    noise: number;
    animateSpeed: number;
    tint: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
