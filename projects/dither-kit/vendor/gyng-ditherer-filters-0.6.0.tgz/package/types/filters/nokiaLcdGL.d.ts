export declare const nokiaLcdGLAvailable: () => boolean;
export declare const renderNokiaLcdGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, columns: number, rows: number, threshold: number, contrast: number, ditherStrength: number, pixelGrid: boolean) => HTMLCanvasElement | OffscreenCanvas | null;
