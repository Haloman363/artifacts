export declare const atmosphericHazeGLAvailable: () => boolean;
export declare const renderAtmosphericHazeGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, strength: number, horizon: number, softness: number, highlightBloom: number, tint: [number, number, number], depthMode: 0 | 1 | 2) => HTMLCanvasElement | OffscreenCanvas | null;
