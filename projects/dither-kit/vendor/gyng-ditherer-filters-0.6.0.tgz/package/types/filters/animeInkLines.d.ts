export declare const optionTypes: {
    source: {
        type: string;
        options: ({
            name: string;
            value: "XDOG";
        } | {
            name: string;
            value: "SOBEL";
        } | {
            name: string;
            value: "LAPLACIAN";
        })[];
        default: "XDOG";
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sigma: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    scaleRatio: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lineSoftness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    textureSuppression: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lineWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lineColor: {
        type: string;
        default: number[];
        desc: string;
    };
    renderMode: {
        type: string;
        options: ({
            name: string;
            value: "OVERLAY";
        } | {
            name: string;
            value: "SOLID";
        })[];
        default: "OVERLAY";
        desc: string;
    };
    overlayMix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bgColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    source: "XDOG";
    threshold: number;
    sigma: number;
    scaleRatio: number;
    lineSoftness: number;
    textureSuppression: number;
    lineWidth: number;
    lineColor: number[];
    renderMode: "OVERLAY";
    overlayMix: number;
    bgColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
