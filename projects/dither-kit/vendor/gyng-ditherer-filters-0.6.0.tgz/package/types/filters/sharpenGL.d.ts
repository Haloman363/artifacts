export declare const sharpenGLAvailable: () => boolean;
export declare const renderSharpenGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, strength: number, radius: number, threshold: number, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
