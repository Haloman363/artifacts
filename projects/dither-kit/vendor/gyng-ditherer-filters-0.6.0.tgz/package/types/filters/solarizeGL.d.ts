export declare const solarizeGLAvailable: () => boolean;
export declare const renderSolarizeGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, reversal: number, strength: number) => HTMLCanvasElement | OffscreenCanvas | null;
