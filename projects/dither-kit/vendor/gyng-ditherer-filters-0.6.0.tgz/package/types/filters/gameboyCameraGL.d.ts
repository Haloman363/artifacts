export declare const gameboyCameraGLAvailable: () => boolean;
export declare const renderGameboyCameraGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, downW: number, downH: number, options: {
    contrast: number;
    exposure: number;
    gain: number;
    bias: number;
    invert: number;
    edgeMode: number;
    edgeEnhance: number;
    kernelP: number;
    kernelM: number;
    kernelX: number;
    sensorNoise: number;
    randomSeed: number;
    frame: number;
    ditherStrength: number;
}) => HTMLCanvasElement | OffscreenCanvas | null;
