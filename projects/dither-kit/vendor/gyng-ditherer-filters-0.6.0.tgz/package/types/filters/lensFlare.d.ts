export declare const optionTypes: {
    positionX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    positionY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    intensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bloomRadius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flareColor: {
        type: string;
        default: number[];
        desc: string;
    };
    ghosts: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ghostSpread: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    streakStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    chromaticSpread: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    positionX: number;
    positionY: number;
    intensity: number;
    bloomRadius: number;
    flareColor: number[];
    ghosts: number;
    ghostSpread: number;
    streakStrength: number;
    chromaticSpread: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
type Point = readonly [number, number];
export declare const lensFlareGhostPosition: (source: Point, imageCenter: Point, index: number, count: number, spread: number) => [number, number];
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
