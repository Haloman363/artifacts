import type { VHSNTSCGLParams } from "./vhsNtscGL";
export declare const vhsNtscUsingFloatPath: () => boolean;
export declare const vhsNtscFloatStatus: () => string;
export declare const markVHSNTSCFloatFailure: (reason: string) => void;
export declare const renderVHSNTSCConformanceGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, params: VHSNTSCGLParams) => HTMLCanvasElement | OffscreenCanvas | null;
