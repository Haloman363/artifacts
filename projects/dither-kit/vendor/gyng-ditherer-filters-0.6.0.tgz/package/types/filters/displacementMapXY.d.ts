export declare const optionTypes: {
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    blurRadius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    channelX: {
        type: string;
        options: {
            name: string;
            value: number;
        }[];
        default: number;
        desc: string;
    };
    channelY: {
        type: string;
        options: {
            name: string;
            value: number;
        }[];
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    strength: number;
    blurRadius: number;
    channelX: number;
    channelY: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
