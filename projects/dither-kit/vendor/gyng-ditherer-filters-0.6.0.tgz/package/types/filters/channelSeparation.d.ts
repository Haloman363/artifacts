export declare const optionTypes: {
    rOffsetX: {
        type: string;
        range: number[];
        default: number;
        desc: string;
    };
    rOffsetY: {
        type: string;
        range: number[];
        default: number;
        desc: string;
    };
    rOpacity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gOffsetX: {
        type: string;
        range: number[];
        default: number;
        desc: string;
    };
    gOffsetY: {
        type: string;
        range: number[];
        default: number;
        desc: string;
    };
    gOpacity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bOffsetX: {
        type: string;
        range: number[];
        default: number;
        desc: string;
    };
    bOffsetY: {
        type: string;
        range: number[];
        default: number;
        desc: string;
    };
    bOpacity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    aOffsetX: {
        type: string;
        range: number[];
        default: number;
        desc: string;
    };
    aOffsetY: {
        type: string;
        range: number[];
        default: number;
        desc: string;
    };
    aOpacity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    rOffsetX: number;
    rOffsetY: number;
    rOpacity: number;
    gOffsetX: number;
    gOffsetY: number;
    gOpacity: number;
    bOffsetX: number;
    bOffsetY: number;
    bOpacity: number;
    aOffsetX: number;
    aOffsetY: number;
    aOpacity: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
