export declare const stippleGLAvailable: () => boolean;
export declare const renderStippleGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, density: number, maxDotSize: number, inkColor: number[], paperColor: number[]) => HTMLCanvasElement | OffscreenCanvas | null;
