export declare const CRT_PROFILE: {
    readonly CONSUMER_525: "CONSUMER_525";
    readonly CONSUMER_625: "CONSUMER_625";
    readonly ARCADE_240P: "ARCADE_240P";
    readonly APERTURE_GRILLE: "APERTURE_GRILLE";
    readonly BROADCAST: "BROADCAST";
    readonly CUSTOM: "CUSTOM";
};
export type CrtProfile = (typeof CRT_PROFILE)[keyof typeof CRT_PROFILE];
export type CrtProfileDefaults = {
    visibleScanlines: number;
    interlaced: boolean;
    mask: "VERTICAL" | "STAGGERED" | "LADDER" | "TILED" | "HEX_GAP";
    overscan: number;
    curvature: number;
    beamMinSigma: number;
    beamMaxSigma: number;
    cornerFocus: number;
    damperWires: number;
    phosphorT10Ms: {
        red: number;
        green: number;
        blue: number;
    };
};
export declare const crtProfileDefaults: (profile: unknown) => CrtProfileDefaults;
export declare const resolveVisibleScanlines: (profile: unknown, customLines: number, outputHeight: number) => number;
/** Apply a tube profile baseline while preserving a control the user changed. */
export declare const resolveCrtProfileSetting: (value: number, controlDefault: number, profileDefault: number) => number;
export declare const crtBeamSigma: (luminance: number, normalizedRadius: number, minimum: number, maximum: number, cornerFocus: number) => number;
export declare const crtSignalToSrgb: (signal: number, gamma: number) => number;
/** Retained light after one frame when t10 is the measured decay-to-10% time. */
export declare const decayRetentionFromT10: (t10Ms: number, refreshRate: number) => number;
