export declare const foliageSimplifierGLAvailable: () => boolean;
export declare const renderFoliageSimplifierGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, radius: number, regionMerge: number, edgePreserve: number, brushiness: number, shadowRetention: number, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
