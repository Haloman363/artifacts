import { type FilterOptionValues } from "./types";
/**
 * Range floor, as a fraction of the display radius, below which `1/R⁴` is held
 * constant. This is divergence control, nothing more: without it the origin
 * would be infinitely bright. Note that it clamps the return to its maximum, so
 * `r < RADAR_MIN_RANGE` is the BRIGHTEST region of the scope — it does not
 * model transmit-pulse blanking, which would darken the origin instead. Both
 * the kernel and the shader floor at this value.
 */
export declare const RADAR_MIN_RANGE = 0.04;
/**
 * Calibration range: the normalized range at which the receiver chain has unity
 * gain. Attenuation is reported relative to here so the picture is not either
 * all-white at the origin or all-black at the rim.
 */
export declare const RADAR_REF_RANGE = 0.25;
/**
 * Radar-equation range falloff: received power Pr ∝ 1/R⁴.
 *
 * `r` is normalized slant range (1 = scope rim). Floored at `minRange` so the
 * blanked near field is finite. Strictly decreasing above the floor, and
 * doubling the range divides the return by 16.
 */
export declare const rangeAttenuation: (r: number, minRange?: number) => number;
/**
 * STC (sensitivity time control): receiver gain ramped as R^(4·stc) with range.
 * `stc` = 0 is raw video, `stc` = 1 exactly cancels the 1/R⁴ falloff.
 */
export declare const stcGain: (r: number, stc: number, minRange?: number) => number;
/**
 * Phosphor persistence: B = B₀·exp(−Δφ/τ), with Δφ the sweep angle elapsed
 * since the beam last painted this cell and τ the persistence constant (same
 * angular units as Δφ — radians throughout this module).
 */
export declare const persistenceDecay: (deltaPhi: number, tau: number) => number;
/**
 * Mean of `persistenceDecay` over a full revolution: (τ/2π)·(1 − exp(−2π/τ)).
 *
 * This is what a cell that subtends EVERY bearing at once settles at, which is
 * the case at the scope origin — angular resolution collapses there, so the
 * bearing-dependent terms are faded into this value rather than sampling a
 * bearing that does not exist.
 */
export declare const meanPersistence: (tau: number) => number;
/**
 * Sweep angle elapsed since the beam last crossed `bearing`, wrapped into
 * [0, 2π). A cell just *behind* the sweep returns a small angle (bright); a
 * cell just *ahead* of it has to wait almost a full revolution, so it returns
 * nearly 2π (dim). This wrap is what makes the trail follow the sweep.
 */
export declare const sweepElapsedAngle: (bearing: number, sweep: number) => number;
/** Antenna bearing φ(t) = ω·t at a given frame, wrapped into [0, 2π). */
export declare const sweepBearing: (frameIndex: number, degreesPerFrame: number) => number;
/** GLSL mirror of the kernels above — the shader and the tests must agree. */
export declare const RADAR_PPI_GLSL = "\nconst float RP_TWO_PI = 6.28318530717958648;\nfloat rp_rangeAttenuation(float r, float minRange) {\n  float rr = max(max(r, 0.0), max(minRange, 1e-6));\n  float r2 = rr * rr;\n  return 1.0 / max(r2 * r2, 1e-30);\n}\nfloat rp_stcGain(float r, float stc, float minRange) {\n  float rr = max(max(r, 0.0), max(minRange, 1e-6));\n  return pow(rr, 4.0 * clamp(stc, 0.0, 1.0));\n}\nfloat rp_persistence(float dPhi, float tau) {\n  return exp(-max(dPhi, 0.0) / max(tau, 1e-4));\n}\nfloat rp_meanPersistence(float tau) {\n  float t = max(tau, 1e-4);\n  return t * (1.0 - exp(-RP_TWO_PI / t)) / RP_TWO_PI;\n}\nfloat rp_elapsed(float bearing, float sweep) {\n  float d = sweep - bearing;\n  float w = d - RP_TWO_PI * floor(d / RP_TWO_PI);\n  // Keep the result strictly in [0, 2pi): for a tiny negative d the subtraction\n  // rounds up to exactly 2pi.\n  if (w >= RP_TWO_PI) w -= RP_TWO_PI;\n  return max(w, 0.0);\n}\n";
declare const CLUTTER: {
    readonly NONE: "NONE";
    readonly SEA: "SEA";
    readonly RAIN: "RAIN";
    readonly BOTH: "BOTH";
};
type ClutterMode = (typeof CLUTTER)[keyof typeof CLUTTER];
export declare const optionTypes: {
    gain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    stc: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sweepSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    persistence: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    beamWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    clutterMode: {
        type: string;
        options: ({
            name: string;
            value: "NONE";
        } | {
            name: string;
            value: "SEA";
        } | {
            name: string;
            value: "RAIN";
        } | {
            name: string;
            value: "BOTH";
        })[];
        default: "SEA";
        desc: string;
    };
    clutter: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    clutterRange: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    clutterBoil: {
        type: string;
        default: boolean;
        desc: string;
    };
    rings: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    spokes: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    graticule: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    scopeScale: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    phosphor: {
        type: string;
        default: number[];
        desc: string;
    };
    background: {
        type: string;
        default: number[];
        desc: string;
    };
};
export declare const defaults: {
    gain: number;
    stc: number;
    sweepSpeed: number;
    persistence: number;
    beamWidth: number;
    clutterMode: ClutterMode;
    clutter: number;
    clutterRange: number;
    clutterBoil: boolean;
    rings: number;
    spokes: number;
    graticule: number;
    scopeScale: number;
    phosphor: number[];
    background: number[];
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
