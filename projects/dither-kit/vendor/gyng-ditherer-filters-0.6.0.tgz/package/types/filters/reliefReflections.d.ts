export declare const optionTypes: {
    depth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    reflectivity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    roughness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    distance: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    steps: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    skyTop: {
        type: string;
        default: number[];
        desc: string;
    };
    skyBottom: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    depth: number;
    reflectivity: number;
    roughness: number;
    distance: number;
    steps: number;
    skyTop: number[];
    skyBottom: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
