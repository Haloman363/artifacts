export declare const displacementMapXYGLAvailable: () => boolean;
export declare const renderDisplacementMapXYGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, strength: number, blurRadius: number, channelX: 0 | 1 | 2, channelY: 0 | 1 | 2) => HTMLCanvasElement | OffscreenCanvas | null;
