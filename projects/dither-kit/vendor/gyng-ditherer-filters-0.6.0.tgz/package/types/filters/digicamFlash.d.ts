export declare const optionTypes: {
    flashPower: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    falloff: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    centerX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    centerY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ambient: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeBurn: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    whiteClip: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    warmth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    flashPower: number;
    falloff: number;
    centerX: number;
    centerY: number;
    ambient: number;
    edgeBurn: number;
    whiteClip: number;
    warmth: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
