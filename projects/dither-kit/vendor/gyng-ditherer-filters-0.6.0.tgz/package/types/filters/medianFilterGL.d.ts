export declare const medianFilterGLAvailable: () => boolean;
export declare const renderMedianFilterGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, radius: number) => HTMLCanvasElement | OffscreenCanvas | null;
