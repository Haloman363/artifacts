export declare const scanlineGLAvailable: () => boolean;
export declare const SCANLINE_MODE_ID: Record<string, number>;
export declare const renderScanlineGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, mode: string, visibleScanlines: number, beamMinWidth: number, beamMaxWidth: number, beamStrength: number, intensity: number, gap: number, hgt: number, lineHeight: number, brightness: number, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
