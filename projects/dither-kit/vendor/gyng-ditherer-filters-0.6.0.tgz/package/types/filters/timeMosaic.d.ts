import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    behavior: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    tileSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    maxDelay: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    pattern: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
        visibleWhen: (options: TimeMosaicOptions) => boolean;
    };
    motionThreshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: TimeMosaicOptions) => boolean;
    };
    holdFrames: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: TimeMosaicOptions) => boolean;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    behavior: string;
    tileSize: number;
    maxDelay: number;
    pattern: string;
    motionThreshold: number;
    holdFrames: number;
    animSpeed: number;
};
type TimeMosaicOptions = FilterOptionValues & {
    behavior?: string;
    tileSize?: number;
    maxDelay?: number;
    pattern?: string;
    motionThreshold?: number;
    holdFrames?: number;
    animSpeed?: number;
    _prevInput?: Uint8ClampedArray | null;
    _frameIndex?: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
