import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    zoom: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    rotation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    offsetX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    offsetY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    mix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    colorShift: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    zoom: number;
    rotation: number;
    offsetX: number;
    offsetY: number;
    mix: number;
    colorShift: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
