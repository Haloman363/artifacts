import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    columns: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    standardPage: {
        type: string;
        default: boolean;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    blockGap: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bitErrorRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    burstErrors: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    concealment: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    randomSeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    columns: number;
    standardPage: boolean;
    threshold: number;
    blockGap: number;
    bitErrorRate: number;
    burstErrors: number;
    concealment: string;
    randomSeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
export interface TeletextGeometry {
    columns: number;
    rows: number;
    cellW: number;
    cellH: number;
    blockW: number;
    blockH: number;
    standardPage: boolean;
}
export declare const resolveTeletextGeometry: (width: unknown, height: unknown, options: {
    columns?: unknown;
    standardPage?: unknown;
}) => TeletextGeometry;
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
