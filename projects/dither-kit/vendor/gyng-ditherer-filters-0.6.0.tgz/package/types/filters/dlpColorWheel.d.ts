import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    wheel: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    colorCycles: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    motionX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    motionY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    breakup: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bitplaneSparkle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lensSoftness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
};
export declare const defaults: {
    wheel: string;
    colorCycles: number;
    motionX: number;
    motionY: number;
    breakup: number;
    bitplaneSparkle: number;
    lensSoftness: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
