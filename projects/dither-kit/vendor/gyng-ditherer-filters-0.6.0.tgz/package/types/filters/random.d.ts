import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    grayscale: {
        type: string;
        default: boolean;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    grayscale: boolean;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
type RandomOptions = FilterOptionValues & typeof defaults & {
    _linearize?: boolean;
    _webglAcceleration?: boolean;
};
declare const _default: import("./types").FilterDefinition<RandomOptions>;
export default _default;
