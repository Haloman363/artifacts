import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    blockSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    motionThreshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    displacement: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    keyframeInterval: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    corruptChance: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    channelShift: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    blockSize: number;
    motionThreshold: number;
    displacement: number;
    keyframeInterval: number;
    corruptChance: number;
    channelShift: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
