export declare const optionTypes: {
    symmetry: {
        type: string;
        options: ({
            name: string;
            value: 5;
        } | {
            name: string;
            value: 7;
        } | {
            name: string;
            value: 8;
        } | {
            name: string;
            value: 10;
        })[];
        default: 8;
        desc: string;
    };
    scale: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    rotation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sourceInfluence: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    facets: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bevel: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sourceMix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    low: {
        type: string;
        default: number[];
        desc: string;
    };
    mid: {
        type: string;
        default: number[];
        desc: string;
    };
    high: {
        type: string;
        default: number[];
        desc: string;
    };
};
export declare const defaults: {
    symmetry: 8;
    scale: number;
    rotation: number;
    sourceInfluence: number;
    facets: number;
    bevel: number;
    sourceMix: number;
    low: number[];
    mid: number[];
    high: number[];
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
