export declare const anaglyphDisparity: (depth: number, maximumDisparity: number, convergence: number) => number;
type LinearRgb = readonly [number, number, number];
/** Dubois least-squares red/cyan projection, before display-range clipping. */
export declare const duboisRedCyanLinear: (left: LinearRgb, right: LinearRgb) => [number, number, number];
/** Returns R=0, G=1, or B=2 for a Bayer photosite. */
export declare const bayerColorAt: (cfa: string, x: number, y: number) => number;
export declare const bayerNoiseSigma: (signal: number, shotNoiseAtWhite: number, readNoise: number) => number;
export declare const moireBeatFrequency: (sourcePitch: number, samplePitch: number, relativeAngleDegrees: number) => number;
export declare const processScreenAngle: (channel: string) => number;
export {};
