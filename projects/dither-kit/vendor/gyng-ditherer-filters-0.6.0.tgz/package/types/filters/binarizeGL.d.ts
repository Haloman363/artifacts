export declare const binarizeGLAvailable: () => boolean;
export declare const renderBinarizeGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, thresholdR: number, thresholdG: number, thresholdB: number, thresholdA: number, linearize: boolean) => HTMLCanvasElement | OffscreenCanvas | null;
