export declare const optionTypes: {
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    horizon: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    softness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    highlightBloom: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    tint: {
        type: string;
        default: number[];
        desc: string;
    };
    depthMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    strength: number;
    horizon: number;
    softness: number;
    highlightBloom: number;
    tint: number[];
    depthMode: string;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
