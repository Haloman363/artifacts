export declare const optionTypes: {
    fanAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    speckle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    brightness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    scanLines: {
        type: string;
        default: boolean;
        desc: string;
    };
    markers: {
        type: string;
        default: boolean;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    fanAngle: number;
    speckle: number;
    brightness: number;
    scanLines: boolean;
    markers: boolean;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
