export declare const optionTypes: {
    variation: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    amount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    zoom: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    rotate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    taps: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    tint: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    variation: string;
    amount: number;
    zoom: number;
    rotate: number;
    taps: number;
    tint: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
