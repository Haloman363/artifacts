export declare const optionTypes: {
    bands: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    colormap: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    lineColor: {
        type: string;
        default: number[];
        desc: string;
    };
    lineWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lineOpacity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    bands: number;
    colormap: string;
    lineColor: number[];
    lineWidth: number;
    lineOpacity: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
