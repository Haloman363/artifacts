export declare const optionTypes: {
    system: {
        type: string;
        options: ({
            name: string;
            value: "NTSC";
        } | {
            name: string;
            value: "PAL";
        })[];
        default: "NTSC";
        desc: string;
    };
    banding: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    colorFringe: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    chromaBandwidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    tuningError: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    verticalRoll: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    scanlineStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    glow: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    rfNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    system: "NTSC";
    banding: number;
    colorFringe: number;
    chromaBandwidth: number;
    tuningError: number;
    verticalRoll: number;
    scanlineStrength: number;
    glow: number;
    rfNoise: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
