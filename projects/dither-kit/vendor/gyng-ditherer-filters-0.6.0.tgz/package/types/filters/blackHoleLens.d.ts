export declare const optionTypes: {
    centerX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    centerY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    mass: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    horizon: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    discRadius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    discWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    spin: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    exposure: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    discTint: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    centerX: number;
    centerY: number;
    mass: number;
    horizon: number;
    discRadius: number;
    discWidth: number;
    spin: number;
    exposure: number;
    discTint: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
