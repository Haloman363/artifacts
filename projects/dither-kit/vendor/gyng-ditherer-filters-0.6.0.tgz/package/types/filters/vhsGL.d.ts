export declare const vhsGLAvailable: () => boolean;
export type VHSGLParams = {
    rowShift: Int32Array;
    rowNoise: Float32Array;
    staticBar: Uint8Array;
    dropoutPacked: Float32Array;
    vJitter: number;
    chromaOffX: number;
    chromaOffY: number;
    chromaBandwidth: number;
    saturation: number;
    brightness: number;
    ghosting: number;
    tapeNoise: number;
    frameIndex: number;
    prevOutput: Uint8ClampedArray | null;
    doBlur: boolean;
};
export declare const renderVHSGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, params: VHSGLParams) => HTMLCanvasElement | OffscreenCanvas | null;
