import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
declare const defaults: {
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
type QuantizePaletteOptions = {
    levels?: number;
    colorDistanceAlgorithm?: string;
    colors?: number[][];
};
type QuantizeOptions = FilterOptionValues & typeof defaults & {
    _linearize?: boolean;
    palette?: typeof defaults.palette & {
        options?: QuantizePaletteOptions;
    };
};
declare const _default: import("./types").FilterDefinition<QuantizeOptions>;
export default _default;
