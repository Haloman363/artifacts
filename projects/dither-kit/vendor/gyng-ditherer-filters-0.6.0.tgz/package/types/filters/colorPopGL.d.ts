export declare const colorPopGLAvailable: () => boolean;
export declare const renderColorPopGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, targetHue: number, hueWidth: number, desaturateOthers: number, softness: number) => HTMLCanvasElement | OffscreenCanvas | null;
