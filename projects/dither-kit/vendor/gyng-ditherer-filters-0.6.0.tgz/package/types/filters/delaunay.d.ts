export declare const optionTypes: {
    pointCount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeWeight: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    showEdges: {
        type: string;
        default: boolean;
        desc: string;
    };
    seed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    pointCount: number;
    edgeWeight: number;
    showEdges: boolean;
    seed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
