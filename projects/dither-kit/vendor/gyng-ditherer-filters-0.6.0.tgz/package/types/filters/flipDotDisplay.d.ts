export declare const optionTypes: {
    cellSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    hysteresis: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    maxFlipRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    responseFrames: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flipPriority: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    dotRoundness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gap: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    onColor: {
        type: string;
        default: [number, number, number];
        desc: string;
    };
    offColor: {
        type: string;
        default: [number, number, number];
        desc: string;
    };
    boardColor: {
        type: string;
        default: [number, number, number];
        desc: string;
    };
    specular: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    stuckDotRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    jitter: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    cellSize: number;
    threshold: number;
    hysteresis: number;
    maxFlipRate: number;
    responseFrames: number;
    flipPriority: string;
    dotRoundness: number;
    gap: number;
    onColor: [number, number, number];
    offColor: [number, number, number];
    boardColor: [number, number, number];
    specular: number;
    stuckDotRate: number;
    jitter: number;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
