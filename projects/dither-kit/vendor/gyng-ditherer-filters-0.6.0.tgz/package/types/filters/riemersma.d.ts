import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    memoryLength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    falloffRatio: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    errorStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    memoryLength: number;
    falloffRatio: number;
    errorStrength: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
type RiemersmaOptions = FilterOptionValues & typeof defaults & {
    _linearize?: boolean;
    _wasmAcceleration?: boolean;
};
declare const _default: import("./types").FilterDefinition<RiemersmaOptions>;
export default _default;
