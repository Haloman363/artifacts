export declare const optionTypes: {
    tileSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    groutWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    groutColor: {
        type: string;
        default: number[];
        desc: string;
    };
    jitter: {
        type: string;
        range: number[];
        step: number;
        default: number;
        label: string;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    tileSize: number;
    groutWidth: number;
    groutColor: number[];
    jitter: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
