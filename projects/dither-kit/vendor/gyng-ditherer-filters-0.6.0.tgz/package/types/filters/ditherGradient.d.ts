export declare const optionTypes: {
    color1: {
        type: string;
        default: number[];
        desc: string;
    };
    color2: {
        type: string;
        default: number[];
        desc: string;
    };
    angle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    style: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    amount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sourceInfluence: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    detailInfluence: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sourceColorMix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    color1: number[];
    color2: number[];
    angle: number;
    style: string;
    amount: number;
    sourceInfluence: number;
    detailInfluence: number;
    sourceColorMix: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<any>;
export default _default;
