export declare const risographGLAvailable: () => boolean;
export declare const renderRisographGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, params: {
    color1: [number, number, number];
    color2: [number, number, number];
    misregX: number;
    misregY: number;
    grain: number;
    inkBleed: number;
    threshold: number;
    levels: number;
}) => HTMLCanvasElement | OffscreenCanvas | null;
