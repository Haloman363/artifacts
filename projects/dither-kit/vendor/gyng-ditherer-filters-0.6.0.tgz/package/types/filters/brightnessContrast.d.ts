import * as palettes from "../palettes/index";
import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    brightness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    contrast: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    exposure: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gamma: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: palettes.PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    brightness: number;
    contrast: number;
    exposure: number;
    gamma: number;
    palette: palettes.PaletteDefinition<{
        levels: number;
    }>;
};
type BrightnessContrastOptions = FilterOptionValues & typeof defaults & {
    _linearize?: boolean;
};
declare const _default: import("./types").FilterDefinition<BrightnessContrastOptions>;
export default _default;
