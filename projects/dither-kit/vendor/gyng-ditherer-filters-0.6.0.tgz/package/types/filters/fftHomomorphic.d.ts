export declare const optionTypes: {
    lowGain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    highGain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cutoff: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    softness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    amount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    lowGain: number;
    highGain: number;
    cutoff: number;
    softness: number;
    amount: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
