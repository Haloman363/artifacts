export declare const claheGLAvailable: () => boolean;
export declare const claheCdfAtlasLayout: (tileCount: number, maxTextureSize: number) => {
    width: number;
    height: number;
    tilesPerRow: number;
} | null;
export declare const renderClaheGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, tileSize: number, cdfs: Uint8Array[], tilesX: number, tilesY: number) => HTMLCanvasElement | OffscreenCanvas | null;
