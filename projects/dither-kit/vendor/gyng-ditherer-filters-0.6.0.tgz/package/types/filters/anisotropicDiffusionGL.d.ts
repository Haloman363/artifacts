export declare const anisotropicDiffusionGLAvailable: () => boolean;
export declare const renderAnisotropicDiffusionGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, iterations: number, kappa: number, lambda: number, conductanceIsExp: boolean) => HTMLCanvasElement | OffscreenCanvas | null;
