import * as palettes from "../palettes/index";
import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    thresholdR: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    thresholdG: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    thresholdB: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    thresholdA: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: palettes.PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    thresholdR: number;
    thresholdG: number;
    thresholdB: number;
    thresholdA: number;
    palette: palettes.PaletteDefinition<{
        levels: number;
    }>;
};
type BinarizeOptions = FilterOptionValues & typeof defaults & {
    _linearize?: boolean;
    _webglAcceleration?: boolean;
};
declare const _default: import("./types").FilterDefinition<BinarizeOptions>;
export default _default;
