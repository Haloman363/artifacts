export declare const optionTypes: {
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    minRadius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    probeRadius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sensitivity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    glow: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sourceMix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    axisColor: {
        type: string;
        default: number[];
        desc: string;
    };
    backgroundColor: {
        type: string;
        default: number[];
        desc: string;
    };
};
export declare const defaults: { [K in keyof typeof optionTypes]: (typeof optionTypes)[K]["default"]; };
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
