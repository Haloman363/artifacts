/** Map normalized signal amplitude to a top-row-first display coordinate. */
export declare const oscilloscopeVoltageRow: (voltage: number, height: number) => number;
/** Normalized Gaussian electron-beam density at a signed pixel distance. */
export declare const oscilloscopeBeamDensity: (distance: number, width: number) => number;
/**
 * Sum excess full-well charge from successively more distant pixels.
 * `decay` is applied once per step and anti-blooming drains a fraction of the
 * accumulated excess rather than changing its colour.
 */
export declare const ccdSpilledCharge: (samples: readonly number[], fullWell: number, decay: number, antiBlooming: number) => number;
/** Expected contrast of equally weighted, independent speckle realizations. */
export declare const speckleContrastForDiversity: (singlePatternContrast: number, modes: number) => number;
