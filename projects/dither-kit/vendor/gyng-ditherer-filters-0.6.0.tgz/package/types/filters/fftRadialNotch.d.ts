export declare const optionTypes: {
    radius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    width: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    depth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    radius: number;
    width: number;
    depth: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
