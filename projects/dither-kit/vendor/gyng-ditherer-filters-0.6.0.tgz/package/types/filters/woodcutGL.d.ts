export declare const woodcutGLAvailable: () => boolean;
export declare const renderWoodcutGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, threshold: number, lineWeight: number, edgeStrength: number, inkColor: [number, number, number], paperColor: [number, number, number]) => HTMLCanvasElement | OffscreenCanvas | null;
