export declare const optionTypes: {
    mode: {
        type: string;
        options: ({
            name: string;
            value: "KNIFE";
        } | {
            name: string;
            value: "COLOR";
        } | {
            name: string;
            value: "SHADOWGRAPH";
        })[];
        default: "KNIFE";
        desc: string;
    };
    knifeAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    radius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sensitivity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cutoff: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sourceMix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    positive: {
        type: string;
        default: number[];
        desc: string;
    };
    negative: {
        type: string;
        default: number[];
        desc: string;
    };
    background: {
        type: string;
        default: number[];
        desc: string;
    };
};
export declare const defaults: {
    mode: string;
    knifeAngle: number;
    radius: number;
    sensitivity: number;
    cutoff: number;
    sourceMix: number;
    positive: number[];
    negative: number[];
    background: number[];
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
