declare const TYPE_KEYS: readonly ["PAPER", "CANVAS", "LINEN", "CARDBOARD", "PARCHMENT"];
declare const BLEND_KEYS: readonly ["MULTIPLY", "OVERLAY", "SOFT_LIGHT"];
export declare const optionTypes: {
    type: {
        type: string;
        options: {
            name: "Canvas" | "Cardboard" | "Linen" | "Paper" | "Parchment";
            value: "CANVAS" | "CARDBOARD" | "LINEN" | "PAPER" | "PARCHMENT";
        }[];
        default: (typeof TYPE_KEYS)[number];
        desc: string;
    };
    blendMode: {
        type: string;
        options: {
            name: "Multiply" | "Overlay" | "Soft Light";
            value: "MULTIPLY" | "OVERLAY" | "SOFT_LIGHT";
        }[];
        default: (typeof BLEND_KEYS)[number];
        desc: string;
    };
    scale: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    contrast: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    type: "CANVAS" | "CARDBOARD" | "LINEN" | "PAPER" | "PARCHMENT";
    blendMode: "MULTIPLY" | "OVERLAY" | "SOFT_LIGHT";
    scale: number;
    strength: number;
    contrast: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
