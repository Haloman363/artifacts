export declare const rhythmicWobbleGLAvailable: () => boolean;
export declare const renderRhythmicWobbleGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, offsetX: number, offsetY: number, angleRad: number, zoom: number) => HTMLCanvasElement | OffscreenCanvas | null;
