export declare const optionTypes: {
    contrast: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeDarken: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    speckle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    generationLoss: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    contrast: number;
    edgeDarken: number;
    speckle: number;
    generationLoss: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
