export declare const noiseGeneratorGLAvailable: () => boolean;
export type NoiseType = 0 | 1 | 2;
export declare const renderNoiseGeneratorGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, type: NoiseType, scale: number, octaves: number, seed: number, frame: number, colorize: boolean, mix: number) => HTMLCanvasElement | OffscreenCanvas | null;
