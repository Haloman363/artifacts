/** Bounded visible-luminance response used as an image-intensifier proxy. */
export declare const nightVisionIntensifierResponse: (luminance: number, gain: number) => number;
/** Absolute noise amplitude: equivalent-background floor plus shot noise. */
export declare const nightVisionNoiseAmplitude: (amplifiedSignal: number, grain: number) => number;
/**
 * Visible-luminance proxy for diffuse tissue backscatter plus impedance
 * discontinuities. Axial change carries more weight than lateral change.
 */
export declare const ultrasoundBackscatter: (center: number, axialBefore: number, axialAfter: number, lateralBefore: number, lateralAfter: number) => number;
/** Round-trip propagation transmission for a normalized B-mode depth. */
export declare const ultrasoundDepthTransmission: (depth: number) => number;
/** Unit-mean Rayleigh envelope from a uniform variate, bounded for rendering. */
export declare const ultrasoundRayleighEnvelope: (uniform: number, mix?: number) => number;
