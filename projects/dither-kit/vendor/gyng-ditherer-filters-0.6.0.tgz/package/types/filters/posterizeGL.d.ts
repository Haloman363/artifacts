export declare const posterizeGLAvailable: () => boolean;
export declare const renderPosterizeGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
