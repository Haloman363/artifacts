export declare const optionTypes: {
    aperture: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    focus: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lightSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bounces: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    roughness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    exposure: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    maxFrames: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    roomColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    aperture: number;
    focus: number;
    lightSize: number;
    bounces: number;
    roughness: number;
    exposure: number;
    maxFrames: number;
    roomColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
