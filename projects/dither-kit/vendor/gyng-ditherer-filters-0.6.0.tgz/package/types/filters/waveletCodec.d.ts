import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    transform: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    scale: {
        type: string;
        options: {
            name: string;
            value: number;
        }[];
        default: number;
        desc: string;
    };
    levels: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    channels: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    quality: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    detailLoss: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bitplaneDrop: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    codeblockLoss: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ringing: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    randomSeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    transform: string;
    scale: number;
    levels: number;
    channels: string;
    quality: number;
    detailLoss: number;
    bitplaneDrop: number;
    codeblockLoss: number;
    ringing: number;
    randomSeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
