import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    system: {
        type: string;
        options: ({
            name: string;
            value: "PAL";
        } | {
            name: string;
            value: "SECAM";
        })[];
        default: "PAL";
        desc: string;
    };
    chromaBandwidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lumaBandwidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    phaseError: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    tuningError: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    delayLine: {
        type: string;
        default: boolean;
        desc: string;
    };
    crossColor: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    crossLuma: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    channelNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    interlace: {
        type: string;
        default: boolean;
        desc: string;
    };
    randomSeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    system: "PAL";
    chromaBandwidth: number;
    lumaBandwidth: number;
    phaseError: number;
    tuningError: number;
    delayLine: boolean;
    crossColor: number;
    crossLuma: number;
    channelNoise: number;
    interlace: boolean;
    randomSeed: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
