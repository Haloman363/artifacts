export declare const optionTypes: {
    stripWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    angle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    viewAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    viewCount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    parallax: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    crosstalk: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lensStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    stripWidth: number;
    angle: number;
    viewAngle: number;
    viewCount: number;
    parallax: number;
    crosstalk: number;
    lensStrength: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
