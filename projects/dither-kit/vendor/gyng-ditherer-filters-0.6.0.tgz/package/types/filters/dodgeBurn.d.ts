export declare const optionTypes: {
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    range: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    mode: string;
    strength: number;
    range: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
