export declare const optionTypes: {
    laser: {
        type: string;
        options: ({
            name: string;
            value: "RGB";
        } | {
            name: string;
            value: "RED";
        } | {
            name: string;
            value: "GREEN";
        } | {
            name: string;
            value: "BLUE";
        })[];
        default: "RGB";
        desc: string;
    };
    grain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    coherence: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    diversity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    scanPitch: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    scanStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bloom: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    motion: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    laser: "RGB";
    grain: number;
    coherence: number;
    diversity: number;
    scanPitch: number;
    scanStrength: number;
    bloom: number;
    motion: number;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
