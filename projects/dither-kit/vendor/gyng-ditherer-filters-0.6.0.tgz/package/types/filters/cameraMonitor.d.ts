export declare const optionTypes: {
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    focusThreshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    zebraThreshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    shadowClip: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    highlightClip: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    overlayOpacity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    stripeWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    focusColor: {
        type: string;
        default: number[];
        desc: string;
    };
};
export declare const defaults: {
    mode: string;
    focusThreshold: number;
    zebraThreshold: number;
    shadowClip: number;
    highlightClip: number;
    overlayOpacity: number;
    stripeWidth: number;
    focusColor: number[];
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
