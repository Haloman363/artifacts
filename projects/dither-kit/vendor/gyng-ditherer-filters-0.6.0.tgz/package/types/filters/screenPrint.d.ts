export declare const optionTypes: {
    plates: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    offset: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    angleJitter: {
        type: string;
        range: number[];
        step: number;
        default: number;
        label: string;
        desc: string;
    };
    paperColor: {
        type: string;
        default: number[];
        desc: string;
    };
    inkStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    screenFrequency: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dotGain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    plates: number;
    offset: number;
    angleJitter: number;
    paperColor: number[];
    inkStrength: number;
    screenFrequency: number;
    dotGain: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
