export declare const optionTypes: {
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    sigma: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    k: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sharpness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flowSamples: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (opts: any) => boolean;
    };
    lineWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cleanupRadius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lineColor: {
        type: string;
        default: number[];
        desc: string;
    };
    bgColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    mode: string;
    sigma: number;
    k: number;
    sharpness: number;
    threshold: number;
    flowSamples: number;
    lineWidth: number;
    cleanupRadius: number;
    lineColor: number[];
    bgColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
