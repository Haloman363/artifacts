export declare const optionTypes: {
    brushSoftness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    washLevels: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    washStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    washSoftness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeThreshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    inkColor: {
        type: string;
        default: number[];
        desc: string;
    };
    paperColor: {
        type: string;
        default: number[];
        desc: string;
    };
    grain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    brushSoftness: number;
    washLevels: number;
    washStrength: number;
    washSoftness: number;
    edgeThreshold: number;
    edgeStrength: number;
    inkColor: number[];
    paperColor: number[];
    grain: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
