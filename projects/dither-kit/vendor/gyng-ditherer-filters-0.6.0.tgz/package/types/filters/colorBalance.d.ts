export declare const optionTypes: {
    shadowR: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    shadowG: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    shadowB: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    midtoneR: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    midtoneG: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    midtoneB: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    highlightR: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    highlightG: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    highlightB: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    shadowR: number;
    shadowG: number;
    shadowB: number;
    midtoneR: number;
    midtoneG: number;
    midtoneB: number;
    highlightR: number;
    highlightG: number;
    highlightB: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
