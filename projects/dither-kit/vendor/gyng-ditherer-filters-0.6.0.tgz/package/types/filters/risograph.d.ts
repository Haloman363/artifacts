import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    color1: {
        type: string;
        default: number[];
        desc: string;
    };
    color2: {
        type: string;
        default: number[];
        desc: string;
    };
    misregX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    misregY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    grain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    inkBleed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    color1: number[];
    color2: number[];
    misregX: number;
    misregY: number;
    grain: number;
    inkBleed: number;
    threshold: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
