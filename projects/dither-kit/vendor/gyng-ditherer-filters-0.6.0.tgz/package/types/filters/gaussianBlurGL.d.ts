export declare const gaussianBlurGLAvailable: () => boolean;
export declare const renderGaussianBlurGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, sigma: number) => HTMLCanvasElement | OffscreenCanvas | null;
