import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    resolution: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    fadeGradient: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dotDensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    resolution: number;
    fadeGradient: number;
    dotDensity: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
