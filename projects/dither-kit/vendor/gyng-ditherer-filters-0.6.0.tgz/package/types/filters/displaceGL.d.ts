export declare const displaceGLAvailable: () => boolean;
export declare const DISPLACE_DIR_ID: Record<string, number>;
export declare const renderDisplaceGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, strength: number, direction: string, warpSource: string, blurRadius: number, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
