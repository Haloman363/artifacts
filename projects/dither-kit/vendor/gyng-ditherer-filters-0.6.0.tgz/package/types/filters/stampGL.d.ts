export declare const stampGLAvailable: () => boolean;
export declare const renderStampGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, threshold: number, roughness: number, inkColor: [number, number, number], paperColor: [number, number, number]) => HTMLCanvasElement | OffscreenCanvas | null;
