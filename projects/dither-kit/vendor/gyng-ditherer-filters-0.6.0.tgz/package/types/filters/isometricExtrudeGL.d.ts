export declare const isometricExtrudeGLAvailable: () => boolean;
export declare const renderIsometricExtrudeGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, depth: number, stepX: number, stepY: number, threshold: number, shadowColor: number[], shadeFalloff: number) => HTMLCanvasElement | OffscreenCanvas | null;
