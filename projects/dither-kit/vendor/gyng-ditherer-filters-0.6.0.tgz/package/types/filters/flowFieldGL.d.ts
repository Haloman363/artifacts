export declare const flowFieldGLAvailable: () => boolean;
export declare const renderFlowFieldGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, scale: number, strength: number, steps: number, seed: number) => HTMLCanvasElement | OffscreenCanvas | null;
