export declare const optionTypes: {
    strokeDensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    contrast: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    pencilColor: {
        type: string;
        default: number[];
        desc: string;
    };
    paperColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    strokeDensity: number;
    contrast: number;
    pencilColor: number[];
    paperColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
