import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    scanMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    coding: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    bitErrorRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    concealment: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    scanNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    yellowing: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    randomSeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    scanMode: string;
    threshold: number;
    coding: string;
    bitErrorRate: number;
    concealment: string;
    scanNoise: number;
    yellowing: number;
    randomSeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
export declare const resolveFaxBitErrorRate: (options: {
    bitErrorRate?: unknown;
    compression?: unknown;
}) => number;
export declare const resolveFaxSampling: (width: number, options: {
    scanMode?: unknown;
    resolution?: unknown;
}) => {
    scaleX: number;
    scaleY: number;
    mrK: number;
    mode: string;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
