export declare const optionTypes: {
    seed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animateNoise: {
        type: string;
        default: boolean;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    seed: number;
    animateNoise: boolean;
    palette: import("..").PaletteDefinition<{
        levels: number;
    }>;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
