export declare const optionTypes: {
    effect: {
        type: string;
        options: ({
            name: string;
            value: "ECHO";
        } | {
            name: string;
            value: "REVERB";
        } | {
            name: string;
            value: "BITCRUSH";
        } | {
            name: string;
            value: "REVERSE";
        })[];
        default: "ECHO";
        desc: string;
    };
    intensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    offset: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    effect: "ECHO";
    intensity: number;
    offset: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
