export declare const optionTypes: {
    cellSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    outline: {
        type: string;
        default: boolean;
        desc: string;
    };
    outlineColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    cellSize: number;
    outline: boolean;
    outlineColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
