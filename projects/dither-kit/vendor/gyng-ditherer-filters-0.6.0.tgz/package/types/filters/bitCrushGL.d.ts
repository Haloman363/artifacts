export declare const bitCrushGLAvailable: () => boolean;
export declare const renderBitCrushGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, bits: number) => HTMLCanvasElement | OffscreenCanvas | null;
