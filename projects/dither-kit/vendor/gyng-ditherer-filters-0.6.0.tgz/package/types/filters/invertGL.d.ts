export declare const invertGLAvailable: () => boolean;
export declare const renderInvertGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, invertR: boolean, invertG: boolean, invertB: boolean, invertA: boolean) => HTMLCanvasElement | OffscreenCanvas | null;
