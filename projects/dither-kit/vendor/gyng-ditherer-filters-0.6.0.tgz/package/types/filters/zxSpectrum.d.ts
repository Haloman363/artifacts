import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    flashProbability: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flashEnabled: {
        type: string;
        default: boolean;
        desc: string;
    };
    pixelGrid: {
        type: string;
        default: boolean;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
};
export declare const defaults: {
    flashProbability: number;
    flashEnabled: boolean;
    pixelGrid: boolean;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
