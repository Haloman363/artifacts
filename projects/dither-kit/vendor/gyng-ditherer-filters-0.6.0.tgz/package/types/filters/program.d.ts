import * as palettes from "../palettes/index";
export declare const optionTypes: {
    program: {
        type: string;
        desc: string;
        default: string;
    };
    palette: {
        type: string;
        default: palettes.PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    program: string;
    palette: palettes.PaletteDefinition<{
        levels: number;
    }>;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
