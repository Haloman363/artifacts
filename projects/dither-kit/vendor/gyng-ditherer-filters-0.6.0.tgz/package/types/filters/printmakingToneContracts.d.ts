export declare const clamp01: (value: number) => number;
/** Rec. 709 luminance of an 8-bit RGB triple, normalised to 0..1. */
export declare const luminance01: (r: number, g: number, b: number) => number;
/** Peak inked fraction a single fully-developed hatch layer contributes. */
export declare const HATCH_LAYER_COVERAGE = 0.5;
/**
 * Within-layer fill for hatch layer `layerIndex` of `layerCount` as darkness
 * rises. Layer 0 fills across darkness [0, 1/count], layer 1 across
 * [1/count, 2/count], and so on, so lighter tones show only the first layer
 * and shadows accumulate every layer. Returns 0..1.
 */
export declare const hatchLayerFill: (darkness: number, layerIndex: number, layerCount: number) => number;
/**
 * Half-width (px) of a hatch line so a layer at spacing `spacing` reaches
 * `fill * HATCH_LAYER_COVERAGE` areal coverage. A parallel-line screen of
 * spacing S and full width w covers w / S, so the half-width is
 * 0.5 * coverage * spacing.
 */
export declare const hatchLineHalfWidthPx: (fill: number, spacing: number, maxCoverage?: number) => number;
/**
 * Statistical inked fraction of `layerCount` hatch layers at the given
 * darkness, treating layers as independent screens: 1 - Π(1 - p_k). Monotone
 * in darkness, ~0 at white and near-1 at black. This is the tone the shader
 * reproduces on a flat patch, and the anchor the contracts assert against.
 */
export declare const hatchUnionCoverage: (darkness: number, layerCount: number, maxCoverage?: number) => number;
/**
 * Anti-aliased areal coverage of a mark of half-width `halfWidth` at distance
 * `distToCenter`, with an `aa`-wide linear edge centred on the geometric edge
 * (½ coverage exactly at the edge). A zero-width mark contributes no ink, so
 * a tone with no developed strokes stays bare paper.
 */
export declare const lineCoverage: (distToCenter: number, halfWidth: number, aa?: number) => number;
/**
 * Unit tangent along an edge given the luminance gradient (gx, gy): the
 * direction perpendicular to the gradient, so strokes run along contours.
 * Falls back to the horizontal axis on a flat neighbourhood.
 */
export declare const gradientTangent: (gx: number, gy: number) => [number, number];
/**
 * Principal tangent angle (radians) of the 2×2 structure tensor
 * [[gxx, gxy], [gxy, gyy]] — the minor-eigenvector direction, along which
 * image structure is coherent. Used for form-following gouges/lines.
 */
export declare const structureTensorTangentAngle: (gxx: number, gyy: number, gxy: number) => number;
/** Tensor coherence 0..1: 1 where structure is strongly oriented, 0 isotropic. */
export declare const structureTensorCoherence: (gxx: number, gyy: number, gxy: number) => number;
/**
 * Fill of each engraving tone structure as darkness rises: the primary burin
 * lines swell first, a crossing secondary set enters the mid-shadows, and a
 * lozenge/dot texture fills the deepest shadows — the classic copperplate
 * tone ladder. Each field is 0..1 and monotone in darkness.
 */
export declare const engravingShadowStructure: (darkness: number) => {
    primaryFill: number;
    secondaryFill: number;
    lozengeFill: number;
};
/**
 * Stipple dot radius (px). Deliberately independent of tone: stippling varies
 * dot *density*, not size (the previous filter grew the radius, which is
 * amplitude-modulated halftone, not stippling).
 */
export declare const stippleDotRadiusPx: (maxDotSize: number) => number;
/**
 * Whether a stipple cell carries a dot, given local darkness and the cell's
 * blue-noise threshold (both 0..1). Because thresholds are ~uniform, the
 * fraction of inked cells equals darkness — density tracks tone.
 */
export declare const stippleDotPresent: (darkness: number, blueNoiseThreshold: number) => boolean;
/** Expected inked-cell density for a flat patch of the given darkness. */
export declare const stippleExpectedDensity: (darkness: number) => number;
/** Anti-aliased coverage of a round dot at squared distance `distSq` (px²). */
export declare const dotCoverage: (distSq: number, radiusPx: number, aa?: number) => number;
export declare const PRINTMAKING_TONE_GLSL = "\nfloat pm_clamp01(float v) { return clamp(v, 0.0, 1.0); }\nfloat pm_luma(vec3 c) { return pm_clamp01(0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b); }\n\n// Within-layer fill for hatch layer k of n as darkness rises.\nfloat pm_hatchLayerFill(float darkness, float layerIndex, float layerCount) {\n  if (layerIndex >= layerCount) return 0.0;\n  return pm_clamp01(pm_clamp01(darkness) * layerCount - layerIndex);\n}\n\n// Half-width (px) so a spacing-S screen reaches fill*maxCoverage area.\nfloat pm_hatchHalfWidth(float fill, float spacing, float maxCoverage) {\n  return 0.5 * pm_clamp01(fill) * pm_clamp01(maxCoverage) * max(spacing, 1e-3);\n}\n\n// Anti-aliased mark coverage, \u00BD at the geometric edge; zero width => no ink.\nfloat pm_lineCoverage(float distToCenter, float halfWidth, float aa) {\n  if (halfWidth <= 0.0) return 0.0;\n  return pm_clamp01((halfWidth - abs(distToCenter)) / max(aa, 1e-3) + 0.5);\n}\n\n// Unit tangent perpendicular to the gradient (runs along contours).\nvec2 pm_gradientTangent(float gx, float gy) {\n  float mag = length(vec2(gx, gy));\n  if (mag < 1e-4) return vec2(1.0, 0.0);\n  return vec2(-gy, gx) / mag;\n}\n\n// Principal tangent angle of the structure tensor [[gxx,gxy],[gxy,gyy]].\n// atan(0,0) is spec-undefined, so a flat neighbourhood returns a stable axis.\nfloat pm_tensorTangentAngle(float gxx, float gyy, float gxy) {\n  if (abs(gxy) < 1e-8 && abs(gxx - gyy) < 1e-8) return 1.57079632679;\n  return 0.5 * atan(2.0 * gxy, gxx - gyy) + 1.57079632679;\n}\n";
