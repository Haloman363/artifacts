export declare const optionTypes: {
    radius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    regionMerge: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgePreserve: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    brushiness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    shadowRetention: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    radius: number;
    regionMerge: number;
    edgePreserve: number;
    brushiness: number;
    shadowRetention: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
