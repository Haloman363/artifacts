export declare const optionTypes: {
    radius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    intensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    shape: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    localDetect: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    softness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bubble: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeRing: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeFringe: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    rotation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    catsEye: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    radius: number;
    threshold: number;
    intensity: number;
    shape: string;
    localDetect: number;
    softness: number;
    bubble: number;
    edgeRing: number;
    edgeFringe: number;
    rotation: number;
    catsEye: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
