export declare const NTSC_RATE: number;
export declare const FIR_TAPS = 65;
export type TapeSpeed = "NONE" | "SP" | "LP" | "EP";
export type TapeFilterType = "BUTTERWORTH" | "CONSTANT_K";
export type TapeProfile = {
    lumaCutoff: number;
    chromaCutoff: number;
    chromaDelay: number;
};
export declare const TAPE_PROFILES: Record<TapeSpeed, TapeProfile>;
export declare const makeLowpassKernel: (cutoff: number, filterType: TapeFilterType, taps?: number) => Float32Array;
export declare const makeRestorationKernel: (cutoff: number, taps?: number) => Float32Array;
export declare const makeCompositePreemphasisKernel: (intensity: number, taps?: number) => Float32Array;
export declare const makeSharpenKernel: (cutoff: number, filterType: TapeFilterType, intensity: number, frequency?: number, taps?: number) => Float32Array;
export declare const makeLumaSmearKernel: (amount: number, taps?: number) => Float32Array;
export declare const makeNotchKernel: (frequency?: number, power?: number, scale?: number, taps?: number) => Float32Array;
export declare const makeRingingKernel: (frequency?: number, power?: number, intensity?: number, taps?: number) => Float32Array;
export declare const frequencyMagnitude: (kernel: ArrayLike<number>, radians: number) => number;
export declare const applyCausalKernel: (signal: ArrayLike<number>, kernel: ArrayLike<number>, advance?: number) => Float32Array;
export type ConformancePattern = "impulse" | "step" | "smpte" | "zonePlate" | "alternatingLines";
export declare const makeConformancePattern: (pattern: ConformancePattern, width: number, height: number) => Float32Array;
export declare const peakIndex: (signal: ArrayLike<number>) => number;
export declare const stepOvershoot: (signal: ArrayLike<number>, steadyState?: number) => number;
export declare const alternatingLineEnergy: (signal: ArrayLike<number>, width: number) => number;
export declare class SplitMix64 {
    private state;
    constructor(seed: number | bigint);
    clone(): SplitMix64;
    nextU64(): bigint;
    nextU32(): number;
    nextFloat(): number;
    mix(input: number | bigint): SplitMix64;
}
export declare const simplex1d: (x: number, seed: number) => number;
export declare const simplex2d: (x: number, y: number, seed: number) => number;
export type NoisePlane = {
    data: Float32Array;
    width: number;
    height: number;
};
export declare const makeNoisePlane: (width: number, height: number, seed: number, frame: number) => NoisePlane;
export declare const makeRowNoisePlane: (height: number, seed: number, frame: number, chromaLoss: number) => NoisePlane;
