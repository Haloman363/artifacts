export declare const halationGLAvailable: () => boolean;
export declare const renderHalationGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, radius: number, threshold: number, // 0..255
strength: number, tint: number[]) => HTMLCanvasElement | OffscreenCanvas | null;
