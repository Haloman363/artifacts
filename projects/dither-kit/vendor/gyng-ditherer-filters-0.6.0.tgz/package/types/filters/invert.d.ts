export declare const optionTypes: {
    invertR: {
        type: string;
        default: boolean;
        desc: string;
    };
    invertG: {
        type: string;
        default: boolean;
        desc: string;
    };
    invertB: {
        type: string;
        default: boolean;
        desc: string;
    };
    invertA: {
        type: string;
        default: boolean;
        desc: string;
    };
};
export declare const defaults: {
    invertR: boolean;
    invertG: boolean;
    invertB: boolean;
    invertA: boolean;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
