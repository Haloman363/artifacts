export declare const optionTypes: {
    sigmaSpatial: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sigmaRange: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    workingResolution: {
        type: string;
        options: ({
            name: string;
            value: "HALF";
        } | {
            name: string;
            value: "FULL";
        } | {
            name: string;
            value: "QUARTER";
        })[];
        default: "HALF";
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    sigmaSpatial: number;
    sigmaRange: number;
    workingResolution: "HALF";
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
export declare const resolveBilateralWorkFactor: (width: number, height: number, requested: number) => number | null;
export declare const resolveBilateralCpuFactor: (width: number, height: number, requested: number) => number | null;
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
