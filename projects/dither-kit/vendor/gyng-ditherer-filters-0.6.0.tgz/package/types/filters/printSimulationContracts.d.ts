/** Separable stencil-ink softening radius; zero means an exact no-blur path. */
export declare const risographBlurRadius: (inkBleed: number) => number;
/** Fixed, balanced registration offset for one plate on a completed sheet. */
export declare const fixedPrintPlateOffset: (layer: number, layers: number, maximumOffset: number) => [number, number];
/** Bounded duplex plate coverages; both inks clear to paper in highlights. */
export declare const duplexPlateCoverages: (luminance: number, mixCurve: number) => {
    dark: number;
    accent: number;
};
/** Stable, correlated stencil/ink variation centered on zero. */
export declare const stencilInkVariation: (x: number, y: number, layer: number) => number;
/** Binary clustered-dot decision for a rotated screen-print plate. */
export declare const screenHalftoneDecision: (coverage: number, x: number, y: number, cellSize: number, angleDegrees: number, dotGain: number) => boolean;
