export declare const polaroidGLAvailable: () => boolean;
export declare const renderPolaroidGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, warmth: number, fadedBlacks: number, saturation: number, grain: number, vignette: number) => HTMLCanvasElement | OffscreenCanvas | null;
