export declare const optionTypes: {
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    steps: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dt: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    viscosity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    forcing: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    pressureIterations: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    amount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    mode: string;
    steps: number;
    dt: number;
    viscosity: number;
    forcing: number;
    pressureIterations: number;
    amount: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
