export declare const optionTypes: {
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    inflate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    melt: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    noiseScale: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bevel: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    metallic: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animateSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    background: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    threshold: number;
    inflate: number;
    melt: number;
    noiseScale: number;
    bevel: number;
    metallic: number;
    animateSpeed: number;
    background: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
