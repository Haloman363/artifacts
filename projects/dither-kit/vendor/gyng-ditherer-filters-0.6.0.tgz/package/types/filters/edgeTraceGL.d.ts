export declare const edgeTraceGLAvailable: () => boolean;
export declare const renderEdgeTraceGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, threshold: number, lineWidth: number, lineColor: [number, number, number], bgColor: [number, number, number], modeIsOverlay: boolean, overlayMix: number) => HTMLCanvasElement | OffscreenCanvas | null;
