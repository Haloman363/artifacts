export declare const crcStripeRejectGLAvailable: () => boolean;
export declare const CRC_PATTERN_ID: Record<string, number>;
export declare const CRC_CONCEAL_ID: Record<string, number>;
export declare const renderCrcStripeRejectGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, pattern: string, rejectChance: number, stripeHeight: number, tileSize: number, conceal: string, jitter: number, frameIndex: number, prevOutput: Uint8ClampedArray | null, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
