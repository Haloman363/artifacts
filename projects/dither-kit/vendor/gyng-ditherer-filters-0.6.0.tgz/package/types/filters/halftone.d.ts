import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    size: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sizeMultiplier: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    offset: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    levels: {
        type: string;
        range: number[];
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
    squareDots: {
        type: string;
        default: boolean;
        desc: string;
    };
    background: {
        type: string;
        default: string;
        desc: string;
    };
};
export declare const defaults: {
    size: number;
    sizeMultiplier: number;
    offset: number;
    levels: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
    squareDots: boolean;
    background: string;
};
type HalftoneOptions = FilterOptionValues & typeof defaults & {
    _linearize?: boolean;
};
declare const _default: import("./types").FilterDefinition<HalftoneOptions>;
export default _default;
