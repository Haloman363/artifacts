export declare const optionTypes: {
    intensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    falseColor: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    foliageResponse: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    skySuppression: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    contrast: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    grain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    intensity: number;
    falseColor: number;
    foliageResponse: number;
    skySuppression: number;
    contrast: number;
    grain: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
