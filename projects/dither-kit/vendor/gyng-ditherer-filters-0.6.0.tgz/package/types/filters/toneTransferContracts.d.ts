/**
 * Smooth Sabattier (solarization) tone-reversal curve. Below the reversal point
 * the tone is unchanged; above it the tone folds back down toward zero, so the
 * curve rises to a hump at the reversal point and then reverses — the darkroom
 * re-exposure characteristic, not a knife-edge invert. `strength` blends from
 * identity (0) to full reversal (1). Applied per channel with the SAME curve,
 * so there is no independent per-channel flip.
 */
export declare const solarizeCurve: (t: number, reversal: number, strength: number) => number;
/**
 * Koschmieder transmission t = e^(−β·depth) for a normalized depth 0..1. At
 * depth 0 (nearest) t = 1 (no haze); it falls off exponentially with depth.
 */
export declare const koschmiederTransmission: (depth: number, beta: number) => number;
/** Airlight composite in linear light: out = src·t + airlight·(1 − t). */
export declare const airlightComposite: (srcLinear: number, airLinear: number, transmission: number) => number;
/**
 * Apply an exposure factor to an sRGB channel value in linear light: the
 * physically correct way to dodge (factor > 1) or burn (factor < 1). Returns an
 * sRGB value in 0..1.
 */
export declare const linearExposure: (srgbValue: number, factor: number) => number;
export declare const SOLARIZE_GLSL = "\nfloat tt_solarizeCurve(float t, float rev, float strength) {\n  float tc = clamp(t, 0.0, 1.0);\n  float r = clamp(rev, 0.01, 0.99);\n  float reflected = max(0.0, r - (tc - r) * (r / (1.0 - r)));\n  float band = 0.5 * min(r, 1.0 - r);\n  float w = smoothstep(r - band, r + band, tc);\n  float folded = mix(tc, reflected, w);\n  return clamp(tc + (folded - tc) * clamp(strength, 0.0, 1.0), 0.0, 1.0);\n}\n";
