export declare const optionTypes: {
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    depth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    angle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bevel: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    metallic: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sideColor: {
        type: string;
        default: number[];
        desc: string;
    };
    background: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    threshold: number;
    depth: number;
    angle: number;
    bevel: number;
    metallic: number;
    sideColor: number[];
    background: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
