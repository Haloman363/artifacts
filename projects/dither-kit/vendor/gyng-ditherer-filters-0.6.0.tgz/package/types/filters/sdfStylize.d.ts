export declare const optionTypes: {
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    spacing: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    thickness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lineColor: {
        type: string;
        default: number[];
        desc: string;
    };
    fillColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    mode: string;
    threshold: number;
    spacing: number;
    thickness: number;
    lineColor: number[];
    fillColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
