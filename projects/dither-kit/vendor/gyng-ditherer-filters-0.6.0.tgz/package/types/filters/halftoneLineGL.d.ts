export declare const halftoneLineGLAvailable: () => boolean;
export declare const renderHalftoneLineGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, cellSize: number, angleMode: 0 | 1 | 2, baseAngleRad: number, inkColor: [number, number, number], paperColor: [number, number, number]) => HTMLCanvasElement | OffscreenCanvas | null;
