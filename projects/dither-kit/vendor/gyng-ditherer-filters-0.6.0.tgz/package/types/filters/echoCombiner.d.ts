import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    gain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    baseline: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    gain: number;
    baseline: string;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
