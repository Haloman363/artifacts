export declare const MAX_PAL = 64;
export declare const MAX_N = 64;
export declare const NC_ALGO: {
    readonly KNOLL: 0;
    readonly EMA_SWEEP: 1;
    readonly EMA_EXACT: 2;
    readonly EMA_CONSTANT: 3;
};
export declare const NC_SPACE: {
    readonly SRGB: 0;
    readonly LINEAR: 1;
    readonly LIQ: 2;
};
export declare const nCandidateGLAvailable: () => boolean;
export declare const toWorkingSpace: (rgb: readonly number[], space: number) => [number, number, number];
export declare const preparePalette: (palette: number[][], space: number, maxPal?: number) => {
    work: [number, number, number];
    out: number[];
    luma: number;
}[];
export declare const renderNCandidateGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, opts: {
    thresholdMap: number[][];
    thresholdLevels: number;
    thresholdMapKey: string;
    algo: number;
    candidates: number;
    strength: number;
    minT: number;
    maxT: number;
    constantT: number;
    colorspace: number;
    lumaWeighted: boolean;
    sweepTests: number;
    paletteRgb: number[][];
    maxPal?: number;
}) => HTMLCanvasElement | OffscreenCanvas | null;
