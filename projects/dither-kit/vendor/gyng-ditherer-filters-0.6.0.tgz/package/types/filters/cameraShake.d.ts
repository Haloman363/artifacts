import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    amountX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    amountY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    rotation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    zoomJitter: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    frequency: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    inertia: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    tremor: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    amountX: number;
    amountY: number;
    rotation: number;
    zoomJitter: number;
    frequency: number;
    inertia: number;
    tremor: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const resetRigState: () => void;
export declare const __testing: {
    resetRigState: typeof resetRigState;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
