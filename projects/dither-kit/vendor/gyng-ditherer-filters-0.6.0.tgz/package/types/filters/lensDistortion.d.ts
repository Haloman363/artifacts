export declare const optionTypes: {
    k1: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    k2: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    zoom: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    k1: number;
    k2: number;
    zoom: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
