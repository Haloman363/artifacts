import { type FilterOptionValues } from "./types";
import * as palettes from "../palettes/index";
type Quadlet = number[];
type SortDirection = string;
type IteratorInit = {
    x: number;
    y: number;
    i: number;
    w: number;
    h: number;
};
type IteratorResult = IteratorInit & {
    wrapX: boolean;
    wrapY: boolean;
    endInterval: boolean;
};
type IteratorFn = () => IteratorResult | null;
export declare const DIRECTION: {
    COLUMN: string;
    ROW: string;
    CIRCULAR: string;
    SPIRAL: string;
    SPIRAL_CUT: string;
    DIAGONAL_TOP_RIGHT: string;
};
export declare const SORT_DIRECTION: {
    ASCENDING: string;
    DESCENDING: string;
};
export declare const COMPARATOR: {
    LUMINANCE: string;
    RGBA: string;
    GBRA: string;
    BGRA: string;
    HSVA: string;
    VSHA: string;
    SVHA: string;
    LABA: string;
    ABLA: string;
    BALA: string;
};
declare const compareQuadlet: (a: Quadlet, b: Quadlet, dir: SortDirection) => number;
export declare const SORTS: {
    [COMPARATOR.RGBA]: typeof compareQuadlet;
    [COMPARATOR.GBRA]: (a: Quadlet, b: Quadlet, dir: SortDirection) => number;
    [COMPARATOR.BGRA]: (a: Quadlet, b: Quadlet, dir: SortDirection) => number;
    [COMPARATOR.HSVA]: (aRgba: Quadlet, bRgba: Quadlet, dir: SortDirection) => number;
    [COMPARATOR.SVHA]: (aRgba: Quadlet, bRgba: Quadlet, dir: SortDirection) => number;
    [COMPARATOR.VSHA]: (aRgba: Quadlet, bRgba: Quadlet, dir: SortDirection) => number;
    [COMPARATOR.LABA]: (aRgba: Quadlet, bRgba: Quadlet, dir: SortDirection) => number;
    [COMPARATOR.ABLA]: (aRgba: Quadlet, bRgba: Quadlet, dir: SortDirection) => number;
    [COMPARATOR.BALA]: (aRgba: Quadlet, bRgba: Quadlet, dir: SortDirection) => number;
    [COMPARATOR.LUMINANCE]: (a: Quadlet, b: Quadlet, dir: SortDirection, linear?: boolean) => number;
};
declare const circularIterator: (init: IteratorInit) => IteratorFn;
export declare const ITERATORS: {
    [DIRECTION.ROW]: (init: IteratorInit) => IteratorFn;
    [DIRECTION.COLUMN]: (init: IteratorInit) => IteratorFn;
    [DIRECTION.CIRCULAR]: typeof circularIterator;
    [DIRECTION.SPIRAL_CUT]: (init: IteratorInit) => IteratorFn;
    [DIRECTION.SPIRAL]: (init: IteratorInit) => IteratorFn;
    [DIRECTION.DIAGONAL_TOP_RIGHT]: (init: IteratorInit) => IteratorFn;
};
export declare const optionTypes: {
    direction: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    sortDirection: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    comparator: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    sortPixelLuminanceAbove: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sortPixelLuminanceBelow: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sortPixelLuminanceChangeAbove: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sortPixelLuminanceChangeBelow: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    extraIntervalStartChance: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    seed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    maxIntervalSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: palettes.PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
    linearLuminance: {
        type: string;
        default: boolean;
        desc: string;
    };
};
export declare const defaults: {
    direction: string;
    sortDirection: string;
    comparator: string;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
    linearLuminance: boolean;
    sortPixelLuminanceAbove: number;
    sortPixelLuminanceBelow: number;
    sortPixelLuminanceChangeAbove: number;
    sortPixelLuminanceChangeBelow: number;
    extraIntervalStartChance: number;
    seed: number;
    maxIntervalSize: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
