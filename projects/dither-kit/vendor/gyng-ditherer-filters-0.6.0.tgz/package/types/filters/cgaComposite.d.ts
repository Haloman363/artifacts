import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    hue: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    saturation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    monitorBandwidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    blackLevel: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    scanlineStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    mode: string;
    hue: number;
    saturation: number;
    monitorBandwidth: number;
    blackLevel: number;
    scanlineStrength: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
