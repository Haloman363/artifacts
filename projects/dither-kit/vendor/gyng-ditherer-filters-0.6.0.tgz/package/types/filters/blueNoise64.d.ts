export declare const BLUE_NOISE_MAP: number[][];
export declare const BLUE_NOISE_SIZE = 64;
export declare const BLUE_NOISE_LEVELS: number;
