export declare const smoothPosterizeGLAvailable: () => boolean;
export declare const renderSmoothPosterizeGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, levels: number, smoothness: number) => HTMLCanvasElement | OffscreenCanvas | null;
