import { type FilterOptionValues } from "./types";
type JpegArtifactPalette = {
    options?: FilterOptionValues;
} & Record<string, unknown>;
type JpegArtifactOptions = FilterOptionValues & {
    qualityLuma?: number;
    qualityChroma?: number;
    quality?: number;
    subsampling?: string;
    blockSize?: number;
    ringing?: number;
    mosquito?: number;
    gridJitter?: number;
    corruptBurstChance?: number;
    deblock?: number;
    temporalHold?: number;
    keyframeInterval?: number;
    preserveAlpha?: boolean;
    palette?: JpegArtifactPalette;
    _prevOutput?: Uint8ClampedArray | null;
    _frameIndex?: number;
};
export declare const optionTypes: {
    qualityLuma: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    qualityChroma: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    subsampling: {
        type: string;
        default: string;
        options: {
            name: string;
            value: string;
        }[];
        desc: string;
    };
    blockSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ringing: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    mosquito: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gridJitter: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    corruptBurstChance: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    deblock: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    temporalHold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    keyframeInterval: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    preserveAlpha: {
        type: string;
        default: boolean;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    qualityLuma: number;
    qualityChroma: number;
    subsampling: string;
    blockSize: number;
    ringing: number;
    mosquito: number;
    gridJitter: number;
    corruptBurstChance: number;
    deblock: number;
    temporalHold: number;
    keyframeInterval: number;
    preserveAlpha: boolean;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
export declare const tryApplyJpegArtifactToCanvas: (input: any, options?: JpegArtifactOptions) => HTMLCanvasElement | OffscreenCanvas | null;
export declare const applyJpegArtifactToCanvas: (input: any, options?: JpegArtifactOptions) => HTMLCanvasElement | OffscreenCanvas;
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
