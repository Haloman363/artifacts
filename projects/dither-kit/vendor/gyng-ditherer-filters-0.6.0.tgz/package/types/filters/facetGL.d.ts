export declare const facetGLAvailable: () => boolean;
export declare const renderFacetGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, facetSize: number, jitter: number, seamWidth: number, lineColor: [number, number, number], averageMode: boolean, seed: number) => HTMLCanvasElement | OffscreenCanvas | null;
