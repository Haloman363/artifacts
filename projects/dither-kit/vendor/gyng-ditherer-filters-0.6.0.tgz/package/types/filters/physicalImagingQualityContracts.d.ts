/** Visible-light proxy mapped into a thermal display window; not temperature. */
export declare const thermalProxyLevelSpan: (luminance: number, level: number, span: number, contrast?: number) => number;
/** Positive-image cyanotype density: darker source values form more blue. */
export declare const cyanotypeBlueDensity: (luminance: number, exposure: number, contrast: number, blueDensity: number, invert?: boolean) => number;
/** Grain remains in normalized tone units; byte scaling would violate this. */
export declare const cyanotypeGrainAmplitude: (grain: number) => number;
