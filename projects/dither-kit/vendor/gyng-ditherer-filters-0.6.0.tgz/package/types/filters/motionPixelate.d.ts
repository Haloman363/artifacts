import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    blockSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    invert: {
        type: string;
        default: boolean;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    blockSize: number;
    invert: boolean;
    threshold: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
