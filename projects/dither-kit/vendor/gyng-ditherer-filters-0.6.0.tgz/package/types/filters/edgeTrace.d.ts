export declare const optionTypes: {
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lineWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lineColor: {
        type: string;
        default: number[];
        desc: string;
    };
    renderMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    overlayMix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    bgColor: {
        type: string;
        default: number[];
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    threshold: number;
    lineWidth: number;
    lineColor: number[];
    renderMode: string;
    overlayMix: number;
    bgColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
