export declare const optionTypes: {
    intensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    warmth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    hotspots: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    seed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    distortion: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    blistering: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    roughness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    intensity: number;
    warmth: number;
    hotspots: number;
    seed: number;
    distortion: number;
    blistering: number;
    roughness: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
