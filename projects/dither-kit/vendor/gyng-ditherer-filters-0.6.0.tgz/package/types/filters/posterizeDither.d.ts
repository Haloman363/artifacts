export declare const optionTypes: {
    levelsR: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    levelsG: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    levelsB: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    matrixSize: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    levelsR: number;
    levelsG: number;
    levelsB: number;
    matrixSize: string;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
