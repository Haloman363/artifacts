import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    pattern: {
        type: string;
        default: string;
        options: {
            name: string;
            value: string;
        }[];
        desc: string;
    };
    rejectChance: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    stripeHeight: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    tileSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    conceal: {
        type: string;
        default: string;
        options: {
            name: string;
            value: string;
        }[];
        desc: string;
    };
    jitter: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    pattern: string;
    rejectChance: number;
    stripeHeight: number;
    tileSize: number;
    conceal: string;
    jitter: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
