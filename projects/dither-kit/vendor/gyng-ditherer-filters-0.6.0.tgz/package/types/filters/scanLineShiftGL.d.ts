export declare const scanLineShiftGLAvailable: () => boolean;
export declare const renderScanLineShiftGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, maxShift: number, blockHeight: number, chance: number, colorShift: boolean, wrap: boolean, frameIndex: number, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
