export declare const posterizeDitherGLAvailable: () => boolean;
export declare const renderPosterizeDitherGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, matrix: number[][], matrixN: number, levelsR: number, levelsG: number, levelsB: number) => HTMLCanvasElement | OffscreenCanvas | null;
