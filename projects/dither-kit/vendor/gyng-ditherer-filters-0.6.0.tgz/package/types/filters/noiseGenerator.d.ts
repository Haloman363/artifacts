export declare const optionTypes: {
    type: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    scale: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    octaves: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    seed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    colorize: {
        type: string;
        default: boolean;
        desc: string;
    };
    mix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    type: string;
    scale: number;
    octaves: number;
    seed: number;
    colorize: boolean;
    mix: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
