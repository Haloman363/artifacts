export declare const lumaMatteGLAvailable: () => boolean;
export declare const renderLumaMatteGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, low: number, high: number, invert: boolean, bgMode: 0 | 1 | 2) => HTMLCanvasElement | OffscreenCanvas | null;
