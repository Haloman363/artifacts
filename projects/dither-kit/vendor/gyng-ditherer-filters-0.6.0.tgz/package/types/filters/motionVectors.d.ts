import { type FilterOptionValues } from "./types";
export declare const clearMotionVectorsState: () => void;
export declare const optionTypes: {
    display: {
        type: string;
        label: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    sourceMode: {
        type: string;
        label: string;
        options: ({
            name: string;
            value: "RGB";
        } | {
            name: string;
            value: "RED";
        } | {
            name: string;
            value: "GREEN";
        } | {
            name: string;
            value: "BLUE";
        } | {
            name: string;
            value: "LUMA";
        })[];
        default: "LUMA";
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    cellSize: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    searchRadius: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    threshold: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    minMagnitude: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    confidenceCutoff: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gain: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    colorMode: {
        type: string;
        label: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    glyphMode: {
        type: string;
        label: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    temporalSmoothing: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    spatialSmoothing: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    showMagnitude: {
        type: string;
        label: string;
        default: boolean;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    backgroundDim: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    trailDecay: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    animSpeed: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    cellSize: number;
    searchRadius: number;
    threshold: number;
    gain: number;
    display: string;
    sourceMode: "LUMA";
    colorMode: string;
    glyphMode: string;
    minMagnitude: number;
    confidenceCutoff: number;
    temporalSmoothing: number;
    spatialSmoothing: number;
    showMagnitude: boolean;
    backgroundDim: number;
    trailDecay: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
