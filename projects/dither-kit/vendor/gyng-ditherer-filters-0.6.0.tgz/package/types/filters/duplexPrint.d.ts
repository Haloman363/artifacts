export declare const optionTypes: {
    inkA: {
        type: string;
        default: number[];
        desc: string;
    };
    inkB: {
        type: string;
        default: number[];
        desc: string;
    };
    mixCurve: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    paperColor: {
        type: string;
        default: number[];
        desc: string;
    };
};
export declare const defaults: {
    inkA: number[];
    inkB: number[];
    mixCurve: number;
    paperColor: number[];
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
