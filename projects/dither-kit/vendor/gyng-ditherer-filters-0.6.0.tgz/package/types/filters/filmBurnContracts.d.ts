export type FilmBurnDamage = {
    heat: number;
    blister: number;
    core: number;
};
/** Bounded radial material zones around an irregular projector-burn front. */
export declare const filmBurnDamage: (normalizedDistance: number, intensity: number, roughnessSample?: number) => FilmBurnDamage;
