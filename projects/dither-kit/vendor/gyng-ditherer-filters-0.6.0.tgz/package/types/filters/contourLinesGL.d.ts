export declare const contourLinesGLAvailable: () => boolean;
export type ContourFillMode = 0 | 1 | 2;
export declare const renderContourLinesGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, levels: number, lineWidth: number, lineColor: [number, number, number], fillMode: ContourFillMode) => HTMLCanvasElement | OffscreenCanvas | null;
