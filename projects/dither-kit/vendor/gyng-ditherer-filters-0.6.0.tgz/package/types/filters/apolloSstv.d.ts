import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    bandwidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    phosphorPersistence: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    vidiconLag: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    vidiconBloom: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    discHold: {
        type: string;
        default: boolean;
        desc: string;
    };
    interlace: {
        type: string;
        default: boolean;
        desc: string;
    };
    rfNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    syncError: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    randomSeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    mode: string;
    bandwidth: number;
    phosphorPersistence: number;
    vidiconLag: number;
    vidiconBloom: number;
    discHold: boolean;
    interlace: boolean;
    rfNoise: number;
    syncError: number;
    randomSeed: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
export declare const apolloFramesPerPicture: (mode: unknown, previewRate: unknown) => number;
export interface ApolloTiming {
    pictureIndex: number;
    picturePhase: number;
    newPicture: boolean;
}
export declare const apolloTiming: (mode: unknown, previewRate: unknown, frameIndex: unknown) => ApolloTiming;
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
