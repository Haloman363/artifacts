export declare const MAX_KW = 5;
export declare const convolveGLAvailable: () => boolean;
export declare const renderConvolveGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, matrix: (number | null | undefined)[][], kWidth: number, linearize: boolean) => HTMLCanvasElement | OffscreenCanvas | null;
