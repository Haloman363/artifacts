export declare const COLOR_SPACE: {
    readonly LAB: "LAB";
    readonly RGB: "RGB";
};
export declare const optionTypes: {
    k: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    iterations: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sampleRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    colorSpace: {
        type: string;
        options: ({
            name: string;
            value: "LAB";
        } | {
            name: string;
            value: "RGB";
        })[];
        default: "LAB";
        desc: string;
    };
    seed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    k: number;
    iterations: number;
    sampleRate: number;
    colorSpace: "LAB";
    seed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
