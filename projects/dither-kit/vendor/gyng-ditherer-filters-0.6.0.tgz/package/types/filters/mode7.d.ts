export declare const optionTypes: {
    fly: {
        type: string;
        label: string;
        default: boolean;
        desc: string;
    };
    forwardSpeed: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => any;
    };
    strafeSpeed: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => any;
    };
    liftSpeed: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => any;
    };
    animSpeed: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
    horizon: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    fov: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    pitch: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    yaw: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    roll: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cameraX: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cameraY: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cameraZ: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    tile: {
        type: string;
        label: string;
        default: boolean;
        desc: string;
    };
    sky: {
        type: string;
        label: string;
        default: boolean;
        desc: string;
    };
    skyStyle: {
        type: string;
        label: string;
        default: string;
        options: {
            name: string;
            value: string;
        }[];
        desc: string;
        visibleWhen: (options: any) => any;
    };
    skyGlow: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => any;
    };
    skyBands: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => any;
    };
    skyTwist: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => any;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    horizon: number;
    fov: number;
    cameraX: number;
    cameraY: number;
    cameraZ: number;
    pitch: number;
    tile: boolean;
    fly: boolean;
    forwardSpeed: number;
    strafeSpeed: number;
    liftSpeed: number;
    yaw: number;
    roll: number;
    sky: boolean;
    skyStyle: string;
    skyGlow: number;
    skyBands: number;
    skyTwist: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
