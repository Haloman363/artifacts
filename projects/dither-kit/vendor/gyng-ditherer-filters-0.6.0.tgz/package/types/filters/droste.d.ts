export declare const optionTypes: {
    twist: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    rInner: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    rOuter: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    angle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    twist: number;
    rInner: number;
    rOuter: number;
    angle: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
