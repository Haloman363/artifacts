export declare const optionTypes: {
    depth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    strata: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cracks: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    mineral: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lightAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    stoneColor: {
        type: string;
        default: number[];
        desc: string;
    };
    fossilColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    depth: number;
    strata: number;
    cracks: number;
    mineral: number;
    lightAngle: number;
    stoneColor: number[];
    fossilColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
