export declare const edgeGlowGLAvailable: () => boolean;
export declare const renderEdgeGlowGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, threshold: number, glowRadius: number, edgeColor: [number, number, number], backgroundColor: [number, number, number], levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
