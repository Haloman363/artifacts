export declare const optionTypes: {
    gateWeave: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    grain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dustAmount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    scratchAmount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flicker: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    vignette: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    warmth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bloom: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bloomRadius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    gateWeave: number;
    grain: number;
    dustAmount: number;
    scratchAmount: number;
    flicker: number;
    vignette: number;
    warmth: number;
    bloom: number;
    bloomRadius: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
