export declare const renderVintageTVGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, params: {
    banding: number;
    colorFringe: number;
    chromaBandwidth: number;
    tuningError: number;
    rollOffset: number;
    frameIndex: number;
    fieldRate: number;
    fieldLines: number;
    scanlineStrength: number;
    glow: number;
    rfNoise: number;
}) => HTMLCanvasElement | OffscreenCanvas | null;
