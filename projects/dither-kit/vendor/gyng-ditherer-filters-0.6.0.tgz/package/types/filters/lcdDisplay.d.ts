export declare const optionTypes: {
    pixelSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    subpixelLayout: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    brightness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gapDarkness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    pixelSize: number;
    subpixelLayout: string;
    brightness: number;
    gapDarkness: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
