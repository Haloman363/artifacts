export declare const optionTypes: {
    hueCenter: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    hueRange: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    saturationMin: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    hueCenter: number;
    hueRange: number;
    saturationMin: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
