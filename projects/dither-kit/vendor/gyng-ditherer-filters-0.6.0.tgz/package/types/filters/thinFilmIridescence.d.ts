export declare const optionTypes: {
    thickness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    variation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ior: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lightAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    intensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    roughness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    driftSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    thickness: number;
    variation: number;
    ior: number;
    lightAngle: number;
    intensity: number;
    roughness: number;
    driftSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
