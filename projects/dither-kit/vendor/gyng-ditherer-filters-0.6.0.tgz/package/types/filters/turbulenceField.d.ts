/** Smooth value noise in [0,1] over a unit lattice. */
export declare const valueNoise: (x: number, y: number) => number;
/**
 * Divergence-free curl of the value-noise potential at (x, y):
 * v = (∂ψ/∂y, −∂ψ/∂x), estimated by central differences with step `eps`.
 */
export declare const curlNoise: (x: number, y: number, eps?: number) => [number, number];
/**
 * Discrete divergence of the curl field at (x, y). Uses the SAME step for the
 * inner curl gradient and the outer divergence difference, so the mixed second
 * differences cancel exactly for a curl field (~0). A gradient/curl-free field
 * would instead evaluate to the Laplacian (non-zero) — which is the point.
 */
export declare const curlDivergence: (x: number, y: number, h?: number) => number;
export declare const TURBULENCE_GLSL = "\nfloat tf_hash2(vec2 p) {\n  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);\n}\nfloat tf_valueNoise(vec2 p) {\n  vec2 i = floor(p);\n  vec2 f = p - i;\n  float a = tf_hash2(i);\n  float b = tf_hash2(i + vec2(1.0, 0.0));\n  float c = tf_hash2(i + vec2(0.0, 1.0));\n  float d = tf_hash2(i + vec2(1.0, 1.0));\n  vec2 u = f * f * (3.0 - 2.0 * f);\n  return a + (b - a) * u.x + (c - a) * u.y + (a - b - c + d) * u.x * u.y;\n}\n// Divergence-free curl of the noise potential.\nvec2 tf_curlNoise(vec2 p, float eps) {\n  float e = max(1e-3, eps);\n  float dpdx = (tf_valueNoise(p + vec2(e, 0.0)) - tf_valueNoise(p - vec2(e, 0.0))) / (2.0 * e);\n  float dpdy = (tf_valueNoise(p + vec2(0.0, e)) - tf_valueNoise(p - vec2(0.0, e))) / (2.0 * e);\n  return vec2(dpdy, -dpdx);\n}\n";
