export declare const spherizeGLAvailable: () => boolean;
export declare const renderSpherizeGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, strength: number, centerX: number, centerY: number, radius: number, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
