import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    blackPoint: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    whitePoint: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gamma: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    outputBlack: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    outputWhite: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    blackPoint: number;
    whitePoint: number;
    gamma: number;
    outputBlack: number;
    outputWhite: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
type LevelsOptions = FilterOptionValues & typeof defaults & {
    _linearize?: boolean;
};
declare const _default: import("./types").FilterDefinition<LevelsOptions>;
export default _default;
