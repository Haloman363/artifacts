export declare const MAX_DUST = 64;
export declare const MAX_SCRATCH = 16;
export declare const projectionFilmGLAvailable: () => boolean;
export type DustSpec = {
    x: number;
    y: number;
    radius: number;
    opacity: number;
};
export type ScratchSpec = {
    x: number;
    opacity: number;
    polarity: number;
    width: number;
    yStart: number;
    yEnd: number;
    wobble: number;
    phase: number;
};
export declare const renderProjectionFilmGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, params: {
    weaveX: number;
    weaveY: number;
    warmth: number;
    flickerMul: number;
    grain: number;
    grainSeed: number;
    vignette: number;
    dust: DustSpec[];
    scratches: ScratchSpec[];
    bloom: number;
    bloomRadius: number;
    levels: number;
}) => HTMLCanvasElement | OffscreenCanvas | null;
