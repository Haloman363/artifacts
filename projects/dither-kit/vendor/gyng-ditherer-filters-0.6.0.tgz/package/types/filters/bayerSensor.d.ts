export declare const optionTypes: {
    cfa: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    method: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    sensorNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    readNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    hotPixels: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    colorBleed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    opticalBlur: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    cfa: string;
    method: string;
    sensorNoise: number;
    readNoise: number;
    hotPixels: number;
    colorBleed: number;
    opticalBlur: number;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
