import { type FilterOptionValues } from "./types";
type MatrixRainPalette = {
    options?: FilterOptionValues;
} & Record<string, unknown>;
type MatrixRainOptions = FilterOptionValues & {
    columnWidth?: number;
    columnSizeVariation?: number;
    characterSizeVariation?: number;
    characterFlip?: number;
    speed?: number;
    trailLength?: number;
    density?: number;
    columnOverlap?: number;
    charset?: string;
    customCharset?: string;
    sourceInfluence?: number;
    classicGreen?: boolean;
    motionMode?: string;
    motionSensitivity?: number;
    motionDropStrength?: number;
    animSpeed?: number;
    palette?: MatrixRainPalette;
    _frameIndex?: number;
    _ema?: Float32Array | null;
};
export declare const optionTypes: {
    columnWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    columnSizeVariation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    characterSizeVariation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    characterFlip: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    speed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    trailLength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    density: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    columnOverlap: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    charset: {
        type: string;
        options: ({
            readonly label: "Featured";
            readonly options: readonly [{
                readonly name: "Matrix film";
                readonly value: "MATRIX_FILM";
            }];
        } | {
            readonly label: "Languages & Scripts";
            readonly options: readonly [{
                readonly name: "Japanese kana";
                readonly value: "JAPANESE";
            }, {
                readonly name: "Hiragana stream";
                readonly value: "HIRAGANA";
            }, {
                readonly name: "Chinese hanzi";
                readonly value: "CHINESE";
            }, {
                readonly name: "Kanji ledger";
                readonly value: "KANJI_LEDGER";
            }, {
                readonly name: "Cyrillic broadcast";
                readonly value: "CYRILLIC";
            }, {
                readonly name: "Hebrew scroll";
                readonly value: "HEBREW";
            }, {
                readonly name: "Arabic signal";
                readonly value: "ARABIC";
            }, {
                readonly name: "Devanagari mantra";
                readonly value: "DEVANAGARI";
            }, {
                readonly name: "Mongolian script";
                readonly value: "MONGOLIAN";
            }, {
                readonly name: "Hieroglyphs";
                readonly value: "HIEROGLYPHS";
            }, {
                readonly name: "Greek chorus";
                readonly value: "GREEK";
            }, {
                readonly name: "Thai loops";
                readonly value: "THAI";
            }, {
                readonly name: "Tibetan prayer flags";
                readonly value: "TIBETAN";
            }, {
                readonly name: "Georgian script";
                readonly value: "GEORGIAN";
            }, {
                readonly name: "Armenian manuscript";
                readonly value: "ARMENIAN";
            }, {
                readonly name: "Ethiopic script";
                readonly value: "ETHIOPIC";
            }, {
                readonly name: "Cherokee syllabary";
                readonly value: "CHEROKEE";
            }, {
                readonly name: "Ogham stave";
                readonly value: "OGHAM";
            }, {
                readonly name: "Oracle bones";
                readonly value: "ORACLE_BONES";
            }, {
                readonly name: "Manchu script";
                readonly value: "MANCHU";
            }, {
                readonly name: "Tifinagh";
                readonly value: "TIFINAGH";
            }];
        } | {
            readonly label: "Cinematic & Symbolic";
            readonly options: readonly [{
                readonly name: "Glitch sigils";
                readonly value: "GLITCH";
            }, {
                readonly name: "Cosmic dust";
                readonly value: "COSMIC";
            }, {
                readonly name: "Space signal";
                readonly value: "SPACE_SIGNAL";
            }, {
                readonly name: "Alien glyphs";
                readonly value: "ALIEN_GLYPHS";
            }, {
                readonly name: "Emoji parade";
                readonly value: "EMOJI";
            }, {
                readonly name: "Astrology chart";
                readonly value: "ASTROLOGY";
            }, {
                readonly name: "Tarot spread";
                readonly value: "TAROT";
            }, {
                readonly name: "Hazard tape";
                readonly value: "HAZARD";
            }, {
                readonly name: "Star map";
                readonly value: "STAR_MAP";
            }, {
                readonly name: "Alchemy expanded";
                readonly value: "ALCHEMY_EXPANDED";
            }, {
                readonly name: "Weather extended";
                readonly value: "WEATHER_EXTENDED";
            }];
        } | {
            readonly label: "Technical";
            readonly options: readonly [{
                readonly name: "Terminal static";
                readonly value: "TERMINAL";
            }, {
                readonly name: "Hex dump";
                readonly value: "HEX";
            }, {
                readonly name: "Blueprint markup";
                readonly value: "BLUEPRINT";
            }, {
                readonly name: "Circuit traces";
                readonly value: "CIRCUIT";
            }, {
                readonly name: "Transit map";
                readonly value: "TRANSIT";
            }, {
                readonly name: "Weather radar";
                readonly value: "WEATHER";
            }, {
                readonly name: "Box drawing";
                readonly value: "BOX_DRAWING";
            }, {
                readonly name: "Block elements";
                readonly value: "BLOCK_ELEMENTS";
            }, {
                readonly name: "Braille grid";
                readonly value: "BRAILLE";
            }, {
                readonly name: "ASCII portrait";
                readonly value: "ASCII_ART";
            }, {
                readonly name: "OCR scanline";
                readonly value: "OCR";
            }, {
                readonly name: "Binary control room";
                readonly value: "BINARY_CONTROL";
            }, {
                readonly name: "Subway signage";
                readonly value: "SUBWAY_SIGNAGE";
            }, {
                readonly name: "Schematics";
                readonly value: "SCHEMATICS";
            }, {
                readonly name: "Glitched UI";
                readonly value: "GLITCH_UI";
            }, {
                readonly name: "UI wireframe";
                readonly value: "UI_WIREFRAME";
            }, {
                readonly name: "Rail timetable";
                readonly value: "RAIL_TIMETABLE";
            }, {
                readonly name: "Barcode scanner";
                readonly value: "BARCODE_SCANNER";
            }, {
                readonly name: "Teletext mosaic";
                readonly value: "TELETEXT";
            }, {
                readonly name: "Industrial stencil";
                readonly value: "INDUSTRIAL_STENCIL";
            }, {
                readonly name: "Legacy computing";
                readonly value: "LEGACY_COMPUTING";
            }];
        } | {
            readonly label: "Mojibake & Corruption";
            readonly options: readonly [{
                readonly name: "Mojibake spill";
                readonly value: "MOJIBAKE";
            }, {
                readonly name: "UTF-8 as Latin-1";
                readonly value: "MOJIBAKE_UTF8_LATIN1";
            }, {
                readonly name: "CP1252 fallout";
                readonly value: "MOJIBAKE_CP1252";
            }, {
                readonly name: "Replacement soup";
                readonly value: "MOJIBAKE_REPLACEMENT";
            }, {
                readonly name: "Shift-JIS wreckage";
                readonly value: "MOJIBAKE_SHIFT_JIS";
            }, {
                readonly name: "Half-width panic";
                readonly value: "MOJIBAKE_HALF_WIDTH";
            }, {
                readonly name: "JP UTF-8 spill";
                readonly value: "MOJIBAKE_JP_UTF8";
            }, {
                readonly name: "Double-decoded ruin";
                readonly value: "MOJIBAKE_DOUBLE_DECODE";
            }, {
                readonly name: "Entity leak";
                readonly value: "MOJIBAKE_ENTITY_LEAK";
            }, {
                readonly name: "Forum export hell";
                readonly value: "MOJIBAKE_FORUM_EXPORT";
            }, {
                readonly name: "Control rot";
                readonly value: "MOJIBAKE_CONTROL_ROT";
            }, {
                readonly name: "CSV in Excel ruin";
                readonly value: "MOJIBAKE_CSV_EXCEL";
            }, {
                readonly name: "XML parser scream";
                readonly value: "MOJIBAKE_XML_SCREAM";
            }, {
                readonly name: "Broken subtitle rip";
                readonly value: "MOJIBAKE_SUBTITLE_RIP";
            }, {
                readonly name: "Email header poison";
                readonly value: "MOJIBAKE_EMAIL_HEADER";
            }, {
                readonly name: "PDF copy rot";
                readonly value: "MOJIBAKE_PDF_COPY";
            }, {
                readonly name: "Terminal bleed";
                readonly value: "MOJIBAKE_TERMINAL_BLEED";
            }, {
                readonly name: "Zalgo export";
                readonly value: "MOJIBAKE_ZALGO_EXPORT";
            }];
        } | {
            readonly label: "Abstract & Encoded";
            readonly options: readonly [{
                readonly name: "Minimal drizzle";
                readonly value: "MINIMAL";
            }, {
                readonly name: "Ticker tape";
                readonly value: "TICKER";
            }, {
                readonly name: "Rune storm";
                readonly value: "RUNES";
            }, {
                readonly name: "Legal boilerplate";
                readonly value: "LEGAL";
            }, {
                readonly name: "Alchemy table";
                readonly value: "ALCHEMY";
            }, {
                readonly name: "Arrow storm";
                readonly value: "ARROWS";
            }, {
                readonly name: "Math notebook";
                readonly value: "MATH";
            }, {
                readonly name: "Currency board";
                readonly value: "CURRENCY";
            }, {
                readonly name: "Music notation";
                readonly value: "MUSIC";
            }, {
                readonly name: "DNA lab";
                readonly value: "DNA_LAB";
            }, {
                readonly name: "Pixel debris";
                readonly value: "PIXEL_DEBRIS";
            }, {
                readonly name: "Ancient numerals";
                readonly value: "ANCIENT_NUMERALS";
            }, {
                readonly name: "Cuneiform shard";
                readonly value: "CUNEIFORM";
            }, {
                readonly name: "Morse signal";
                readonly value: "MORSE_SIGNAL";
            }, {
                readonly name: "Map symbols";
                readonly value: "MAP_SYMBOLS";
            }, {
                readonly name: "Yijing hexagrams";
                readonly value: "YIJING";
            }, {
                readonly name: "Byzantine musical";
                readonly value: "BYZANTINE_MUSIC";
            }];
        } | {
            readonly label: "Games & Glyphs";
            readonly options: readonly [{
                readonly name: "Chess match";
                readonly value: "CHESS";
            }, {
                readonly name: "Mahjong wall";
                readonly value: "MAHJONG";
            }, {
                readonly name: "Playing cards";
                readonly value: "PLAYING_CARDS";
            }, {
                readonly name: "Dice tabletop";
                readonly value: "DICE_TABLETOP";
            }, {
                readonly name: "Domino rally";
                readonly value: "DOMINOES";
            }];
        } | {
            label: string;
            options: {
                name: string;
                value: string;
            }[];
        })[];
        default: "MATRIX_FILM";
        desc: string;
    };
    editSelectedCharset: {
        type: string;
        label: string;
        visibleWhen: (options: FilterOptionValues) => boolean;
        action: (actions: any, _inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    customCharset: {
        type: string;
        default: string;
        visibleWhen: (options: FilterOptionValues) => boolean;
        desc: string;
    };
    sourceInfluence: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    classicGreen: {
        type: string;
        default: boolean;
        desc: string;
    };
    motionMode: {
        type: string;
        options: ({
            name: string;
            value: "GATE";
        } | {
            name: string;
            value: "TRIGGER_DROPS";
        })[];
        default: "TRIGGER_DROPS";
        desc: string;
    };
    motionSensitivity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    motionDropStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    columnWidth: number;
    columnSizeVariation: number;
    characterSizeVariation: number;
    characterFlip: number;
    speed: number;
    trailLength: number;
    density: number;
    columnOverlap: number;
    charset: "MATRIX_FILM";
    customCharset: string;
    sourceInfluence: number;
    classicGreen: boolean;
    motionMode: "TRIGGER_DROPS";
    motionSensitivity: number;
    motionDropStrength: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const sampleBitmapAlpha: (bitmap: Uint8Array, bitmapCellSize: number, srcX: number, srcY: number, transformMode: number) => number;
export declare const __testing: {
    sampleBitmapAlpha: typeof sampleBitmapAlpha;
};
declare const _default: import("./types").FilterDefinition<MatrixRainOptions>;
export default _default;
