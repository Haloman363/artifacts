export declare const MAX_PALETTE = 96;
export declare const paletteIndexDriftGLAvailable: () => boolean;
export declare const renderPaletteIndexDriftGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, palette: number[][], driftMap: number[], lockLuma: boolean, dither: boolean, ditherSeed: number) => HTMLCanvasElement | OffscreenCanvas | null;
