/** P1 (o): pure translation. */
export declare const foldP1: (x: number, y: number, sz: number) => [number, number];
/**
 * P2 (2222): 180° rotation, NO mirror lines. Cell is 2·sz × sz; the right half
 * is the 180° rotation of the left about (sz, sz/2), so both coordinates
 * transform together (a rotation) — unlike PMM which reflects each axis.
 */
export declare const foldP2: (x: number, y: number, sz: number) => [number, number];
/** PMM (*2222): mirror lines on both axes. */
export declare const foldPMM: (x: number, y: number, sz: number) => [number, number];
/** P4M (*442): square kaleidoscope — mirrors on both axes plus the diagonal. */
export declare const foldP4M: (x: number, y: number, sz: number) => [number, number];
/**
 * P6M (*632): hexagonal 6-fold + mirror kaleidoscope. Reduce to the nearest
 * 6-fold centre on the triangular lattice, then fold the offset angle into a 30°
 * wedge (6 rotations × mirror = the D6 point group). The result is invariant
 * under 60° rotation, a mirror, and the hex lattice translations.
 */
export declare const foldP6M: (x: number, y: number, sz: number) => [number, number];
export declare const WALLPAPER_FOLDS_GLSL = "\nfloat wf_modPos(float v, float m) { float r = mod(v, m); return r < 0.0 ? r + m : r; }\nfloat wf_foldReflect(float v, float sz) {\n  float m = wf_modPos(v, 2.0 * sz);\n  return m < sz ? m : 2.0 * sz - m;\n}\nvec2 wf_p1(vec2 p, float sz) { return vec2(wf_modPos(p.x, sz), wf_modPos(p.y, sz)); }\nvec2 wf_p2(vec2 p, float sz) {\n  float fx = wf_modPos(p.x, 2.0 * sz);\n  float fy = wf_modPos(p.y, sz);\n  if (fx >= sz) { fx = 2.0 * sz - fx; fy = sz - fy; }\n  return vec2(fx, fy);\n}\nvec2 wf_pmm(vec2 p, float sz) { return vec2(wf_foldReflect(p.x, sz), wf_foldReflect(p.y, sz)); }\nvec2 wf_p4m(vec2 p, float sz) {\n  float fx = wf_foldReflect(p.x, sz);\n  float fy = wf_foldReflect(p.y, sz);\n  if (fy > fx) { float t = fx; fx = fy; fy = t; }\n  return vec2(fx, fy);\n}\nvec2 wf_p6m(vec2 p, float sz) {\n  const float S3 = 1.7320508075688772;\n  float q = (p.x - p.y / S3) / sz;\n  float r = (p.y * 2.0 / S3) / sz;\n  // hex round (cube)\n  float cx3 = q, cz3 = r, cy3 = -q - r;\n  float rx = floor(cx3 + 0.5), ry = floor(cy3 + 0.5), rz = floor(cz3 + 0.5);\n  float dx3 = abs(rx - cx3), dy3 = abs(ry - cy3), dz3 = abs(rz - cz3);\n  if (dx3 > dy3 && dx3 > dz3) rx = -ry - rz;\n  else if (dy3 > dz3) ry = -rx - rz;\n  else rz = -rx - ry;\n  float cq = rx, cr = rz;\n  float cx = (cq + cr / 2.0) * sz;\n  float cy = (cr * S3 / 2.0) * sz;\n  vec2 d = p - vec2(cx, cy);\n  float rr = length(d);\n  float a = rr > 0.0 ? atan(d.y, d.x) : 0.0;   // atan(0,0) is spec-undefined\n  a = wf_modPos(a, 3.14159265358979 / 3.0);\n  a = abs(a - 3.14159265358979 / 6.0);\n  return vec2(min(sz, rr * cos(a) * S3), min(sz, rr * sin(a) * 2.0 * S3));\n}\n";
