import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    resolution: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    contrast: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    exposure: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bias: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    invertSensor: {
        type: string;
        default: boolean;
        desc: string;
    };
    edgeMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    edgeEnhance: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    kernelP: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    kernelM: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    kernelX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sensorNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    randomSeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ditherStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    resolution: number;
    contrast: number;
    exposure: number;
    gain: number;
    bias: number;
    invertSensor: boolean;
    edgeMode: string;
    edgeEnhance: number;
    kernelP: number;
    kernelM: number;
    kernelX: number;
    sensorNoise: number;
    randomSeed: number;
    ditherStrength: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
/** The cartridge discards eight rows at each end of the 128x128 sensor transfer. */
export declare const resolveGameboySensorGrid: (requestedResolution: unknown) => {
    width: number;
    height: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
