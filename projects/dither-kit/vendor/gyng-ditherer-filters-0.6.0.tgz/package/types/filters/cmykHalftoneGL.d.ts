export declare const cmykHalftoneGLAvailable: () => boolean;
export declare const renderCmykHalftoneGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, dotSize: number, angleC: number, angleM: number, angleY: number, angleK: number, paperColor: [number, number, number]) => HTMLCanvasElement | OffscreenCanvas | null;
