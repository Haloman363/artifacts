import { type FilterOptionValues } from "./types";
export declare const SHARPEN_3X3 = "SHARPEN_3X3";
export declare const UNSHARP_5X5 = "UNSHARP_5X5";
export declare const GAUSSIAN_3X3 = "GAUSSIAN_3X3";
export declare const GAUSSIAN_3X3_WEAK = "GAUSSIAN_3X3_WEAK";
export declare const GAUSSIAN_5X5 = "GAUSSIAN_5X5";
export declare const EMBOSS_3X3 = "EMBOSS_3X3";
export declare const LAPLACIAN_3X3 = "LAPLACIAN_3X3";
export declare const LAPLACIAN_5X5 = "LAPLACIAN_5X5";
export declare const BRIGHTEN_0_5X = "BRIGHTEN_0_5X";
export declare const BRIGHTEN_2X = "BRIGHTEN_2X";
export declare const SOBEL_HORIZONTAL = "SOBEL_HORIZONTAL";
export declare const SOBEL_VERTICAL = "SOBEL_VERTICAL";
export declare const OUTLINE_3X3 = "OUTLINE_3X3";
export declare const kernels: {
    SHARPEN_3X3: {
        width: number;
        matrix: number[][];
    };
    UNSHARP_5X5: {
        width: number;
        matrix: (number | null)[][];
    };
    GAUSSIAN_3X3: {
        width: number;
        matrix: (number | null)[][];
        separable: {
            row: number[];
            col: number[];
        };
    };
    GAUSSIAN_3X3_WEAK: {
        width: number;
        matrix: (number | null)[][];
    };
    GAUSSIAN_5X5: {
        width: number;
        matrix: (number | null)[][];
        separable: {
            row: number[];
            col: number[];
        };
    };
    BRIGHTEN_2X: {
        width: number;
        matrix: number[][];
    };
    BRIGHTEN_0_5X: {
        width: number;
        matrix: number[][];
    };
    EMBOSS_3X3: {
        width: number;
        matrix: number[][];
    };
    LAPLACIAN_3X3: {
        width: number;
        matrix: number[][];
    };
    LAPLACIAN_5X5: {
        width: number;
        matrix: number[][];
    };
    SOBEL_HORIZONTAL: {
        width: number;
        matrix: number[][];
    };
    SOBEL_VERTICAL: {
        width: number;
        matrix: number[][];
    };
    OUTLINE_3X3: {
        width: number;
        matrix: number[][];
    };
};
export declare const optionTypes: {
    kernel: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    kernel: string;
    strength: number;
};
type ConvolveOptions = FilterOptionValues & typeof defaults & {
    _linearize?: boolean;
};
declare const _default: import("./types").FilterDefinition<ConvolveOptions>;
export default _default;
