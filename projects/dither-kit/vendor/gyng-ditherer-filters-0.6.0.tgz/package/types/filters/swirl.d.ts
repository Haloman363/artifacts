export declare const optionTypes: {
    angle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    radius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    centerX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    centerY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    angle: number;
    radius: number;
    centerX: number;
    centerY: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
