import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    ghostMix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    persistence: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flash: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cadenceDrift: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    ghostMix: number;
    persistence: number;
    flash: number;
    cadenceDrift: number;
    animSpeed: number;
};
type AbaGhostOptions = FilterOptionValues & typeof defaults & {
    _frameIndex?: number;
};
declare const _default: import("./types").FilterDefinition<AbaGhostOptions>;
export default _default;
