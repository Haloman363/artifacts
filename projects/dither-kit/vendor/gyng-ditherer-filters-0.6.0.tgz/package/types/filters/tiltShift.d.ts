export declare const optionTypes: {
    focusPosition: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    focusWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    blurAmount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    saturationBoost: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    focusPosition: number;
    focusWidth: number;
    blurAmount: number;
    saturationBoost: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
