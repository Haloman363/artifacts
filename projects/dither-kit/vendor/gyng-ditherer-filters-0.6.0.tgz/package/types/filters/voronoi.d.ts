export declare const optionTypes: {
    cells: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    seed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    cells: number;
    seed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
type VoronoiSeed = {
    x: number;
    y: number;
};
export declare const findNearestVoronoiSeed: (x: number, y: number, seeds: readonly VoronoiSeed[], width: number, height: number) => number;
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
