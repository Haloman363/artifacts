import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    display: {
        type: string;
        options: ({
            name: string;
            value: "WAVEFORM";
        } | {
            name: string;
            value: "TRACE";
        } | {
            name: string;
            value: "PARADE";
        })[];
        default: "WAVEFORM";
        desc: string;
    };
    phosphor: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    beamWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    intensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bloom: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bloomStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    persistence: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    graticule: {
        type: string;
        default: boolean;
        desc: string;
    };
    graticuleDivs: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    noiseFloor: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    display: "WAVEFORM";
    phosphor: string;
    beamWidth: number;
    intensity: number;
    bloom: number;
    bloomStrength: number;
    persistence: number;
    graticule: boolean;
    graticuleDivs: number;
    noiseFloor: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
