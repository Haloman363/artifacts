export declare const optionTypes: {
    fractal: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    power: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    iterations: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    detail: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    yaw: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    pitch: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    zoom: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    materialMix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    rotateSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    background: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    fractal: string;
    power: number;
    iterations: number;
    detail: number;
    yaw: number;
    pitch: number;
    zoom: number;
    materialMix: number;
    rotateSpeed: number;
    background: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
