export declare const optionTypes: {
    dotSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        label: string;
        desc: string;
    };
    levels: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    saturationBoost: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    screenAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    paperColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    dotSize: number;
    levels: number;
    saturationBoost: number;
    screenAngle: number;
    paperColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
export type PopArtSpotGeometry = {
    mode: "DOT" | "HOLE";
    radius: number;
};
export declare const popArtSpotGeometry: (darkness: number, pitch: number) => PopArtSpotGeometry;
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
