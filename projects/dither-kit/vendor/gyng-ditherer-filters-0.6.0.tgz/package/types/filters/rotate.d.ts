import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    angle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    spinPerFrame: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bgColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
};
export declare const defaults: {
    angle: number;
    spinPerFrame: number;
    bgColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
    animSpeed: number;
};
type RotateOptions = FilterOptionValues & {
    angle?: number;
    spinPerFrame?: number;
    bgColor?: number[];
    animSpeed?: number;
    palette?: {
        options?: FilterOptionValues;
    } & Record<string, unknown>;
    _frameIndex?: number;
    _webglAcceleration?: boolean;
};
declare const _default: import("./types").FilterDefinition<RotateOptions>;
export default _default;
