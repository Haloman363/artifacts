export declare const optionTypes: {
    tapeSpeed: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    fieldMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    filterType: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    demodulation: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    compositeSharpness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    compositeNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    snow: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    snowAnisotropy: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    headSwitching: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    headSwitchingHeight: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    trackingNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    trackingHeight: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeWave: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lumaSmear: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    tapeSharpness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ringing: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ringingFrequency: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ringingPower: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lumaNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    chromaNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    chromaPhaseNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    chromaPhaseError: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    chromaDelayH: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    chromaDelayV: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    chromaLoss: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    chromaVertBlend: {
        type: string;
        default: boolean;
        desc: string;
    };
    randomSeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    tapeSpeed: string;
    fieldMode: string;
    filterType: string;
    demodulation: string;
    compositeSharpness: number;
    compositeNoise: number;
    snow: number;
    snowAnisotropy: number;
    headSwitching: number;
    headSwitchingHeight: number;
    trackingNoise: number;
    trackingHeight: number;
    edgeWave: number;
    lumaSmear: number;
    tapeSharpness: number;
    ringing: number;
    ringingFrequency: number;
    ringingPower: number;
    lumaNoise: number;
    chromaNoise: number;
    chromaPhaseNoise: number;
    chromaPhaseError: number;
    chromaDelayH: number;
    chromaDelayV: number;
    chromaLoss: number;
    chromaVertBlend: boolean;
    randomSeed: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
