export declare const optionTypes: {
    iterations: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    kappa: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lambda: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    conductance: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    iterations: number;
    kappa: number;
    lambda: number;
    conductance: string;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
