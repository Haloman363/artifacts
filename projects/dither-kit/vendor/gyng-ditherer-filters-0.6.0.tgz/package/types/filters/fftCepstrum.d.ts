export declare const optionTypes: {
    scale: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    centred: {
        type: string;
        default: boolean;
        desc: string;
    };
    suppressDC: {
        type: string;
        default: boolean;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    scale: number;
    centred: boolean;
    suppressDC: boolean;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
