export declare const optionTypes: {};
export declare const defaults: {};
declare const _default: import("./types").FilterDefinition<{}>;
export default _default;
