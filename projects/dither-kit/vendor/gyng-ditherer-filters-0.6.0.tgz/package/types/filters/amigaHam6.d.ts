import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    standard: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    paletteMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    paletteIterations: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    standard: string;
    paletteMode: string;
    paletteIterations: number;
};
export declare const buildHam6Palette: (pixels: Uint8ClampedArray, iterations?: number) => Uint8Array;
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
