export type UnitRgb = readonly [number, number, number];
/**
 * Estimate a plausible near-infrared response from visible linear RGB.
 * This is deliberately a material-color heuristic, not spectral recovery.
 */
export declare const estimateVisibleNir: (rgb: UnitRgb, foliageResponse?: number, skySuppression?: number) => number;
/** Kodak-style color-infrared ordering: estimated NIR→R, visible R→G, visible G→B. */
export declare const aerochromeChannels: (rgb: UnitRgb, estimatedNir: number) => [number, number, number];
export declare const MEZZOTINT_ROCKER_ANGLES: readonly [0, 45, 90, 135];
/** True means the dark LCD state is active for this display-native pixel. */
export declare const lcdOrderedDecision: (luminance: number, x: number, y: number, threshold: number, ditherStrength: number) => boolean;
/** Continuous ink held by the rocked burr after scraping, burnishing, and wear. */
export declare const mezzotintInkCoverage: (luminance: number, density: number, burnish: number, plateWear: number) => number;
/** Direct-positive image-particle scatter, with gold toning increasing contrast. */
export declare const daguerreotypeScatter: (luminance: number, gilding: number) => number;
/** Broad mirror-field reflection from the polished plate at a chosen viewing angle. */
export declare const daguerreotypePlateReflection: (normalizedX: number, normalizedY: number, angleDegrees: number, metallic: number) => number;
