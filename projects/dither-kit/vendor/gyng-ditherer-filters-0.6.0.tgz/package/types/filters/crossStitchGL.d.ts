export declare const crossStitchGLAvailable: () => boolean;
export declare const renderCrossStitchGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, stitchSize: number, gapBetween: number, fabricColor: [number, number, number], threadModeIsPalette: boolean) => HTMLCanvasElement | OffscreenCanvas | null;
