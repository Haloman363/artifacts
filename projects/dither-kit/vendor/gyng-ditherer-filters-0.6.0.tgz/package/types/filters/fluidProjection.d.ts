/** Central-difference divergence of a velocity field (Neumann boundary). */
export declare const divergence: (vx: Float32Array, vy: Float32Array, w: number, h: number) => Float32Array;
/** Jacobi relaxation solving ∇²p = div, starting from p = 0 (Neumann BC). */
export declare const jacobiPressure: (div: Float32Array, w: number, h: number, iterations: number) => Float32Array;
/** Subtract the pressure gradient from the velocity: v ← v − ∇p. */
export declare const subtractGradient: (vx: Float32Array, vy: Float32Array, p: Float32Array, w: number, h: number) => {
    vx: Float32Array;
    vy: Float32Array;
};
/** Full projection: make the velocity field (approximately) divergence-free. */
export declare const projectVelocity: (vx: Float32Array, vy: Float32Array, w: number, h: number, iterations: number) => {
    vx: Float32Array;
    vy: Float32Array;
};
/** Largest absolute divergence over the interior (excluding the 1px border). */
export declare const maxInteriorDivergence: (vx: Float32Array, vy: Float32Array, w: number, h: number) => number;
