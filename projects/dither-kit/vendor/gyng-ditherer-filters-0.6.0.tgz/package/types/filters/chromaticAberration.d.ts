export declare const optionTypes: {
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    angle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    radial: {
        type: string;
        default: boolean;
        desc: string;
    };
    rOffsetX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    rOffsetY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gOffsetX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gOffsetY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bOffsetX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bOffsetY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    mode: string;
    strength: number;
    angle: number;
    radial: boolean;
    rOffsetX: number;
    rOffsetY: number;
    gOffsetX: number;
    gOffsetY: number;
    bOffsetX: number;
    bOffsetY: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
