export declare const optionTypes: {
    structureScale: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    shadowThreshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    highlightThreshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    shadowSteps: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    highlightSteps: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeSoftness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bandBias: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    shadowTint: {
        type: string;
        default: number[];
        desc: string;
    };
    highlightTint: {
        type: string;
        default: number[];
        desc: string;
    };
    colorSeparation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    preserveSkin: {
        type: string;
        default: boolean;
        desc: string;
    };
    mix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    structureScale: number;
    shadowThreshold: number;
    highlightThreshold: number;
    shadowSteps: number;
    highlightSteps: number;
    edgeSoftness: number;
    bandBias: number;
    shadowTint: number[];
    highlightTint: number[];
    colorSeparation: number;
    preserveSkin: boolean;
    mix: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
