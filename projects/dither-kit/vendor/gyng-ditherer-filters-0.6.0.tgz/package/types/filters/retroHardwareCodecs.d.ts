/** Pure storage/display codecs shared by the hardware simulation filters. */
export declare const APPLE_HGR_COLORS: {
    black: number[];
    white: number[];
    purple: number[];
    green: number[];
    blue: number[];
    orange: number[];
};
export declare const decodeAppleHgrDots: (bits: Uint8Array, bytePhases: Uint8Array) => Uint8ClampedArray;
export declare const spectrumColor: (index: number, bright: boolean) => number[];
/**
 * The 50 Hz ULA swaps flashing attributes every 16 frames, so a complete
 * normal → inverse → normal cycle lasts 32 frames (about 0.64 seconds).
 */
export declare const spectrumFlashPhase: (frameIndex: number, previewFps: number) => number;
export type SpectrumAttribute = {
    ink: number;
    paper: number;
    bright: boolean;
    bitmap: Uint8Array;
};
export declare const chooseSpectrumAttribute: (source: Uint8Array) => SpectrumAttribute;
export declare const HAM6_OP: {
    readonly DIRECT: 0;
    readonly BLUE: 1;
    readonly RED: 2;
    readonly GREEN: 3;
};
export declare const decodeHam6Scanline: (codes: Uint8Array, palette: Uint8Array) => Uint8ClampedArray;
export type Ham6Encoding = {
    codes: Uint8Array;
    output: Uint8ClampedArray;
};
export declare const encodeHam6Scanline: (source: Uint8Array, palette: Uint8Array) => Ham6Encoding;
export type PxlTiming = {
    captureIndex: number;
    newCapture: boolean;
};
export declare const pxlTiming: (frameIndex: number, previewFps: number) => PxlTiming;
