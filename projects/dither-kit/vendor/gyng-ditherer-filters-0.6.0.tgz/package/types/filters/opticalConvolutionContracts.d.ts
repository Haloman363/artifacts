export declare const clamp01: (value: number) => number;
/** Gaussian sigma for a truncated kernel of the given pixel radius (r ≈ 3σ). */
export declare const sigmaForRadius: (radius: number) => number;
/** Single Gaussian weight exp(-k²/2σ²) (un-normalised). */
export declare const gaussianWeight: (k: number, sigma: number) => number;
/**
 * Normalised 1-D Gaussian kernel over taps [-radius, radius]. Sums to 1, is
 * symmetric, and (for σ>0) decreases away from the centre — the separable
 * low-pass that defines a Gaussian blur and, by difference, the unsharp mask.
 */
export declare const gaussianKernel1D: (radius: number, sigma?: number) => number[];
/** Median of a numeric list (mid element of the sorted copy). */
export declare const channelMedian: (values: number[]) => number;
/**
 * Edge-preserving despeckle pick: replace the centre value with the window
 * median only when it deviates from the median by more than `threshold`
 * (an impulse); otherwise keep it, so edges and detail survive.
 */
export declare const thresholdedMedianPick: (center: number, median: number, threshold: number) => number;
/**
 * Linear-light bright-pass response: energy above the threshold, soft-kneed so
 * the transition is not a hard step. Inputs and output are linear 0..1.
 */
export declare const brightPassLinear: (linearLuma: number, threshold: number) => number;
export declare const srgbToLinear: (c: number) => number;
export declare const linearToSrgb: (c: number) => number;
export declare const SRGB_GLSL = "\nvec3 oc_srgbToLinear(vec3 c) {\n  vec3 lo = c / 12.92;\n  vec3 hi = pow((c + 0.055) / 1.055, vec3(2.4));\n  return mix(lo, hi, step(vec3(0.04045), c));\n}\nvec3 oc_linearToSrgb(vec3 c) {\n  c = clamp(c, 0.0, 1.0);\n  vec3 lo = c * 12.92;\n  vec3 hi = 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055;\n  return mix(lo, hi, step(vec3(0.0031308), c));\n}\n";
