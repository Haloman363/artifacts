import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    feather: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    background: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
        visibleWhen: (options: BackgroundSubtractionOptions) => boolean;
    };
    bgColor: {
        type: string;
        default: number[];
        desc: string;
        visibleWhen: (options: BackgroundSubtractionOptions) => boolean;
    };
    learnRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: BackgroundSubtractionOptions) => boolean;
    };
    frozenFrame: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
        visibleWhen: (options: BackgroundSubtractionOptions) => boolean;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    mode: string;
    threshold: number;
    feather: number;
    background: string;
    bgColor: number[];
    learnRate: number;
    frozenFrame: string;
    animSpeed: number;
};
type BackgroundSubtractionOptions = FilterOptionValues & {
    mode?: string;
    threshold?: number;
    feather?: number;
    background?: string;
    bgColor?: number[];
    learnRate?: number;
    frozenFrame?: string;
    animSpeed?: number;
    _ema?: Float32Array | null;
    _frameIndex?: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
