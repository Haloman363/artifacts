import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    pattern: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    cellSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sourcePitch: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    angle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    chroma: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    opticalBlur: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    drift: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    pattern: string;
    cellSize: number;
    sourcePitch: number;
    angle: number;
    strength: number;
    chroma: number;
    opticalBlur: number;
    drift: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
