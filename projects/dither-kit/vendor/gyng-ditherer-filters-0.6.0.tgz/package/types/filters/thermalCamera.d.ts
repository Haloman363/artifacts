export declare const optionTypes: {
    colormap: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    level: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    span: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    contrast: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sensorWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    noiseAmount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    fixedPatternNoise: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    crosshair: {
        type: string;
        default: boolean;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    colormap: string;
    level: number;
    span: number;
    contrast: number;
    sensorWidth: number;
    noiseAmount: number;
    fixedPatternNoise: number;
    crosshair: boolean;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
