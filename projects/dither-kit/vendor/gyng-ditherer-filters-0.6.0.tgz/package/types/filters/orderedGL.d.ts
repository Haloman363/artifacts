export declare const MAX_PALETTE = 256;
export declare const orderedGLAvailable: () => boolean;
export declare const ORDERED_PAL_MODE: {
    readonly LEVELS: 0;
    readonly RGB: 1;
    readonly RGB_APPROX: 2;
    readonly HSV: 3;
    readonly LAB: 4;
    readonly OKLAB: 5;
};
export declare const renderOrderedGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, opts: {
    thresholdMap: number[][];
    thresholdMapKey: string;
    mapScaleX: number;
    mapScaleY: number;
    tempOffsetX: number;
    tempOffsetY: number;
    levels: number;
    paletteLevels: number;
    invertThreshold: boolean;
    linearize: boolean;
    palMode: number;
    paletteRgb: number[][] | null;
    labRef: [number, number, number];
}) => HTMLCanvasElement | OffscreenCanvas | null;
