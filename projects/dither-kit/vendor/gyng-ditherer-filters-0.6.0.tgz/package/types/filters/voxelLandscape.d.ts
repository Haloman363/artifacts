export declare const optionTypes: {
    cellSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    heightScale: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    pitch: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    yaw: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    fog: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sunAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    waterLevel: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    skyColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    cellSize: number;
    heightScale: number;
    pitch: number;
    yaw: number;
    fog: number;
    sunAngle: number;
    waterLevel: number;
    skyColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
