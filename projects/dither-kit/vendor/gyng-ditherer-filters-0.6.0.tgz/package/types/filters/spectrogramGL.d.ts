export declare const SPECTROGRAM_MAX_STOPS = 8;
export declare const SPECTROGRAM_GL_MAX_SIGNAL_LENGTH = 4096;
export declare const spectrogramGLAvailable: () => boolean;
export declare const renderSpectrogramGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, numBins: number, logScale: boolean, dynamicRange: number, stops: number[][], levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
