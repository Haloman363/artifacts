export declare const infraredGLAvailable: () => boolean;
export declare const renderInfraredGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, intensity: number, falseColor: number, foliageResponse: number, skySuppression: number, contrast: number, grain: number) => HTMLCanvasElement | OffscreenCanvas | null;
