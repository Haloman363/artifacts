export declare const optionTypes: {
    preset: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    steps: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    reseed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lo: {
        type: string;
        default: number[];
        desc: string;
    };
    hi: {
        type: string;
        default: number[];
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    preset: string;
    steps: number;
    mode: string;
    reseed: number;
    lo: number[];
    hi: number[];
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
