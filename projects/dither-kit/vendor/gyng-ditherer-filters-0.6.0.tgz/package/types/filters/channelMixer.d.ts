export declare const optionTypes: {
    rr: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    rg: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    rb: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gr: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gg: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gb: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    br: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bg: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bb: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    rr: number;
    rg: number;
    rb: number;
    gr: number;
    gg: number;
    gb: number;
    br: number;
    bg: number;
    bb: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
