import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    keyframeInterval: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    smear: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
};
export declare const defaults: {
    keyframeInterval: number;
    smear: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
