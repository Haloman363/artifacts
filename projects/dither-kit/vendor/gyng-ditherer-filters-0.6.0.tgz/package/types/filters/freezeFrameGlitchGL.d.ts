export declare const freezeFrameGlitchGLAvailable: () => boolean;
export declare const renderFreezeFrameGlitchGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, blockSize: number, blocksX: number, blocksY: number, freezeGrid: Uint8Array, channelIndependent: boolean, prevOutput: Uint8ClampedArray | null) => HTMLCanvasElement | OffscreenCanvas | null;
