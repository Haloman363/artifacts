export declare const optionTypes: {
    ringSpacing: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    drops: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flowStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    combScale: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    combStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    inkDensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    sourceMix: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    paperGrain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    motion: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    inkA: {
        type: string;
        default: number[];
        desc: string;
    };
    inkB: {
        type: string;
        default: number[];
        desc: string;
    };
    paper: {
        type: string;
        default: number[];
        desc: string;
    };
};
export declare const defaults: {
    ringSpacing: number;
    drops: number;
    flowStrength: number;
    combScale: number;
    combStrength: number;
    inkDensity: number;
    sourceMix: number;
    paperGrain: number;
    motion: number;
    inkA: number[];
    inkB: number[];
    paper: number[];
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
