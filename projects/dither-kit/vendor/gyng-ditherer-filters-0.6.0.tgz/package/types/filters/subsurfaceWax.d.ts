export declare const optionTypes: {
    thickness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    radius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    translucency: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lightAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    backlight: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    waxColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    thickness: number;
    radius: number;
    translucency: number;
    lightAngle: number;
    backlight: number;
    waxColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
