export declare const ortonGLAvailable: () => boolean;
export declare const renderOrtonGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, sigma: number, strength: number, contrast: number, saturation: number) => HTMLCanvasElement | OffscreenCanvas | null;
