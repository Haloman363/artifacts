export declare const pinchGLAvailable: () => boolean;
export declare const renderPinchGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, strength: number, centerX: number, centerY: number, radius: number, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
