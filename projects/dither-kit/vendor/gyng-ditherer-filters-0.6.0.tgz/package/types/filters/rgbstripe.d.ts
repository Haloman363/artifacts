import { type FilterOptionValues } from "./types";
import * as palettes from "../palettes/index";
export declare const VERTICAL = "VERTICAL";
export declare const STAGGERED = "STAGGERED";
export declare const LADDER = "LADDER";
export declare const TILED = "TILED";
export declare const HEX_GAP = "HEX_GAP";
export declare const optionTypes: {
    tubeProfile: {
        type: string;
        options: ({
            name: string;
            value: "ARCADE_240P";
        } | {
            name: string;
            value: "CONSUMER_525";
        } | {
            name: string;
            value: "CONSUMER_625";
        } | {
            name: string;
            value: "APERTURE_GRILLE";
        } | {
            name: string;
            value: "BROADCAST";
        } | {
            name: string;
            value: "CUSTOM";
        })[];
        default: "ARCADE_240P";
        desc: string;
    };
    contrast: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    brightness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    exposure: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gamma: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    phosphorScale: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    includeScanline: {
        type: string;
        default: boolean;
        desc: string;
    };
    visibleScanlines: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    scanlineGap: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    scanlineStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    beamMinWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    beamMaxWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cornerFocus: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    shadowMask: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    misconvergence: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    beamSpread: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bloom: {
        type: string;
        default: boolean;
        desc: string;
    };
    bloomThreshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bloomRadius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bloomStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    curvature: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    overscan: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    vignette: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    damperWireStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    interlace: {
        type: string;
        default: boolean;
        desc: string;
        visibleWhen: (options: any) => boolean;
    };
    persistence: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flicker: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    degauss: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any) => void;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    blur: {
        type: string;
        default: boolean;
        desc: string;
    };
    palette: {
        type: string;
        default: palettes.PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    tubeProfile: "ARCADE_240P";
    strength: number;
    contrast: number;
    brightness: number;
    exposure: number;
    gamma: number;
    phosphorScale: number;
    includeScanline: boolean;
    visibleScanlines: number;
    scanlineGap: number;
    scanlineStrength: number;
    beamMinWidth: number;
    beamMaxWidth: number;
    cornerFocus: number;
    shadowMask: string;
    misconvergence: number;
    beamSpread: number;
    bloom: boolean;
    bloomThreshold: number;
    bloomRadius: number;
    bloomStrength: number;
    curvature: number;
    overscan: number;
    vignette: number;
    damperWireStrength: number;
    interlace: boolean;
    persistence: number;
    flicker: number;
    animSpeed: number;
    blur: boolean;
    palette: palettes.PaletteDefinition<{
        levels: number;
    }>;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
