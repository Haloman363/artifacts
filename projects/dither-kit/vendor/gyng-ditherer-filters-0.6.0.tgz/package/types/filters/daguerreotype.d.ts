export declare const optionTypes: {
    silverTone: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    softFocus: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    vignette: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    metallic: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    gilding: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    viewAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    plateAge: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    silverTone: number;
    softFocus: number;
    vignette: number;
    metallic: number;
    gilding: number;
    viewAngle: number;
    plateAge: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
