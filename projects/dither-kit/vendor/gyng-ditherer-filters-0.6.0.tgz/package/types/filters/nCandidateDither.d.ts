import { type FilterOptionValues } from "./types";
export declare const ALGO: {
    readonly KNOLL: "KNOLL";
    readonly EMA_SWEEP: "EMA_SWEEP";
    readonly EMA_EXACT: "EMA_EXACT";
    readonly EMA_CONSTANT: "EMA_CONSTANT";
};
export declare const COLORSPACE: {
    readonly SRGB: "SRGB";
    readonly LINEAR: "LINEAR";
    readonly LIQ: "LIQ";
};
export declare const NC_BAYER_2X2 = "NC_BAYER_2X2";
export declare const NC_BAYER_4X4 = "NC_BAYER_4X4";
export declare const NC_BAYER_8X8 = "NC_BAYER_8X8";
declare const thresholdMaps: {
    NC_BAYER_2X2: {
        raw: number[][];
        levels: number;
    };
    NC_BAYER_4X4: {
        raw: number[][];
        levels: number;
    };
    NC_BAYER_8X8: {
        raw: number[][];
        levels: number;
    };
};
type ThresholdMapKey = keyof typeof thresholdMaps;
type NCandidatePalette = {
    options?: {
        levels?: number;
        colors?: number[][];
    } & FilterOptionValues;
} & Record<string, unknown>;
type NCandidateOptions = FilterOptionValues & {
    algo?: string;
    candidates?: number;
    strength?: number;
    minT?: number;
    constantT?: number;
    sweepTests?: number;
    lumaWeighted?: boolean;
    thresholdMap?: ThresholdMapKey;
    colorspace?: string;
    palette?: NCandidatePalette;
    _linearize?: boolean;
};
export declare const optionTypes: {
    algo: {
        type: string;
        options: ({
            name: string;
            value: "EMA_EXACT";
        } | {
            name: string;
            value: "EMA_SWEEP";
        } | {
            name: string;
            value: "EMA_CONSTANT";
        } | {
            name: string;
            value: "KNOLL";
        })[];
        default: "EMA_EXACT";
        desc: string;
    };
    candidates: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: NCandidateOptions) => boolean;
    };
    minT: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: NCandidateOptions) => boolean;
    };
    constantT: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: NCandidateOptions) => boolean;
    };
    sweepTests: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
        visibleWhen: (options: NCandidateOptions) => boolean;
    };
    lumaWeighted: {
        type: string;
        default: boolean;
        desc: string;
        visibleWhen: (options: NCandidateOptions) => boolean;
    };
    colorspace: {
        type: string;
        options: ({
            name: string;
            value: "SRGB";
        } | {
            name: string;
            value: "LINEAR";
        } | {
            name: string;
            value: "LIQ";
        })[];
        default: "SRGB";
        desc: string;
    };
    thresholdMap: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            colors: number[][];
            colorDistanceAlgorithm: string;
        }>;
    };
};
export declare const paletteColorsFor: (palette: NCandidatePalette | undefined) => number[][];
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
