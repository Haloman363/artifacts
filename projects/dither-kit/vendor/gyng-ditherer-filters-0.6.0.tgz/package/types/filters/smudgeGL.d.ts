export declare const smudgeGLAvailable: () => boolean;
export declare const renderSmudgeGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, strength: number, directionRad: number) => HTMLCanvasElement | OffscreenCanvas | null;
