export declare const triangleDitherGLAvailable: () => boolean;
export declare const renderTriangleDitherGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, seed: number, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
