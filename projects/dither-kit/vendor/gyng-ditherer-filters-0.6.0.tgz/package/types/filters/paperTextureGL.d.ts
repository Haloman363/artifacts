export declare const PAPER_TEXTURE: {
    readonly PAPER: 0;
    readonly CANVAS: 1;
    readonly LINEN: 2;
    readonly CARDBOARD: 3;
    readonly PARCHMENT: 4;
};
export declare const PAPER_BLEND: {
    readonly MULTIPLY: 0;
    readonly OVERLAY: 1;
    readonly SOFT_LIGHT: 2;
};
export declare const paperTextureGLAvailable: () => boolean;
export declare const renderPaperTextureGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, type: number, blendMode: number, scale: number, strength: number, contrast: number) => HTMLCanvasElement | OffscreenCanvas | null;
