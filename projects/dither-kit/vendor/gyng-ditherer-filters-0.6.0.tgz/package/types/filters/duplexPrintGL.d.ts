export declare const duplexPrintGLAvailable: () => boolean;
export declare const renderDuplexPrintGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, inkA: [number, number, number], inkB: [number, number, number], paper: [number, number, number], mixCurve: number) => HTMLCanvasElement | OffscreenCanvas | null;
