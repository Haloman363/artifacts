import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dither: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dotBloom: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    electrodeGrid: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    glassTint: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    microficheUnderlay: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    invert: {
        type: string;
        default: boolean;
        desc: string;
    };
};
export declare const defaults: {
    threshold: number;
    dither: number;
    dotBloom: number;
    electrodeGrid: number;
    glassTint: number;
    microficheUnderlay: number;
    invert: boolean;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
