export declare const animeLookId: (look: unknown) => number;
export declare const celBandIndex: (luminance: number, shadowThreshold: number, highlightThreshold: number) => 0 | 1 | 2;
/** XDoG's dark-line complement of its piecewise soft-threshold response. */
export declare const xdogInkResponse: (difference: number, threshold: number, softness: number) => number;
export declare const rimDirection: (angleDegrees: number) => {
    x: number;
    y: number;
};
