import { type FilterOptionValues } from "./types";
export declare const IMAGE_JPEG = "IMAGE_JPEG";
export declare const IMAGE_PNG = "IMAGE_PNG";
export declare const IMAGE_WEBP = "IMAGE_WEBP";
export declare const IMAGE_BMP = "IMAGE_BMP";
export declare const IMAGE_ICO = "IMAGE_ICO";
export declare const optionTypes: {
    format: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    errors: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    errTranspose: {
        type: string;
        default: boolean;
        desc: string;
    };
    errRepeat: {
        type: string;
        default: boolean;
        desc: string;
    };
    errSubstitute: {
        type: string;
        default: boolean;
        desc: string;
    };
    jpegQuality: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const transformTranspose: (header: number, input: Uint8Array, ..._rest: unknown[]) => Uint8Array;
export declare const transformSubstitute: (header: number, input: Uint8Array, ..._rest: unknown[]) => Uint8Array;
export declare const transformRepeat: (header: number, input: Uint8Array, ..._rest: unknown[]) => Uint8Array;
export declare const setU32: (data: Uint8Array, value: number) => void;
export declare const getU32: (data: Uint8Array) => number;
export declare const computeCrc: (data: Uint8Array, crcBuf: Uint8Array) => void;
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
