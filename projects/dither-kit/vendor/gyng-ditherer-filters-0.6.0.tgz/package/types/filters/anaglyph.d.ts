export declare const optionTypes: {
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    convergence: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    depthSource: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
};
export declare const defaults: {
    strength: number;
    convergence: number;
    mode: string;
    depthSource: string;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
