import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    blockSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    freezeChance: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    thawRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    channelIndependent: {
        type: string;
        default: boolean;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    blockSize: number;
    freezeChance: number;
    thawRate: number;
    channelIndependent: boolean;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
