export declare const optionTypes: {
    dotSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        label: string;
        desc: string;
    };
    screenAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    yellowing: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    foldCrease: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    inkSmear: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    dotSize: number;
    screenAngle: number;
    yellowing: number;
    foldCrease: number;
    inkSmear: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
