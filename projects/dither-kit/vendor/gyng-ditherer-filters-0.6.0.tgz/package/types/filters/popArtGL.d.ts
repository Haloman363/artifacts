export declare const popArtGLAvailable: () => boolean;
export declare const renderPopArtGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, dotSize: number, levels: number, saturationBoost: number, screenAngle: number, paperColor: [number, number, number]) => HTMLCanvasElement | OffscreenCanvas | null;
