import type { FilterDefinition, FilterOptionValues } from "./types";
import * as palettes from "../palettes/index";
export declare const ORDER: {
    HORIZONTAL: string;
    VERTICAL: string;
    HILBERT: string;
    SPIRAL: string;
    DIAGONAL: string;
    RANDOM_PIXEL: string;
};
export declare const ROW_ALT: {
    BOUSTROPHEDON: string;
    REVERSE: string;
    BLOCK2: string;
    BLOCK3: string;
    BLOCK4: string;
    BLOCK8: string;
    TRIANGULAR: string;
    GRAYCODE: string;
    BITREVERSE: string;
    PRIME: string;
    RANDOM: string;
};
export declare const ERR_STRATEGY: {
    RENORMALIZE: string;
    CLAMPED: string;
    DROP: string;
    ROTATE: string;
    SYMMETRIC: string;
};
export declare const TEMPORAL_MODE: {
    OFF: string;
    BLEED: string;
    VOTE: string;
};
type ErrorDiffusingRuntimeOptions = FilterOptionValues & {
    palette?: {
        getColor?: {
            bivarianceHack(color: number[], options?: FilterOptionValues): number[];
        }["bivarianceHack"];
        options?: FilterOptionValues;
    } & Record<string, unknown>;
    serpentine?: boolean;
    temporalMode?: string;
    temporalBleed?: number;
    voteWindow?: number;
    scanOrder?: string;
    rowAlternation?: string;
    errorStrategy?: string;
    _frameIndex?: number;
    _prevInput?: Uint8ClampedArray | null;
    _prevOutput?: Uint8ClampedArray | null;
    _linearize?: boolean;
};
declare const isRowMajorOrder: (opts: ErrorDiffusingRuntimeOptions) => boolean;
declare const isCustomOrderOpts: (opts: ErrorDiffusingRuntimeOptions) => boolean;
declare const usesTemporalBleed: (opts: ErrorDiffusingRuntimeOptions) => boolean;
declare const usesTemporalVote: (opts: ErrorDiffusingRuntimeOptions) => boolean;
export declare const optionTypes: {
    serpentine: {
        type: string;
        default: boolean;
        visibleWhen: typeof isRowMajorOrder;
        desc: string;
    };
    scanOrder: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    rowAlternation: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        visibleWhen: (opts: ErrorDiffusingRuntimeOptions) => boolean;
        desc: string;
    };
    errorStrategy: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        visibleWhen: typeof isCustomOrderOpts;
        desc: string;
    };
    temporalMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    temporalBleed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        visibleWhen: typeof usesTemporalBleed;
        desc: string;
    };
    voteWindow: {
        type: string;
        range: number[];
        step: number;
        default: number;
        visibleWhen: typeof usesTemporalVote;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
    palette: {
        type: string;
        default: palettes.PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    serpentine: boolean;
    scanOrder: string;
    rowAlternation: string;
    errorStrategy: string;
    temporalMode: string;
    temporalBleed: number;
    voteWindow: number;
    animSpeed: number;
    palette: palettes.PaletteDefinition<{
        levels: number;
    }>;
};
export declare const errorDiffusingFilter: (name: string, errorMatrix: any, defaultOptions: any) => FilterDefinition;
export default errorDiffusingFilter;
