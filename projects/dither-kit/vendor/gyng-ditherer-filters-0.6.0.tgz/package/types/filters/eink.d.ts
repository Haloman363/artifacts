import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    refreshMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    fullRefreshEvery: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    contrast: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    paperWhite: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    inkBlack: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    colorSaturation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    ghosting: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    pixelGrid: {
        type: string;
        default: boolean;
        desc: string;
    };
    texture: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    pageRefresh: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any) => void;
    };
    refreshRate: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    mode: string;
    refreshMode: string;
    fullRefreshEvery: number;
    contrast: number;
    paperWhite: number;
    inkBlack: number;
    colorSaturation: number;
    ghosting: number;
    pixelGrid: boolean;
    texture: number;
    refreshRate: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
