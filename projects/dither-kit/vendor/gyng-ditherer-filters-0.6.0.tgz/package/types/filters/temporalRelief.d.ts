import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    source: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    depth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    decay: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lightAngle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    invert: {
        type: string;
        default: boolean;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
};
export declare const defaults: {
    source: string;
    depth: number;
    decay: number;
    lightAngle: number;
    invert: boolean;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
