export declare const optionTypes: {
    iterations: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flow: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    wetness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    edgeBloom: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    paperTexture: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    iterations: number;
    flow: number;
    wetness: number;
    edgeBloom: number;
    paperTexture: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
