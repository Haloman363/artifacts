import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    baseSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    motionMultiplier: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    saturationBoost: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    baseSpeed: number;
    motionMultiplier: number;
    saturationBoost: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
