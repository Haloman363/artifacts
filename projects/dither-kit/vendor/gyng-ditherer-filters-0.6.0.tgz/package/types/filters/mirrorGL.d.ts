export declare const mirrorGLAvailable: () => boolean;
export declare const MIRROR_MODE_ID: Record<string, number>;
export declare const renderMirrorGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, mode: string, segments: number, offsetX: number, offsetY: number, levels: number) => HTMLCanvasElement | OffscreenCanvas | null;
