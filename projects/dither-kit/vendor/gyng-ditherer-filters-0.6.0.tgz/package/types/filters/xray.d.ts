/**
 * Beer–Lambert law: I = I₀·exp(−μ·t). Transmission through a path of
 * integrated density `density` given attenuation coefficient `attenuation`
 * (μ·t per unit density). Exactly 1 at zero density and monotonically
 * decreasing in density; never negative.
 */
export declare const beerLambertTransmission: (density: number, attenuation: number) => number;
/**
 * ABSOLUTE standard deviation of quantum mottle on the transmission estimate.
 * A detector element receives N ~ Poisson(λ) quanta with λ = dose·T, and the
 * transmission estimate is T̂ = N/dose, so Var(T̂) = λ/dose² = T/dose and
 * σ = √(T/dose). Absolute noise is therefore *largest* where transmission is
 * high; it is the relative noise σ/T = 1/√(dose·T) = 1/√N that blows up in
 * dense, photon-starved regions, which is what makes them look mottled.
 *
 * No floor on transmission: √(T/dose) is already finite and exactly zero at
 * T = 0, where a fully-opaque pixel receives no photons and so has no mottle.
 * Guards here only reject meaningless inputs; the GLSL twin is
 * MOTTLE_AMPLITUDE_GLSL below, whose uniforms are pre-normalised.
 */
export declare const quantumMottleAmplitude: (transmission: number, dose: number, gain: number) => number;
/**
 * The mottle amplitude as GLSL, kept as one string so the shader and
 * quantumMottleAmplitude() cannot drift apart unnoticed (a unit test pins this
 * expression, the interpolated constant, and its presence in the shader).
 * `u_dose` is normalised to the option range before upload, so the max() here
 * only mirrors the kernel's degenerate-input guard.
 */
export declare const MOTTLE_AMPLITUDE_GLSL = "max(0.0, u_mottle) * sqrt(max(0.0, transmission) / max(0.000001, u_dose))";
/**
 * Veiling glare: the detector sees primary transmission plus a broad scattered
 * pedestal. Mixing the two lowers subject contrast without changing the mean.
 */
export declare const veilingGlareMix: (primary: number, scattered: number, scatterFraction: number) => number;
/**
 * Display mapping. Film records transmitted intensity, so on a lightbox dense
 * material reads white: the POSITIVE (bone-white) view shows 1−T, while the
 * film-negative view shows T itself.
 */
export declare const radiographDisplayIntensity: (transmission: number, positive: boolean) => number;
export declare const optionTypes: {
    densitySource: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    attenuation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    display: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    scatter: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    scatterRadius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    dose: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    mottle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    tint: {
        type: string;
        default: number[];
        desc: string;
    };
    tintStrength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    densitySource: string;
    attenuation: number;
    display: string;
    scatter: number;
    scatterRadius: number;
    dose: number;
    mottle: number;
    tint: number[];
    tintStrength: number;
};
export declare const XRAY_DEVELOP_FS = "#version 300 es\nprecision highp float;\nin vec2 v_uv;\nout vec4 fragColor;\nuniform sampler2D u_source;\nuniform sampler2D u_primary;\nuniform sampler2D u_scatter;\nuniform vec2 u_res;\nuniform float u_scatterMix;\nuniform float u_dose;\nuniform float u_mottle;\nuniform float u_seed;\nuniform int u_positive;\nuniform vec3 u_tint;\nuniform float u_tintStrength;\n\nvec3 oc_srgbToLinear(vec3 c) {\n  vec3 lo = c / 12.92;\n  vec3 hi = pow((c + 0.055) / 1.055, vec3(2.4));\n  return mix(lo, hi, step(vec3(0.04045), c));\n}\nvec3 oc_linearToSrgb(vec3 c) {\n  c = clamp(c, 0.0, 1.0);\n  vec3 lo = c * 12.92;\n  vec3 hi = 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055;\n  return mix(lo, hi, step(vec3(0.0031308), c));\n}\n\n\n// Deterministic per-pixel hash (coords + frame seed) \u2014 no Math.random, so the\n// mottle is stable for a given frame instead of shimmering between redraws.\nfloat hash13(vec3 p) {\n  p = fract(p * 0.1031);\n  p += dot(p, p.yzx + 33.33);\n  return fract((p.x + p.y) * p.z);\n}\n\nvoid main() {\n  vec4 src = texture(u_source, v_uv);\n  float primary = texture(u_primary, v_uv).r;\n  float scattered = texture(u_scatter, v_uv).r;\n  // Veiling glare: detected = (1-s)*primary + s*scatter. The broad pedestal\n  // lowers subject contrast, exactly as Compton scatter does on real film.\n  float transmission = mix(primary, scattered, clamp(u_scatterMix, 0.0, 1.0));\n\n  // Quantum mottle. N ~ Poisson(dose * T) quanta reach the detector and the\n  // transmission estimate is T_hat = N/dose, so Var(T_hat) = T/dose and the\n  // ABSOLUTE sigma is sqrt(T/dose). Dense regions look the noisiest not because\n  // sigma is bigger there but because the SNR collapses: sigma/T = 1/sqrt(N).\n  // Box-Muller turns two uniform hashes into the Gaussian limit of the deviate.\n  vec2 pixel = vec2(v_uv.x * u_res.x, (1.0 - v_uv.y) * u_res.y);\n  float u1 = max(hash13(vec3(floor(pixel), u_seed)), 1e-6);\n  float u2 = hash13(vec3(floor(pixel) + 17.31, u_seed + 5.77));\n  float gaussian = sqrt(-2.0 * log(u1)) * cos(6.2831853 * u2);\n  float amplitude = max(0.0, u_mottle) * sqrt(max(0.0, transmission) / max(0.000001, u_dose));\n  // Only the physical floor is applied: a photon count cannot go negative, but\n  // an unattenuated estimate T_hat = N/dose may legitimately exceed 1. Clamping\n  // T to [0,1] here would throw away every upward excursion in the open beam\n  // and leave one-sided specks, so the deviate stays symmetric and the single\n  // range clamp happens once at the linear->sRGB encode.\n  transmission = max(0.0, transmission + amplitude * gaussian);\n\n  // Film records TRANSMITTED intensity, so dense material exposes less film and\n  // reads white on a lightbox: the positive view shows 1-T.\n  float intensity = u_positive == 1 ? 1.0 - transmission : transmission;\n\n  // Radiographs are viewed with a cool cast; tint in linear light.\n  vec3 tintLin = oc_srgbToLinear(clamp(u_tint / 255.0, 0.0, 1.0));\n  vec3 rgbLin = vec3(intensity) * mix(vec3(1.0), tintLin, clamp(u_tintStrength, 0.0, 1.0));\n  fragColor = vec4(oc_linearToSrgb(rgbLin), src.a);\n}\n";
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
