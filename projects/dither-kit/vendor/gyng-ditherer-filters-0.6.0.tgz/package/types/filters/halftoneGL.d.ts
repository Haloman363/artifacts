/** Parse common CSS colour strings to normalised [r,g,b]. Returns null for unknown formats. */
export declare const parseCssColorRgb: (color: string) => [number, number, number] | null;
export declare const halftoneGLAvailable: () => boolean;
export declare const renderHalftoneGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, size: number, sizeMultiplier: number, offset: number, levels: number, squareDots: boolean, background: [number, number, number], linearize: boolean) => HTMLCanvasElement | OffscreenCanvas | null;
