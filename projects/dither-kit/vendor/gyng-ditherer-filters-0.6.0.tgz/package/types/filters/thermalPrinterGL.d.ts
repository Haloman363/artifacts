export declare const thermalPrinterGLAvailable: () => boolean;
export declare const renderThermalPrinterGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, scale: number, fadeGradient: number, dotDensity: number) => HTMLCanvasElement | OffscreenCanvas | null;
