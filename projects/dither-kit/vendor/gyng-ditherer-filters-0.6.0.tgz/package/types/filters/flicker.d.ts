import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    mode: {
        type: string;
        default: "LIVE_GHOST";
        options: ({
            name: string;
            value: "LIVE_GHOST";
        } | {
            name: string;
            value: "STROBE";
        } | {
            name: string;
            value: "HOLD_FLASH";
        })[];
        desc: string;
    };
    amount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flash: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
};
export declare const defaults: {
    mode: "LIVE_GHOST";
    amount: number;
    flash: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
