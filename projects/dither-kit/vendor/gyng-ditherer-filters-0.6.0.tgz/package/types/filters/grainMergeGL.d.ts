export declare const grainMergeGLAvailable: () => boolean;
export declare const renderGrainMergeGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, radius: number, strength: number) => HTMLCanvasElement | OffscreenCanvas | null;
