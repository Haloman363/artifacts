export declare const optionTypes: {
    spacing: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    thickness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    t1: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    t2: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    inkColor: {
        type: string;
        default: number[];
        desc: string;
    };
    paperColor: {
        type: string;
        default: number[];
        desc: string;
    };
    preserveColor: {
        type: string;
        default: boolean;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    spacing: number;
    thickness: number;
    t1: number;
    t2: number;
    inkColor: number[];
    paperColor: number[];
    preserveColor: boolean;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
