import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    levels: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    holdThreshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    releaseSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
};
export declare const defaults: {
    levels: number;
    holdThreshold: number;
    releaseSpeed: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
