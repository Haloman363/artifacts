export declare const lenticularGLAvailable: () => boolean;
export declare const renderLenticularGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, stripWidth: number, angleRad: number, viewAngle: number, viewCount: number, parallax: number, crosstalk: number, lensStrength: number) => HTMLCanvasElement | OffscreenCanvas | null;
