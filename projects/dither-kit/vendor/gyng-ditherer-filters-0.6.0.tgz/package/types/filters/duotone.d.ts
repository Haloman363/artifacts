export declare const optionTypes: {
    shadowColor: {
        type: string;
        default: number[];
        desc: string;
    };
    highlightColor: {
        type: string;
        default: number[];
        desc: string;
    };
    paperColor: {
        type: string;
        default: number[];
        desc: string;
    };
    shadowCurve: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    highlightCurve: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    shadowColor: number[];
    highlightColor: number[];
    paperColor: number[];
    shadowCurve: number;
    highlightCurve: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
