export declare const swirlGLAvailable: () => boolean;
export declare const renderSwirlGL: (source: HTMLCanvasElement | OffscreenCanvas, width: number, height: number, centreX: number, centreY: number, radius: number, angleRad: number) => HTMLCanvasElement | OffscreenCanvas | null;
