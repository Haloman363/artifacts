export declare const optionTypes: {
    amplitudeX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    frequencyX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    amplitudeY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    frequencyY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    phaseX: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    phaseY: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    diagonal: {
        type: string;
        default: boolean;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    amplitudeX: number;
    frequencyX: number;
    amplitudeY: number;
    frequencyY: number;
    phaseX: number;
    phaseY: number;
    diagonal: boolean;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
