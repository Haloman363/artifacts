import { type FilterOptionValues } from "./types";
export declare const LAYOUT: {
    CENTER_STACK: string;
    GRID_2X2: string;
    GRID_3X3: string;
    PIP: string;
};
type Rect = {
    x: number;
    y: number;
    w: number;
    h: number;
};
export declare const clamp255: (v: number) => number;
export declare const clamp01: (v: number) => number;
export declare const hslToRgb: (h: number, s: number, l: number) => [number, number, number];
export declare const centeredRect: (W: number, H: number, scale: number, dx?: number, dy?: number) => Rect;
export declare const clampRect: (rect: Rect, W: number, H: number) => Rect | null;
export declare const layoutRect: (layout: string, level: number, frameIndex: number, W: number, H: number, scalePerDepth: number, drift: number) => Rect | null;
export declare const optionTypes: {
    layout: {
        type: string;
        label: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    depth: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    scalePerDepth: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    drift: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    mix: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    uiChrome: {
        type: string;
        label: string;
        default: boolean;
        desc: string;
    };
    digitalDegrade: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    accentHue: {
        type: string;
        label: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
    };
    animate: {
        type: string;
        label: string;
        action: (actions: any, inputCanvas: any, _f: any, options: any) => void;
    };
};
export declare const defaults: {
    layout: string;
    depth: number;
    scalePerDepth: number;
    drift: number;
    mix: number;
    uiChrome: boolean;
    digitalDegrade: number;
    accentHue: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
