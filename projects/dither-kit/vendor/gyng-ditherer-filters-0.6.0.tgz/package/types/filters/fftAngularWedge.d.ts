export declare const optionTypes: {
    angle: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    wedge: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    softness: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    invert: {
        type: string;
        default: boolean;
        desc: string;
    };
    gain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    angle: number;
    wedge: number;
    softness: number;
    invert: boolean;
    gain: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
