export declare const optionTypes: {
    warmth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    fadedBlacks: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    saturation: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    grain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    vignette: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    warmth: number;
    fadedBlacks: number;
    saturation: number;
    grain: number;
    vignette: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
