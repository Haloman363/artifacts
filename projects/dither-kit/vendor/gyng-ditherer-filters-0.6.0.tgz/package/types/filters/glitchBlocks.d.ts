export declare const optionTypes: {
    blockCount: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    maxBlockSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    corruption: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    blockCount: number;
    maxBlockSize: number;
    corruption: number;
    animSpeed: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
