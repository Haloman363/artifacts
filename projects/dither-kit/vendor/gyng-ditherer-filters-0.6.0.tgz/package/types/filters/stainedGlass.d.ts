export declare const COLOR_MODE: {
    readonly AVERAGE: "AVERAGE";
    readonly MEDIAN: "MEDIAN";
    readonly DOMINANT: "DOMINANT";
};
export declare const optionTypes: {
    seed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    cellSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    irregularity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    leadingWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    leadingColor: {
        type: string;
        default: number[];
        desc: string;
    };
    colorMode: {
        type: string;
        options: ({
            name: string;
            value: "AVERAGE";
        } | {
            name: string;
            value: "MEDIAN";
        } | {
            name: string;
            value: "DOMINANT";
        })[];
        default: "AVERAGE";
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    seed: number;
    cellSize: number;
    irregularity: number;
    leadingWidth: number;
    leadingColor: number[];
    colorMode: "AVERAGE";
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
