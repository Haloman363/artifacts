/**
 * Normalized source height for the anamorphic annulus (R_c ≤ r ≤ R_max): the
 * linear reflection map. 1 at the cylinder wall (nearest reflection), 0 at the
 * outer rim of the drawing. Linear in r, so the midpoint radius maps to 0.5 —
 * unlike a log map.
 */
export declare const anamorphAnnulusHeight: (r: number, cylR: number, maxR: number) => number;
/**
 * Normalized source height for the inner mirror-preview disc (r < R_c): the
 * undistorted image wrapped onto the disc, 0 at the centre and 1 at the rim, so
 * it joins the annulus continuously at r = R_c (both give height 1 there).
 */
export declare const anamorphDiscHeight: (r: number, cylR: number) => number;
/** Angle (plus twist) wrapped to a source column fraction in [0, 1). */
export declare const anamorphAngleU: (theta: number, twist: number) => number;
export declare const ANAMORPH_GLSL = "\nfloat am_annulusHeight(float r, float cylR, float maxR) {\n  float span = max(1e-3, maxR - cylR);\n  return clamp((maxR - r) / span, 0.0, 1.0);\n}\nfloat am_discHeight(float r, float cylR) {\n  return clamp(r / max(1e-3, cylR), 0.0, 1.0);\n}\nfloat am_angleU(float theta, float twist) {\n  float u = (theta + twist) / 6.28318530717958647;\n  return u - floor(u);\n}\n";
