import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    tileSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    clipLimit: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    tileSize: number;
    clipLimit: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
