export declare const lenticularViewPosition: (stripPhase: number, viewAngle: number, viewCount: number) => number;
export declare const lenticularParallaxOffset: (viewPosition: number, depthProxy: number, parallax: number) => number;
export type LcdSubpixelLayout = "STRIPE" | "PENTILE" | "DIAMOND";
/** Returns R=0, G=1, B=2, or -1 for black matrix. */
export declare const lcdSubpixelChannel: (layout: string, localX: number, localY: number, cellX: number, cellY: number) => number;
export declare const lcdBlackMatrixLevel: (gapDarkness: number) => number;
export declare const hannWindow: (sample: number, length: number) => number;
export declare const spectrogramNyquistBinCount: (signalLength: number, requestedBins: number) => number;
export declare const spectrogramMagnitudeLevel: (real: number, imaginary: number, windowSum: number, bin: number, signalLength: number, dynamicRangeDb: number) => number;
export declare const spectrogramOneSidedScale: (bin: number, signalLength: number) => 1 | 2;
export declare const spectrogramBinForRow: (row: number, height: number, binCount: number, logarithmic: boolean) => number;
