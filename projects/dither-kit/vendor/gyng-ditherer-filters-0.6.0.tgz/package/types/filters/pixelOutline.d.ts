export declare const optionTypes: {
    outlineColor: {
        type: string;
        default: number[];
        desc: string;
    };
    outlineWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    mergeThreshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
};
export declare const defaults: {
    outlineColor: number[];
    outlineWidth: number;
    mergeThreshold: number;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
