export declare const optionTypes: {
    height: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    radius: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bias: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    mode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    stoneColor: {
        type: string;
        default: number[];
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    height: number;
    radius: number;
    strength: number;
    bias: number;
    mode: string;
    stoneColor: number[];
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
