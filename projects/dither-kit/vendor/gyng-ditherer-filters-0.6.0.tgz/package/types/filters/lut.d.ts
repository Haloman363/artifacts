declare const PRESET_KEYS: readonly ["ACES", "REINHARD", "UNCHARTED2", "TEAL_ORANGE", "BLEACH_BYPASS", "CROSS_PROCESS", "KODACHROME", "FADED_FILM", "TECHNICOLOR", "MATRIX_GREEN", "AMBER_NOIR", "COLD_WINTER", "LOMO", "VELVIA", "PORTRA", "TRIX_BW", "DUNE", "MOONRISE", "CLARENDON", "NASHVILLE", "MAGIC_HOUR", "JOHN_WICK", "WES_ANDERSON", "FURY_ROAD", "NEGATIVE", "KODAK_GOLD", "FUJI_PRO_400H", "CINESTILL_800T", "ILFORD_HP5", "EKTACHROME", "AGFA_VISTA", "DEAKINS", "AMELIE", "SAVING_RYAN", "THREE_HUNDRED", "BLADE_RUNNER", "SIN_CITY", "BREAKING_BAD", "MR_ROBOT", "REVENANT", "INCEPTION", "DRIVE", "STRANGER_THINGS", "JOKER_2019"];
export declare const optionTypes: {
    preset: {
        type: string;
        options: {
            name: "300" | "ACES Filmic" | "Agfa Vista" | "Amber Noir" | "Amélie (storybook)" | "Blade Runner (1982)" | "Bleach Bypass" | "Breaking Bad" | "CineStill 800T" | "Clarendon" | "Cold Winter" | "Cross Process" | "Deakins (cool moody)" | "Drive" | "Dune" | "Faded Film" | "Fuji Pro 400H" | "Fury Road" | "Ilford HP5+" | "Inception" | "John Wick" | "Joker (2019)" | "Kodachrome" | "Kodak Ektachrome" | "Kodak Gold 200" | "Lomo" | "Magic Hour" | "Matrix Green" | "Moonrise" | "Mr. Robot" | "Nashville" | "Negative" | "Portra (Kodak)" | "Reinhard" | "Saving Private Ryan" | "Sin City" | "Stranger Things" | "Teal & Orange" | "Technicolor" | "The Revenant" | "Tri-X B&W" | "Uncharted 2 (Hable)" | "Velvia (Fuji)" | "Wes Anderson";
            value: "ACES" | "AGFA_VISTA" | "AMBER_NOIR" | "AMELIE" | "BLADE_RUNNER" | "BLEACH_BYPASS" | "BREAKING_BAD" | "CINESTILL_800T" | "CLARENDON" | "COLD_WINTER" | "CROSS_PROCESS" | "DEAKINS" | "DRIVE" | "DUNE" | "EKTACHROME" | "FADED_FILM" | "FUJI_PRO_400H" | "FURY_ROAD" | "ILFORD_HP5" | "INCEPTION" | "JOHN_WICK" | "JOKER_2019" | "KODACHROME" | "KODAK_GOLD" | "LOMO" | "MAGIC_HOUR" | "MATRIX_GREEN" | "MOONRISE" | "MR_ROBOT" | "NASHVILLE" | "NEGATIVE" | "PORTRA" | "REINHARD" | "REVENANT" | "SAVING_RYAN" | "SIN_CITY" | "STRANGER_THINGS" | "TEAL_ORANGE" | "TECHNICOLOR" | "THREE_HUNDRED" | "TRIX_BW" | "UNCHARTED2" | "VELVIA" | "WES_ANDERSON";
        }[];
        default: (typeof PRESET_KEYS)[number];
        desc: string;
    };
    strength: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    exposure: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
    };
};
export declare const defaults: {
    preset: "ACES" | "AGFA_VISTA" | "AMBER_NOIR" | "AMELIE" | "BLADE_RUNNER" | "BLEACH_BYPASS" | "BREAKING_BAD" | "CINESTILL_800T" | "CLARENDON" | "COLD_WINTER" | "CROSS_PROCESS" | "DEAKINS" | "DRIVE" | "DUNE" | "EKTACHROME" | "FADED_FILM" | "FUJI_PRO_400H" | "FURY_ROAD" | "ILFORD_HP5" | "INCEPTION" | "JOHN_WICK" | "JOKER_2019" | "KODACHROME" | "KODAK_GOLD" | "LOMO" | "MAGIC_HOUR" | "MATRIX_GREEN" | "MOONRISE" | "MR_ROBOT" | "NASHVILLE" | "NEGATIVE" | "PORTRA" | "REINHARD" | "REVENANT" | "SAVING_RYAN" | "SIN_CITY" | "STRANGER_THINGS" | "TEAL_ORANGE" | "TECHNICOLOR" | "THREE_HUNDRED" | "TRIX_BW" | "UNCHARTED2" | "VELVIA" | "WES_ANDERSON";
    strength: number;
    exposure: number;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
