export declare const optionTypes: {
    highlightColor: {
        type: string;
        default: number[];
        desc: string;
    };
    shadowColor: {
        type: string;
        default: number[];
        desc: string;
    };
    exposure: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    contrast: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    grain: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    paperTint: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    wash: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    blueDensity: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    fiberTexture: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    invert: {
        type: string;
        default: boolean;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    highlightColor: number[];
    shadowColor: number[];
    exposure: number;
    contrast: number;
    grain: number;
    paperTint: number;
    wash: number;
    blueDensity: number;
    fiberTexture: number;
    invert: boolean;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
