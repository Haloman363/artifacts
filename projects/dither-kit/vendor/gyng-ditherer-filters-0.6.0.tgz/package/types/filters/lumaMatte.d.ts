export declare const optionTypes: {
    threshold: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    feather: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    invert: {
        type: string;
        default: boolean;
        desc: string;
    };
    backgroundMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
};
export declare const defaults: {
    threshold: number;
    feather: number;
    invert: boolean;
    backgroundMode: string;
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
