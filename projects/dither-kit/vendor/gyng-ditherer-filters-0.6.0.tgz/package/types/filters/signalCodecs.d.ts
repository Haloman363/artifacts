/** Deterministic codec/channel primitives shared by the specification filters. */
export declare const seededUnit: (seed: number, a: number, b?: number) => number;
export type FaxCoding = "MH" | "MR" | "MMR";
export type FaxConcealment = "WHITE" | "PREVIOUS" | "DELETE";
export interface FaxRunLine {
    runs: number[];
    startsBlack: boolean;
    estimatedBits: number;
}
export declare const encodeFaxRuns: (pixels: Uint8Array) => FaxRunLine;
export declare const decodeFaxRuns: (line: FaxRunLine, width: number) => Uint8Array;
export interface FaxChannelResult {
    rows: Uint8Array[];
    damagedRows: number[];
}
export declare const transmitFaxRows: (rows: Uint8Array[], coding: FaxCoding, bitErrorRate: number, seed: number, concealment: FaxConcealment, mrK?: number) => FaxChannelResult;
/** SECDED Hamming 8/4 used for Teletext packet addresses and control data. */
export declare const encodeHamming84: (nibble: number) => number;
export interface Hamming84Result {
    value: number;
    corrected: boolean;
    uncorrectable: boolean;
}
export declare const decodeHamming84: (input: number) => Hamming84Result;
export declare const withOddParity: (sevenBits: number) => number;
export declare const hasOddParity: (byte: number) => boolean;
/** Reversible JPEG 2000 5/3 lifting transform, split low bands then high. */
export declare const forward53: (values: Int32Array) => Int32Array;
export declare const inverse53: (coefficients: Int32Array) => Int32Array;
export declare const quantizeCoefficient: (value: number, step: number, bitplanes: number) => number;
