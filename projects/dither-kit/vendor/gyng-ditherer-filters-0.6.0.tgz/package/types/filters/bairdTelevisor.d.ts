import { type FilterOptionValues } from "./types";
export declare const optionTypes: {
    originalAspect: {
        type: string;
        default: boolean;
        desc: string;
    };
    tint: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    spotSize: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    bandwidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    discWobble: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    syncDrift: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    flicker: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animSpeed: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    animate: {
        type: string;
        label: string;
        desc: string;
        action: (actions: any, inputCanvas: any, _filterFunc: any, options: any) => void;
    };
};
export declare const defaults: {
    originalAspect: boolean;
    tint: string;
    spotSize: number;
    bandwidth: number;
    discWobble: number;
    syncDrift: number;
    flicker: number;
    animSpeed: number;
};
declare const _default: import("./types").FilterDefinition<FilterOptionValues>;
export default _default;
