export declare const optionTypes: {
    levels: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lineWidth: {
        type: string;
        range: number[];
        step: number;
        default: number;
        desc: string;
    };
    lineColor: {
        type: string;
        default: number[];
        desc: string;
    };
    fillMode: {
        type: string;
        options: {
            name: string;
            value: string;
        }[];
        default: string;
        desc: string;
    };
    palette: {
        type: string;
        default: import("..").PaletteDefinition<{
            levels: number;
        }>;
        desc: string;
    };
};
export declare const defaults: {
    levels: number;
    lineWidth: number;
    lineColor: number[];
    fillMode: string;
    palette: {
        name: string;
        getColor: (color: number[], options?: {
            levels: number;
        } | undefined) => number[];
        defaults?: {
            levels: number;
        };
        optionTypes?: Record<string, unknown>;
        options: {
            levels: number;
        };
    };
};
declare const _default: import("./types").FilterDefinition<import("./types").FilterOptionValues>;
export default _default;
