export declare const filterCatalog: readonly [{
    readonly displayName: "None";
    readonly filterName: "None";
    readonly category: "None";
    readonly description: "Pass-through — leaves the image unchanged. The default chain entry after Clear.";
}, {
    readonly displayName: "Atkinson (Mac)";
    readonly filterName: "Atkinson";
    readonly category: "Dithering";
    readonly description: "Classic Mac dithering with 75% error diffusion for a crisp, high-contrast look";
}, {
    readonly displayName: "Atkinson (Macintosh II color test)";
    readonly filterName: "Atkinson";
    readonly category: "Dithering";
    readonly description: "Atkinson dithering with the original Macintosh II 16-color palette";
}, {
    readonly displayName: "Atkinson (Mondrian)";
    readonly filterName: "Atkinson";
    readonly category: "Dithering";
    readonly description: "Atkinson dithering with Mondrian's 5-color De Stijl palette";
}, {
    readonly displayName: "Binarize";
    readonly filterName: "Binarize";
    readonly category: "Dithering";
    readonly description: "Simple threshold to pure black and white with no error diffusion";
}, {
    readonly displayName: "Burkes";
    readonly filterName: "Burkes";
    readonly category: "Dithering";
    readonly description: "Fast two-row error diffusion with smooth gradients";
}, {
    readonly displayName: "Dither gradient";
    readonly filterName: "Dither Gradient";
    readonly category: "Dithering";
    readonly description: "Generate a smooth gradient and dither it — test pattern or standalone gradient art";
}, {
    readonly displayName: "False Floyd-Steinberg";
    readonly filterName: "False Floyd-Steinberg";
    readonly category: "Dithering";
    readonly description: "Simplified Floyd-Steinberg using only two neighbors for a grainier result";
}, {
    readonly displayName: "Floyd-Steinberg";
    readonly filterName: "Floyd-Steinberg";
    readonly category: "Dithering";
    readonly description: "The classic error-diffusion algorithm — balanced quality and speed";
}, {
    readonly displayName: "Floyd-Steinberg (CGA test)";
    readonly filterName: "Floyd-Steinberg";
    readonly category: "Dithering";
    readonly description: "Floyd-Steinberg with the 16-color CGA palette";
}, {
    readonly displayName: "Floyd-Steinberg (Synthwave)";
    readonly filterName: "Floyd-Steinberg";
    readonly category: "Dithering";
    readonly description: "Floyd-Steinberg with a neon synthwave/outrun palette";
}, {
    readonly displayName: "Floyd-Steinberg (Vaporwave test)";
    readonly filterName: "Floyd-Steinberg";
    readonly category: "Dithering";
    readonly description: "Floyd-Steinberg with a pastel vaporwave palette";
}, {
    readonly displayName: "Jarvis";
    readonly filterName: "Jarvis";
    readonly category: "Dithering";
    readonly description: "Three-row error diffusion for smoother gradients at the cost of speed";
}, {
    readonly displayName: "N-Candidate";
    readonly filterName: "N-Candidate";
    readonly category: "Dithering";
    readonly description: "Ordered dithering that picks N weighted palette candidates per pixel — reproduces arbitrary palettes far better than a plain Bayer match";
}, {
    readonly displayName: "N-Candidate (Knoll)";
    readonly filterName: "N-Candidate";
    readonly category: "Dithering";
    readonly description: "Thomas Knoll's pattern dither, as used in Photoshop — each candidate compensates for the previous one's error";
}, {
    readonly displayName: "N-Candidate (Yliluoma 2)";
    readonly filterName: "N-Candidate";
    readonly category: "Dithering";
    readonly description: "Joel Yliluoma's 2011 algorithm #2 as originally published — fraction sweep with a luma-weighted color difference";
}, {
    readonly displayName: "N-Candidate (EMA-Constant)";
    readonly filterName: "N-Candidate";
    readonly category: "Dithering";
    readonly description: "Simplified Yliluoma with a fixed 0.3 mixing factor — lighter dithering, the cheapest of the family";
}, {
    readonly displayName: "N-Candidate (CGA, luma-weighted)";
    readonly filterName: "N-Candidate";
    readonly category: "Dithering";
    readonly description: "N-candidate dithering to the CGA 16-color palette, desaturated first so the match favors green and bright tones";
}, {
    readonly displayName: "Ordered";
    readonly filterName: "Ordered";
    readonly category: "Dithering";
    readonly description: "Bayer matrix threshold dithering — fast, tiled, no error diffusion";
}, {
    readonly displayName: "Ordered (Blue Noise 1-bit)";
    readonly filterName: "Ordered";
    readonly category: "Dithering";
    readonly description: "Organic 1-bit ordered dithering with a void-and-cluster blue-noise threshold map";
}, {
    readonly displayName: "Ordered (Bayer Subject)";
    readonly filterName: "Ordered";
    readonly category: "Dithering";
    readonly description: "High-structure 1-bit Bayer dither intended for edges, figures, and foreground emphasis";
}, {
    readonly displayName: "Ordered (Amber CRT)";
    readonly filterName: "Ordered";
    readonly category: "Dithering";
    readonly description: "Ordered dithering with 4-shade amber phosphor CRT tones";
}, {
    readonly displayName: "Ordered (Cream Detective)";
    readonly filterName: "Ordered";
    readonly category: "Dithering";
    readonly description: "Cream-and-black 1-bit ordered dithering for monochrome mystery-game art";
}, {
    readonly displayName: "Ordered (Fallwell Greenboy)";
    readonly filterName: "Ordered";
    readonly category: "Dithering";
    readonly description: "Ordered dithering with a muted green Gameboy-style palette";
}, {
    readonly displayName: "Ordered (Gameboy)";
    readonly filterName: "Ordered";
    readonly category: "Dithering";
    readonly description: "Ordered dithering with the 4-shade Gameboy green palette";
}, {
    readonly displayName: "Ordered (PICO-8)";
    readonly filterName: "Ordered";
    readonly category: "Dithering";
    readonly description: "Ordered dithering with the PICO-8 fantasy console 16-color palette";
}, {
    readonly displayName: "Ordered (Windows 16-color)";
    readonly filterName: "Ordered";
    readonly category: "Dithering";
    readonly description: "4x4 Bayer ordered dithering with the classic Windows 16-color palette";
}, {
    readonly displayName: "Ordered (White Noise 1-bit)";
    readonly filterName: "Ordered";
    readonly category: "Dithering";
    readonly description: "Deterministic white-noise threshold dithering — noisy but shader-friendly and repeatable";
}, {
    readonly displayName: "Posterize dither";
    readonly filterName: "Posterize Dither";
    readonly category: "Dithering";
    readonly description: "Tone-preserving per-channel Bayer dithering between configurable output levels";
}, {
    readonly displayName: "Median Cut";
    readonly filterName: "Median Cut";
    readonly category: "Dithering";
    readonly description: "Build an exact-budget adaptive palette from visible pixels and remap the image to it";
}, {
    readonly displayName: "Octree Quantize";
    readonly filterName: "Octree Quantize";
    readonly category: "Dithering";
    readonly description: "Adaptive palette reduction using octree subdivision for a different quantization bias";
}, {
    readonly displayName: "Quantize (No dithering)";
    readonly filterName: "Quantize";
    readonly category: "Dithering";
    readonly description: "Reduce colors by snapping each pixel to the nearest palette color";
}, {
    readonly displayName: "Random";
    readonly filterName: "Random";
    readonly category: "Dithering";
    readonly description: "Add random noise before quantizing for a stippled, noisy texture";
}, {
    readonly displayName: "Riemersma";
    readonly filterName: "Riemersma";
    readonly category: "Dithering";
    readonly description: "Hilbert-curve error diffusion with rolling exponential error memory";
}, {
    readonly displayName: "Sierra (full)";
    readonly filterName: "Sierra";
    readonly category: "Dithering";
    readonly description: "Three-row error diffusion similar to Jarvis but with different weights";
}, {
    readonly displayName: "Sierra (lite)";
    readonly filterName: "Sierra lite";
    readonly category: "Dithering";
    readonly description: "Minimal Sierra variant — fast with only two neighbors";
}, {
    readonly displayName: "Sierra (two-row)";
    readonly filterName: "Sierra 2-row";
    readonly category: "Dithering";
    readonly description: "Two-row Sierra for a balance between speed and quality";
}, {
    readonly displayName: "Stucki";
    readonly filterName: "Stucki";
    readonly category: "Dithering";
    readonly description: "Three-row error diffusion with sharper results than Jarvis";
}, {
    readonly displayName: "Threshold map";
    readonly filterName: "Threshold Map";
    readonly category: "Dithering";
    readonly description: "Dither with custom threshold patterns — Bayer, halftone dot, diagonal, cross, diamond";
}, {
    readonly displayName: "Triangle dither";
    readonly filterName: "Triangle dither";
    readonly category: "Dithering";
    readonly description: "Triangle-distributed noise dithering for film-like grain";
}, {
    readonly displayName: "Blend";
    readonly filterName: "Blend";
    readonly category: "Color";
    readonly description: "Blend with a color using standard modes — multiply, screen, overlay, and more";
}, {
    readonly displayName: "Brightness/Contrast";
    readonly filterName: "Brightness/Contrast";
    readonly category: "Color";
    readonly description: "Adjust image brightness and contrast levels";
}, {
    readonly displayName: "Channel mixer";
    readonly filterName: "Channel Mixer";
    readonly category: "Color";
    readonly description: "Arbitrary RGB matrix multiplication — swap, mix, or invert channels";
}, {
    readonly displayName: "Chromatic posterize";
    readonly filterName: "Chromatic Posterize";
    readonly category: "Color";
    readonly description: "Posterize each RGB channel independently with different level counts";
}, {
    readonly displayName: "CLAHE";
    readonly filterName: "CLAHE";
    readonly category: "Color";
    readonly description: "Alpha-aware contrast-limited adaptive histogram equalization with interpolated local mappings";
}, {
    readonly displayName: "LUT";
    readonly filterName: "LUT";
    readonly category: "Color";
    readonly description: "Iconic colour-grade lookups — ACES, Reinhard, Hable, Teal & Orange, Bleach Bypass, Kodachrome, Technicolor, Cross Process, Matrix, Amber Noir, Faded Film, Cold Winter";
}, {
    readonly displayName: "Anime Color Grade";
    readonly filterName: "Anime Color Grade";
    readonly category: "Color";
    readonly description: "Scene-scripted grading with authored value colors, soft highlights, dense chroma, and skin protection";
}, {
    readonly displayName: "Anime Ink Lines";
    readonly filterName: "Anime Ink Lines";
    readonly category: "Color";
    readonly description: "Noise-resistant XDoG ink extraction with controllable line scale, weight, and compositing";
}, {
    readonly displayName: "Anime Sky";
    readonly filterName: "Anime Sky";
    readonly category: "Color";
    readonly description: "Paint likely sky regions with coherent cloud masses, horizon glow, and a controlled color gradient";
}, {
    readonly displayName: "Anime Tone Bands";
    readonly filterName: "Anime Tone Bands";
    readonly category: "Color";
    readonly description: "Group smoothed structure into authored shadow, base, and highlight colors";
}, {
    readonly displayName: "Atmospheric Haze";
    readonly filterName: "Atmospheric Haze";
    readonly category: "Color";
    readonly description: "Painted atmospheric depth haze with horizon lift and sky-tinted bloom";
}, {
    readonly displayName: "Color balance";
    readonly filterName: "Color balance";
    readonly category: "Color";
    readonly description: "Shift the balance between complementary color channels";
}, {
    readonly displayName: "Color Pop";
    readonly filterName: "Color Pop";
    readonly category: "Color";
    readonly description: "Preserve one hue family while muting the rest toward monochrome";
}, {
    readonly displayName: "Color halftone (RGB)";
    readonly filterName: "Color Halftone Separate";
    readonly category: "Color";
    readonly description: "Area-calibrated additive RGB dot plates with independent registration offsets";
}, {
    readonly displayName: "Color shift";
    readonly filterName: "Color shift";
    readonly category: "Color";
    readonly description: "Rotate hue and shift saturation/lightness";
}, {
    readonly displayName: "Color threshold";
    readonly filterName: "Color Threshold";
    readonly category: "Color";
    readonly description: "Isolate pixels by hue range — keep selected colors, desaturate the rest";
}, {
    readonly displayName: "Contour map";
    readonly filterName: "Contour Map";
    readonly category: "Color";
    readonly description: "Topographic-style elevation bands with distinct colors per luminance level";
}, {
    readonly displayName: "Curves";
    readonly filterName: "Curves";
    readonly category: "Color";
    readonly description: "Remap tonal response with editable control points for RGB or single-channel shaping";
}, {
    readonly displayName: "Dodge / Burn";
    readonly filterName: "Dodge / Burn";
    readonly category: "Color";
    readonly description: "Classic darkroom technique — dodge lightens shadows, burn darkens highlights";
}, {
    readonly displayName: "Duplex / Offset Print";
    readonly filterName: "Duplex Print";
    readonly category: "Color";
    readonly description: "Sequential accent and dark ink plates clear through continuous tone into visible paper highlights";
}, {
    readonly displayName: "Duotone";
    readonly filterName: "Duotone";
    readonly category: "Color";
    readonly description: "Map shadows and highlights to two custom colors";
}, {
    readonly displayName: "Echo Combiner";
    readonly filterName: "Echo Combiner";
    readonly category: "Color";
    readonly description: "Amplify movement against the recent average while keeping or removing the static baseline";
}, {
    readonly displayName: "Gradient map";
    readonly filterName: "Gradient Map";
    readonly category: "Color";
    readonly description: "Map luminance to a three-stop color gradient for creative toning";
}, {
    readonly displayName: "Grain merge";
    readonly filterName: "Grain Merge";
    readonly category: "Color";
    readonly description: "High-pass texture enhancement — amplifies existing texture without adding noise";
}, {
    readonly displayName: "Grayscale";
    readonly filterName: "Grayscale";
    readonly category: "Color";
    readonly description: "Convert to grayscale using perceptual luminance weights";
}, {
    readonly displayName: "Foliage Simplifier";
    readonly filterName: "Foliage Simplifier";
    readonly category: "Color";
    readonly description: "Collapse leafy or grassy texture into larger painted masses while keeping silhouettes";
}, {
    readonly displayName: "Histogram equalization";
    readonly filterName: "Histogram equalization";
    readonly category: "Color";
    readonly description: "Redistribute tonal range for better contrast across the image";
}, {
    readonly displayName: "Histogram equalization (per-channel)";
    readonly filterName: "Histogram equalization";
    readonly category: "Color";
    readonly description: "Equalize each RGB channel independently — can introduce color shifts";
}, {
    readonly displayName: "Invert";
    readonly filterName: "Invert";
    readonly category: "Color";
    readonly description: "Flip all colors to their complement (negative)";
}, {
    readonly displayName: "Levels";
    readonly filterName: "Levels";
    readonly category: "Color";
    readonly description: "Adjust black point, white point, and gamma for precise tonal control";
}, {
    readonly displayName: "Luma Matte";
    readonly filterName: "Luma Matte";
    readonly category: "Color";
    readonly description: "Build a cutout matte from luminance and optionally output transparency";
}, {
    readonly displayName: "Palette Mapper by Hue Bands";
    readonly filterName: "Palette Mapper";
    readonly category: "Color";
    readonly description: "Map hue families into fixed palette slots while preserving tonal structure";
}, {
    readonly displayName: "Posterize";
    readonly filterName: "Posterize";
    readonly category: "Color";
    readonly description: "Reduce color levels per channel for a flat, poster-like look";
}, {
    readonly displayName: "Sepia";
    readonly filterName: "Sepia";
    readonly category: "Color";
    readonly description: "Warm monochrome toning with adjustable intensity";
}, {
    readonly displayName: "Solarize";
    readonly filterName: "Solarize";
    readonly category: "Color";
    readonly description: "Partially invert tones above a threshold for a surreal darkroom effect";
}, {
    readonly displayName: "Vignette";
    readonly filterName: "Vignette";
    readonly category: "Color";
    readonly description: "Darken image edges with adjustable radius, softness, and shape";
}, {
    readonly displayName: "Anime Rim Light";
    readonly filterName: "Anime Rim Light";
    readonly category: "Stylize";
    readonly description: "Directional colored contour light for anime-style compositing and dramatic scene accents";
}, {
    readonly displayName: "ASCII";
    readonly filterName: "ASCII";
    readonly category: "Stylize";
    readonly description: "Render the image as ASCII characters based on brightness";
}, {
    readonly displayName: "CMYK halftone";
    readonly filterName: "CMYK Halftone";
    readonly category: "Stylize";
    readonly description: "Idealized unprofiled CMYK AM screens with independent plate angles";
}, {
    readonly displayName: "Contour lines";
    readonly filterName: "Contour Lines";
    readonly category: "Stylize";
    readonly description: "Antialiased topographic isolines and flat endpoint-preserving luminance bands";
}, {
    readonly displayName: "Cross-stitch";
    readonly filterName: "Cross Stitch";
    readonly category: "Stylize";
    readonly description: "Render the image as stitched X patterns on fabric for an embroidery look";
}, {
    readonly displayName: "Crosshatch";
    readonly filterName: "Crosshatch";
    readonly category: "Stylize";
    readonly description: "Simulate pen-and-ink crosshatching with luminance-driven line density";
}, {
    readonly displayName: "Delaunay triangulation";
    readonly filterName: "Delaunay";
    readonly category: "Stylize";
    readonly description: "Full-frame low-poly triangle mesh with deterministic edge-weighted point placement";
}, {
    readonly displayName: "Dot matrix";
    readonly filterName: "Dot Matrix";
    readonly category: "Stylize";
    readonly description: "Fixed circular printer-pin strikes with ordered tone density and ink/paper colors";
}, {
    readonly displayName: "Edge trace";
    readonly filterName: "Edge Trace";
    readonly category: "Stylize";
    readonly description: "Canny-like localized edge tracing with continuous line width and configurable color";
}, {
    readonly displayName: "Engraving";
    readonly filterName: "Engraving";
    readonly category: "Stylize";
    readonly description: "Parallel lines whose thickness varies with luminance — currency/illustration style";
}, {
    readonly displayName: "Flip-Dot Display";
    readonly filterName: "Flip-Dot Display";
    readonly category: "Stylize";
    readonly description: "Electromechanical dot-sign board with bi-stable cells, hysteresis, and limited flip throughput";
}, {
    readonly displayName: "Engraving (Blueprint)";
    readonly filterName: "Engraving";
    readonly category: "Stylize";
    readonly description: "Engraving lines rendered in blueprint Prussian blue on white";
}, {
    readonly displayName: "Halftone";
    readonly filterName: "Halftone";
    readonly category: "Stylize";
    readonly description: "Simulate print halftone with variable-size dots";
}, {
    readonly displayName: "K-means";
    readonly filterName: "K-means";
    readonly category: "Stylize";
    readonly description: "Seeded alpha-aware color clustering with perceptual Lab or legacy RGB distance";
}, {
    readonly displayName: "Kuwahara";
    readonly filterName: "Kuwahara";
    readonly category: "Advanced";
    readonly description: "Edge-preserving smoothing for a painterly, watercolor-like look";
}, {
    readonly displayName: "Line art";
    readonly filterName: "Line Art";
    readonly category: "Stylize";
    readonly description: "Extract clean black lines from edges, removing all shading";
}, {
    readonly displayName: "Matrix rain";
    readonly filterName: "Matrix Rain";
    readonly category: "Stylize";
    readonly description: "Matrix-style falling character rain using input image luminance";
}, {
    readonly displayName: "Mezzotint";
    readonly filterName: "Mezzotint";
    readonly category: "Stylize";
    readonly description: "Dark-ground tonal intaglio with crossed rocker burr, scraped light, ink, paper, and plate wear";
}, {
    readonly displayName: "Mosaic tile";
    readonly filterName: "Mosaic Tile";
    readonly category: "Stylize";
    readonly description: "Alpha-aware sampled tile colors with grout lines and per-tile brightness variation";
}, {
    readonly displayName: "Oil painting";
    readonly filterName: "Oil Painting";
    readonly category: "Stylize";
    readonly description: "Choose modal local paint colors from circular luminance neighborhoods";
}, {
    readonly displayName: "Pencil sketch";
    readonly filterName: "Pencil Sketch";
    readonly category: "Stylize";
    readonly description: "Directional graphite hatching that follows image tone and edge flow";
}, {
    readonly displayName: "Pixel art upscale";
    readonly filterName: "Pixel Art Upscale";
    readonly category: "Stylize";
    readonly description: "Upscale with pixel art algorithms — Scale2x, Eagle, or nearest neighbor";
}, {
    readonly displayName: "Pixel outline";
    readonly filterName: "Pixel Outline";
    readonly category: "Stylize";
    readonly description: "Alpha-aware sprite borders around sharp color and silhouette changes";
}, {
    readonly displayName: "Pixelate";
    readonly filterName: "Pixelate";
    readonly category: "Stylize";
    readonly description: "Downscale into chunky pixel blocks";
}, {
    readonly displayName: "Hex pixelate";
    readonly filterName: "Hex Pixelate";
    readonly category: "Stylize";
    readonly description: "Pixelate into staggered hex cells instead of square blocks";
}, {
    readonly displayName: "Facet / Crystalize Grid";
    readonly filterName: "Facet";
    readonly category: "Stylize";
    readonly description: "Seeded faceted planes with antialiased seams and center or local-mean color";
}, {
    readonly displayName: "Halftone Line";
    readonly filterName: "Halftone Line";
    readonly category: "Stylize";
    readonly description: "Render tone-calibrated periodic line screens with constant, luminance, or edge-following angles";
}, {
    readonly displayName: "Pop art";
    readonly filterName: "Pop Art";
    readonly category: "Stylize";
    readonly description: "Area-correct rotatable Ben-Day dots with posterized color and configurable paper";
}, {
    readonly displayName: "Posterize edges";
    readonly filterName: "Posterize Edges";
    readonly category: "Stylize";
    readonly description: "Comic book / cel-shaded look — posterized colors with dark edge outlines";
}, {
    readonly displayName: "Risograph";
    readonly filterName: "Risograph";
    readonly category: "Stylize";
    readonly description: "Fixed two-master stencil print with spot inks, registration offset, correlated ink variation, and controllable bleed";
}, {
    readonly displayName: "Smooth posterize";
    readonly filterName: "Smooth Posterize";
    readonly category: "Stylize";
    readonly description: "Posterize with smooth gradient transitions between bands — painted look";
}, {
    readonly displayName: "Stained glass";
    readonly filterName: "Stained Glass";
    readonly category: "Stylize";
    readonly description: "Voronoi panes with average, median, or dominant visible color and anti-aliased lead came";
}, {
    readonly displayName: "Stamp";
    readonly filterName: "Stamp";
    readonly category: "Stylize";
    readonly description: "Bold rubber-stamp print with rough edges and uneven ink coverage";
}, {
    readonly displayName: "Stipple";
    readonly filterName: "Stipple";
    readonly category: "Stylize";
    readonly description: "Pointillist dot placement sized by luminance — no grid";
}, {
    readonly displayName: "Stripe (horizontal)";
    readonly filterName: "Stripe (Horizontal)";
    readonly category: "Stylize";
    readonly description: "Overlay horizontal stripe pattern over the image";
}, {
    readonly displayName: "Stripe (vertical)";
    readonly filterName: "Stripe (Vertical)";
    readonly category: "Stylize";
    readonly description: "Overlay vertical stripe pattern over the image";
}, {
    readonly displayName: "Toon / Cel Shade";
    readonly filterName: "Toon";
    readonly category: "Stylize";
    readonly description: "Flat cartoon color bands with inked outlines for a cleaner cel-shaded look";
}, {
    readonly displayName: "Triangle pixelate";
    readonly filterName: "Triangle Pixelate";
    readonly category: "Stylize";
    readonly description: "Pixelate into alternating triangle cells for a faceted low-poly mosaic look";
}, {
    readonly displayName: "Voronoi";
    readonly filterName: "Voronoi";
    readonly category: "Stylize";
    readonly description: "Seeded exact Voronoi regions filled with alpha-aware average source colors";
}, {
    readonly displayName: "Watercolor bleed";
    readonly filterName: "Watercolor Bleed";
    readonly category: "Stylize";
    readonly description: "Stylized eight-neighbor pigment diffusion with edge deposition and multiscale paper fibers";
}, {
    readonly displayName: "Woodcut";
    readonly filterName: "Woodcut";
    readonly category: "Stylize";
    readonly description: "High-contrast relief with carved line texture following edge contours";
}, {
    readonly displayName: "Woodcut (Ukiyo-e)";
    readonly filterName: "Woodcut";
    readonly category: "Stylize";
    readonly description: "Woodcut with Japanese woodblock print colors — sumi ink on cream paper";
}, {
    readonly displayName: "Zigzag";
    readonly filterName: "Zigzag";
    readonly category: "Stylize";
    readonly description: "Zigzag herringbone pattern where line thickness encodes luminance";
}, {
    readonly displayName: "Cyanotype";
    readonly filterName: "Cyanotype";
    readonly category: "Stylize";
    readonly description: "Washed cyanotype paper with bounded Prussian-blue image density, granulation, and directional fibers";
}, {
    readonly displayName: "SDF Stylize";
    readonly filterName: "SDF Stylize";
    readonly category: "Stylize";
    readonly description: "True signed-distance styling via boundary jump-flood: isolines, offset bands, or bevelled fills";
}, {
    readonly displayName: "SDF Medial Axis";
    readonly filterName: "SDF Medial Axis";
    readonly category: "Stylize";
    readonly description: "Reveal a silhouette's topological skeleton where nearest-boundary regions meet";
}, {
    readonly displayName: "Flow Crosshatch";
    readonly filterName: "Flow Crosshatch";
    readonly category: "Stylize";
    readonly description: "Crosshatch ink strokes that follow the image's edge flow rather than a fixed angle";
}, {
    readonly displayName: "Line Integral Convolution";
    readonly filterName: "Line Integral Convolution";
    readonly category: "Stylize";
    readonly description: "Convolve noise along the gradient-tangent flow field — silky directional streaks";
}, {
    readonly displayName: "Quasicrystal Mosaic";
    readonly filterName: "Quasicrystal Mosaic";
    readonly category: "Stylize";
    readonly description: "Aperiodic interference facets with forbidden rotational symmetry, source-modulated phase, and relief shading";
}, {
    readonly displayName: "Suminagashi Marbling";
    readonly filterName: "Suminagashi Marbling";
    readonly category: "Stylize";
    readonly description: "Floating ink rings combed through a source-derived contour flow and transferred onto fibrous paper";
}, {
    readonly displayName: "Wallpaper Tiling";
    readonly filterName: "Wallpaper Tiling";
    readonly category: "Stylize";
    readonly description: "Crystallographic symmetry groups (P1, P2, PMM, P4M, P6M) fold the image into repeated tiles";
}, {
    readonly displayName: "Chromatic aberration";
    readonly filterName: "Chromatic aberration";
    readonly category: "Distort";
    readonly description: "Offset color channels to simulate lens fringing";
}, {
    readonly displayName: "Chromatic aberration (per-channel)";
    readonly filterName: "Chromatic aberration";
    readonly category: "Distort";
    readonly description: "Move each RGB channel independently for extreme color splitting";
}, {
    readonly displayName: "Displace";
    readonly filterName: "Displace";
    readonly category: "Distort";
    readonly description: "Warp pixels using the image's own luminance as a displacement map";
}, {
    readonly displayName: "Displace (smooth)";
    readonly filterName: "Displace";
    readonly category: "Distort";
    readonly description: "Displacement mapping with a blurred source for gentler warping";
}, {
    readonly displayName: "Flip";
    readonly filterName: "Flip";
    readonly category: "Distort";
    readonly description: "Flip the image horizontally, vertically, or both";
}, {
    readonly displayName: "Camera Shake";
    readonly filterName: "Camera Shake";
    readonly category: "Distort";
    readonly description: "Handheld whole-frame wobble — translation, rotation, and slight zoom breathing over time";
}, {
    readonly displayName: "Rhythmic Wobble";
    readonly filterName: "Rhythmic Wobble";
    readonly category: "Distort";
    readonly description: "Periodic whole-frame wobble with smooth sinusoidal drift and zoom breathing";
}, {
    readonly displayName: "Lens distortion";
    readonly filterName: "Lens distortion";
    readonly category: "Distort";
    readonly description: "Apply barrel distortion like a wide-angle lens";
}, {
    readonly displayName: "Lens distortion (pincushion)";
    readonly filterName: "Lens distortion";
    readonly category: "Distort";
    readonly description: "Apply inward pincushion distortion like a telephoto lens";
}, {
    readonly displayName: "Lens flare";
    readonly filterName: "Lens Flare";
    readonly category: "Distort";
    readonly description: "Linear-light bloom, anamorphic streaking, and chromatic optical-axis ghosts";
}, {
    readonly displayName: "Liquify";
    readonly filterName: "Liquify";
    readonly category: "Distort";
    readonly description: "Organic pixel warping driven by luminance gradients";
}, {
    readonly displayName: "Isometric Extrude";
    readonly filterName: "Isometric Extrude";
    readonly category: "Distort";
    readonly description: "Turn the image into stacked isometric slabs with a directional extrusion shadow";
}, {
    readonly displayName: "Mirror / Kaleidoscope";
    readonly filterName: "Mirror";
    readonly category: "Distort";
    readonly description: "Reflect the image along axes or create radial kaleidoscope patterns";
}, {
    readonly displayName: "Mode 7";
    readonly filterName: "Mode 7";
    readonly category: "Distort";
    readonly description: "Project the image onto a receding floor plane like a classic console racer";
}, {
    readonly displayName: "Polar transform";
    readonly filterName: "Polar Transform";
    readonly category: "Distort";
    readonly description: "Wrap a rectangle into a circle or unwrap a circular image into a strip";
}, {
    readonly displayName: "Pinch";
    readonly filterName: "Pinch";
    readonly category: "Distort";
    readonly description: "Squeeze pixels toward or away from center — radial scale distortion";
}, {
    readonly displayName: "Ripple";
    readonly filterName: "Ripple";
    readonly category: "Distort";
    readonly description: "Concentric circular waves radiating from center";
}, {
    readonly displayName: "SDF Flow Warp";
    readonly filterName: "SDF Flow Warp";
    readonly category: "Distort";
    readonly description: "Warp the source along normals and tangents of its signed-distance silhouette";
}, {
    readonly displayName: "Refractive Glass";
    readonly filterName: "Refractive Glass";
    readonly category: "Distort";
    readonly description: "Refract the image through luminance relief, cut edges, or frosted procedural glass";
}, {
    readonly displayName: "Rotate";
    readonly filterName: "Rotate";
    readonly category: "Distort";
    readonly description: "Arbitrary angle rotation with bilinear sampling";
}, {
    readonly displayName: "Smudge";
    readonly filterName: "Smudge";
    readonly category: "Distort";
    readonly description: "Paint-like smudging — drags color along a direction";
}, {
    readonly displayName: "Spherize";
    readonly filterName: "Spherize";
    readonly category: "Distort";
    readonly description: "Wrap image onto a sphere surface with adjustable strength";
}, {
    readonly displayName: "Stretch";
    readonly filterName: "Stretch";
    readonly category: "Distort";
    readonly description: "Non-uniform X/Y scaling from center";
}, {
    readonly displayName: "Swirl";
    readonly filterName: "Swirl";
    readonly category: "Distort";
    readonly description: "Twist the image with rotation that increases toward the center";
}, {
    readonly displayName: "Time-warp Displacement";
    readonly filterName: "Time-warp Displacement";
    readonly category: "Distort";
    readonly description: "Use luminance or position to sample different recent moments per pixel";
}, {
    readonly displayName: "Turbulence";
    readonly filterName: "Turbulence";
    readonly category: "Distort";
    readonly description: "Perlin noise-driven displacement for organic warping";
}, {
    readonly displayName: "Wave";
    readonly filterName: "Wave";
    readonly category: "Distort";
    readonly description: "Displace pixels along sine waves for a ripple effect";
}, {
    readonly displayName: "Möbius transform";
    readonly filterName: "Möbius";
    readonly category: "Distort";
    readonly description: "Complex-plane Möbius transformation z → (az+b)/(cz+d) — conformal warp with spiralling fixed-point structure";
}, {
    readonly displayName: "Droste spiral";
    readonly filterName: "Droste";
    readonly category: "Distort";
    readonly description: "Log-polar spiral recursion à la Escher's Prentententoonstelling — the image wraps into itself with an adjustable twist";
}, {
    readonly displayName: "Anamorphic Cylinder";
    readonly filterName: "Anamorphic Cylinder";
    readonly category: "Distort";
    readonly description: "Cylindrical anamorphosis — image stays normal inside a mirror radius and stretches logarithmically outside it";
}, {
    readonly displayName: "Fractal Flame";
    readonly filterName: "Fractal Flame";
    readonly category: "Distort";
    readonly description: "Per-pixel fractal-flame-style IFS variations: swirl, spherical, horseshoe, heart, and more with layered multi-tap accumulation";
}, {
    readonly displayName: "Analog static";
    readonly filterName: "Analog Static";
    readonly category: "Glitch";
    readonly description: "Analog TV static — noise bars, vertical hold drift, and ghosting";
}, {
    readonly displayName: "Bit crush";
    readonly filterName: "Bit crush";
    readonly category: "Glitch";
    readonly description: "Reduce bit depth per channel for harsh color banding";
}, {
    readonly displayName: "Bitplane Dropout";
    readonly filterName: "Bitplane Dropout";
    readonly category: "Glitch";
    readonly description: "Corrupt specific RGB bitplanes in bursts so significance levels drop, freeze, or flip like real digital faults";
}, {
    readonly displayName: "CRC Stripe Reject";
    readonly filterName: "CRC Stripe Reject";
    readonly category: "Glitch";
    readonly description: "Reject stripes or tiles like failed CRC packets, then conceal with hold, row-copy, or nearest-valid fill";
}, {
    readonly displayName: "Channel separation";
    readonly filterName: "Channel separation";
    readonly category: "Glitch";
    readonly description: "Split and offset RGB channels for a glitchy color-fringe look";
}, {
    readonly displayName: "Data bend";
    readonly filterName: "Data Bend";
    readonly category: "Glitch";
    readonly description: "Treat pixel data as audio — apply echo, reverb, bitcrush, or reverse";
}, {
    readonly displayName: "Datamosh";
    readonly filterName: "Datamosh";
    readonly category: "Glitch";
    readonly description: "Simulate I-frame removal — blocks persist, smear, and corrupt like broken video compression";
}, {
    readonly displayName: "Glitch";
    readonly filterName: "Glitch";
    readonly category: "Glitch";
    readonly description: "Randomly corrupt pixel data to simulate digital artifacts";
}, {
    readonly displayName: "Glitch blocks";
    readonly filterName: "Glitch Blocks";
    readonly category: "Glitch";
    readonly description: "Rectangular block displacement — simulates GPU memory corruption";
}, {
    readonly displayName: "Interlace tear";
    readonly filterName: "Interlace Tear";
    readonly category: "Glitch";
    readonly description: "Even/odd row offset simulating torn interlaced video";
}, {
    readonly displayName: "Jitter";
    readonly filterName: "Jitter";
    readonly category: "Glitch";
    readonly description: "Randomly shift pixel rows for a shaky, unstable signal look";
}, {
    readonly displayName: "JPEG artifact";
    readonly filterName: "JPEG Artifact";
    readonly category: "Glitch";
    readonly description: "Apply padded 8×8 DCT compression with separate luma/chroma quality and real 4:4:4, 4:2:2, or 4:2:0 sampling";
}, {
    readonly displayName: "Palette Index Drift";
    readonly filterName: "Palette Index Drift";
    readonly category: "Glitch";
    readonly description: "Map into an indexed palette, then drift the lookup table over time so colors break while geometry stays stable";
}, {
    readonly displayName: "Pixel drift";
    readonly filterName: "Pixel Drift";
    readonly category: "Glitch";
    readonly description: "Pixels fall or rise based on luminance — melting/gravity effect";
}, {
    readonly displayName: "Pixel scatter";
    readonly filterName: "Pixel Scatter";
    readonly category: "Glitch";
    readonly description: "Explode pixels outward from edges — disintegration effect";
}, {
    readonly displayName: "Pixelsort";
    readonly filterName: "Pixelsort";
    readonly category: "Glitch";
    readonly description: "Deterministically sort seeded pixel spans by brightness or color-space channel order";
}, {
    readonly displayName: "Scan line shift";
    readonly filterName: "Scan Line Shift";
    readonly category: "Glitch";
    readonly description: "Offset horizontal scan line blocks for a broken display glitch effect";
}, {
    readonly displayName: "Scanline Warp";
    readonly filterName: "Scanline Warp";
    readonly category: "Glitch";
    readonly description: "Sinusoidal horizontal displacement with animatable phase — wavy CRT glitch";
}, {
    readonly displayName: "Anisotropic diffusion";
    readonly filterName: "Anisotropic diffusion";
    readonly category: "Advanced";
    readonly description: "Half-float Perona–Malik smoothing with shared color-edge guidance";
}, {
    readonly displayName: "Anaglyph 3D";
    readonly filterName: "Anaglyph";
    readonly category: "Simulate";
    readonly description: "Single-image synthetic stereo anaglyph with convergence-centered disparity and a linear-light Dubois red/cyan projection";
}, {
    readonly displayName: "Apollo Slow-Scan TV";
    readonly filterName: "Apollo Slow-Scan TV";
    readonly category: "Simulate";
    readonly description: "Apollo 320/10 or 1280/0.625 slow-scan camera through the RCA kinescope, vidicon, and magnetic-disc converter";
}, {
    readonly displayName: "Apple II HGR";
    readonly filterName: "Apple II HGR";
    readonly category: "Simulate";
    readonly description: "Apple II 280×192 high-resolution bitmap through phase-dependent NTSC artifact-color decoding";
}, {
    readonly displayName: "Amiga HAM6";
    readonly filterName: "Amiga HAM6";
    readonly category: "Simulate";
    readonly description: "Amiga OCS six-plane hold-and-modify encoding with a legal stateful opcode stream";
}, {
    readonly displayName: "Bayer Sensor";
    readonly filterName: "Bayer Sensor";
    readonly category: "Simulate";
    readonly description: "Bayer CFA capture with true nearest/bilinear or 5×5 gradient-corrected demosaicing, shot/read noise, crosstalk, optical low-pass filtering, and stable defects";
}, {
    readonly displayName: "Baird Televisor";
    readonly filterName: "Baird Televisor";
    readonly category: "Simulate";
    readonly description: "Baird/BBC 30-line vertical mechanical television with a Nipkow-disc raster and modulated neon lamp";
}, {
    readonly displayName: "Camera Monitor";
    readonly filterName: "Camera Monitor";
    readonly category: "Simulate";
    readonly description: "Focus peaking, exposure zebras, false color, and clipping warnings for a production-monitor view";
}, {
    readonly displayName: "CCD Charge Smear";
    readonly filterName: "CCD Charge Smear";
    readonly category: "Simulate";
    readonly description: "Visible-light proxy for CCD full-well overflow with additive column blooming and an anti-blooming drain";
}, {
    readonly displayName: "CGA Composite";
    readonly filterName: "CGA Composite";
    readonly category: "Simulate";
    readonly description: "IBM CGA through legal RGBI palettes or phase-sensitive NTSC composite artifact-color decoding";
}, {
    readonly displayName: "CRT emulation";
    readonly filterName: "rgbStripe";
    readonly category: "Simulate";
    readonly description: "Profiled CRT display model with voltage-to-light transfer, beam-current raster, phosphor masks, overscan, convergence, and faceplate bloom";
}, {
    readonly displayName: "CRT Degauss";
    readonly filterName: "CRT Degauss";
    readonly category: "Simulate";
    readonly description: "Fire a decaying degauss pulse with raster wobble, phosphor mislanding, and a bright magnetic flash";
}, {
    readonly displayName: "Daguerreotype";
    readonly filterName: "Daguerreotype";
    readonly category: "Simulate";
    readonly description: "Highly detailed direct-positive particles over a directional, mirror-polished silver plate";
}, {
    readonly displayName: "Digicam Flash";
    readonly filterName: "Digicam Flash";
    readonly category: "Simulate";
    readonly description: "Flat-scene point-and-shoot flash proxy with linear-light ambient/flash exposure, an off-axis beam, flash-only white balance, lens falloff, and sensor saturation";
}, {
    readonly displayName: "DLP Color Wheel";
    readonly filterName: "DLP Color Wheel";
    readonly category: "Simulate";
    readonly description: "Single-chip DLP sequential illumination with motion color breakup, micromirror bit planes, and projection softness";
}, {
    readonly displayName: "Deep fry";
    readonly filterName: "Deep fry";
    readonly category: "Stylize";
    readonly description: "Extreme contrast, oversaturation, and JPEG artifacts — the deep-fried meme aesthetic";
}, {
    readonly displayName: "E-ink (color)";
    readonly filterName: "E-ink";
    readonly category: "Simulate";
    readonly description: "Kaleido-style printed color-filter array over reflective ink, with 16 levels per channel, three-pixel color cells, fixed paper grain, and update residuals";
}, {
    readonly displayName: "E-ink (grayscale)";
    readonly filterName: "E-ink";
    readonly category: "Simulate";
    readonly description: "Carta-style reflective display with 16 optical states, fixed paper grain, full clearing waveforms, and changed-pixel partial-update residuals";
}, {
    readonly displayName: "Edge glow";
    readonly filterName: "Edge Glow";
    readonly category: "Stylize";
    readonly description: "Neon-colored edge outlines on a dark background — cyberpunk/Tron aesthetic";
}, {
    readonly displayName: "Fax machine";
    readonly filterName: "Fax Machine";
    readonly category: "Simulate";
    readonly description: "ITU-T T.4 Group 3 / T.6 Group 4 scan-line coding, channel errors, dependent-line damage, and E.453 concealment";
}, {
    readonly displayName: "Film burn";
    readonly filterName: "Film Burn";
    readonly category: "Simulate";
    readonly description: "Projection-gate heat damage with warped dyes, blistered crust, cracked emulsion, and exposed-lamp cores";
}, {
    readonly displayName: "Film grain";
    readonly filterName: "Film Grain";
    readonly category: "Stylize";
    readonly description: "Density-aware film granularity with smooth clusters, correlated color layers, and optional frame motion";
}, {
    readonly displayName: "Ink Bleed";
    readonly filterName: "Ink Bleed";
    readonly category: "Simulate";
    readonly description: "Dark ink wicks through an anisotropic paper-fiber field with heterogeneous capillary edges";
}, {
    readonly displayName: "Paper Texture";
    readonly filterName: "Paper Texture";
    readonly category: "Simulate";
    readonly description: "Antialiased paper fibres, alternating canvas and linen weave, kraft liner, or parchment formation over the image";
}, {
    readonly displayName: "Sumi-e";
    readonly filterName: "Sumi-e";
    readonly category: "Stylize";
    readonly description: "Stylized Japanese ink wash with softened tonal bands, contour ink, and directionally fibrous washi formation";
}, {
    readonly displayName: "Gameboy Camera";
    readonly filterName: "Gameboy Camera";
    readonly category: "Simulate";
    readonly description: "Mitsubishi M64282FP exposure, gain, bias, inversion and edge registers with cartridge four-tone dithering";
}, {
    readonly displayName: "Infrared photography";
    readonly filterName: "Infrared";
    readonly category: "Simulate";
    readonly description: "Estimated visible-RGB infrared film response with Wood-effect monochrome and Aerochrome-style channel mapping";
}, {
    readonly displayName: "LCD display";
    readonly filterName: "LCD Display";
    readonly category: "Simulate";
    readonly description: "Magnified display-emitter proxy with equal RGB stripe, shared-chroma PenTile RGBG, and diamond-shaped RGBG layouts";
}, {
    readonly displayName: "Lenticular";
    readonly filterName: "Lenticular";
    readonly category: "Simulate";
    readonly description: "Single-image lenticular-sheet proxy with synthetic interlaced views, viewing-angle selection, cylindrical transmission, and crosstalk";
}, {
    readonly displayName: "Laser Speckle Projector";
    readonly filterName: "Laser Speckle Projector";
    readonly category: "Simulate";
    readonly description: "Linear-light laser-projector irradiance with coherent speckle, independent-pattern diversity, scan structure, and optical bloom";
}, {
    readonly displayName: "Light leak";
    readonly filterName: "Light Leak";
    readonly category: "Simulate";
    readonly description: "Spectrally faithful edge-entering film fog added as linear-light exposure";
}, {
    readonly displayName: "Mavica FD7";
    readonly filterName: "Mavica FD7";
    readonly category: "Simulate";
    readonly description: "Sony MVC-FD7 still-camera proxy with VGA CCD sampling, interlaced field capture, period JPEG budgets, scene modes, and optional flash artifacts";
}, {
    readonly displayName: "Metadata Mismatch Decode";
    readonly filterName: "Metadata Mismatch Decode";
    readonly category: "Simulate";
    readonly description: "Apply wrong gamma, matrix, range, and chroma assumptions to mimic authentic decode metadata failures";
}, {
    readonly displayName: "Moiré / Aliasing";
    readonly filterName: "Moiré / Aliasing";
    readonly category: "Simulate";
    readonly description: "Lattice-derived capture aliasing from rotated scene sampling, RGB display emitters, or conventional CMYK print screens";
}, {
    readonly displayName: "Newspaper";
    readonly filterName: "Newspaper";
    readonly category: "Simulate";
    readonly description: "Static 45° monochrome halftone with locally averaged tone, yellowed paper, folds, and fixed ink spread";
}, {
    readonly displayName: "Night vision";
    readonly filterName: "Night vision";
    readonly category: "Simulate";
    readonly description: "Visible-luminance image-intensifier proxy with MCP-like gain, signal-dependent noise, green phosphor bloom, and tube vignette";
}, {
    readonly displayName: "Nokia LCD";
    readonly filterName: "Nokia LCD";
    readonly category: "Simulate";
    readonly description: "PCD8544-style 84×48 two-state LCD with display-grid ordered dithering and preserved green optical states";
}, {
    readonly displayName: "Oscilloscope";
    readonly filterName: "Oscilloscope";
    readonly category: "Simulate";
    readonly description: "Image-derived luma waveform, column trace, or RGB parade rendered as a persistent phosphor instrument display";
}, {
    readonly displayName: "PLATO Plasma";
    readonly filterName: "PLATO Plasma";
    readonly category: "Simulate";
    readonly description: "Control Data's square 512×512 bistable orange-neon plasma panel with optional microfiche underlay";
}, {
    readonly displayName: "PAL / SECAM";
    readonly filterName: "PAL / SECAM";
    readonly category: "Simulate";
    readonly description: "BT.1700 PAL/SECAM composite signal with delay-line decoding, bandwidth, phase, tuning and crosstalk faults";
}, {
    readonly displayName: "Photocopier";
    readonly filterName: "Photocopier";
    readonly category: "Simulate";
    readonly description: "Fixed-sheet xerographic copy with continuous density transfer, edge toner, background scatter, and transfer voids";
}, {
    readonly displayName: "Polaroid";
    readonly filterName: "Polaroid";
    readonly category: "Simulate";
    readonly description: "Developed instant-film grade with warm dye balance, lifted blacks, fixed grain, and optical vignetting";
}, {
    readonly displayName: "Projection film";
    readonly filterName: "Projection film";
    readonly category: "Simulate";
    readonly description: "Mechanical 16/35 mm projection with weave, density grain, dark gate debris, scratches, flicker, and bloom";
}, {
    readonly displayName: "PXL-2000";
    readonly filterName: "PXL-2000";
    readonly category: "Simulate";
    readonly description: "Fisher-Price 120×90 monochrome CCD, 15 Hz ping-pong capture, 90 kHz luma, and FM cassette recording";
}, {
    readonly displayName: "Risograph (multi-layer)";
    readonly filterName: "Risograph (multi-layer)";
    readonly category: "Simulate";
    readonly description: "Fixed multi-master stencil print with balanced registration offsets and correlated emulsion-ink variation";
}, {
    readonly displayName: "Rolling Shutter";
    readonly filterName: "Rolling Shutter";
    readonly category: "Simulate";
    readonly description: "Temporal CMOS readout bends motion progressively across rows or columns";
}, {
    readonly displayName: "Schlieren Optics";
    readonly filterName: "Schlieren Optics";
    readonly category: "Simulate";
    readonly description: "Directional knife-edge and color schlieren views of source-derived refractive gradients";
}, {
    readonly displayName: "X-Ray";
    readonly filterName: "X-Ray";
    readonly category: "Simulate";
    readonly description: "Beer–Lambert radiograph proxy: image luminance stands in for path-integrated density, with Compton-scatter veiling glare and dose-dependent quantum mottle";
}, {
    readonly displayName: "Scanning Electron Micrograph";
    readonly filterName: "Scanning Electron Micrograph";
    readonly category: "Simulate";
    readonly description: "Read luminance as invented topography, then light it by secant-law secondary-electron yield — bright rims, off-axis detector shading, scan noise";
}, {
    readonly displayName: "Radar PPI";
    readonly filterName: "Radar PPI";
    readonly category: "Simulate";
    readonly description: "Rotating plan-position-indicator scope — 1/r⁴ radar-equation falloff with STC, exponential phosphor persistence behind the sweep, short-range sea and rain clutter, range rings and bearing graticule. There is no radar data: image luminance stands in for target reflectivity";
}, {
    readonly displayName: "Screen Print / Misregistration";
    readonly filterName: "Screen Print";
    readonly category: "Simulate";
    readonly description: "Rotated clustered-dot spot-color screens with subtractive overprint, dot gain, and deterministic plate offset";
}, {
    readonly displayName: "Scanline";
    readonly filterName: "Scanline";
    readonly category: "Simulate";
    readonly description: "Resolution-independent CRT raster lines with a luminance-dependent Gaussian beam profile and legacy row modes";
}, {
    readonly displayName: "Spectrogram";
    readonly filterName: "Spectrogram";
    readonly category: "Simulate";
    readonly description: "Spatial-frequency spectrogram treating each image column as a Hann-windowed signal with fixed-reference dB magnitude and linear or log frequency spacing";
}, {
    readonly displayName: "Teletext";
    readonly filterName: "Teletext";
    readonly category: "Simulate";
    readonly description: "ETSI System B 24x40 alphamosaics with packet-address Hamming correction, data parity, and channel faults";
}, {
    readonly displayName: "Thermal camera";
    readonly filterName: "Thermal camera";
    readonly category: "Simulate";
    readonly description: "Visible-RGB luminance proxy—not emitted-IR temperature—through a low-resolution thermal-camera display";
}, {
    readonly displayName: "Thermal printer";
    readonly filterName: "Thermal Printer";
    readonly category: "Simulate";
    readonly description: "Direct-thermal receipt print with coherent line-head dots, density response, and edge fade";
}, {
    readonly displayName: "Ultrasound";
    readonly filterName: "Ultrasound";
    readonly category: "Simulate";
    readonly description: "Source-derived acoustic-impedance proxy rendered as a convex B-mode sector with boundary echoes, depth attenuation, and correlated speckle";
}, {
    readonly displayName: "VHS emulation";
    readonly filterName: "VHS emulation";
    readonly category: "Simulate";
    readonly description: "Simulate VHS tape — tracking errors, chroma delay, head-switching noise, and ghosting";
}, {
    readonly displayName: "VHS / NTSC";
    readonly filterName: "VHS / NTSC";
    readonly category: "Simulate";
    readonly description: "Signal-model VHS — YIQ composite modulation, NTSC decoding, tape-speed bandwidth, tracking, snow, and chroma loss";
}, {
    readonly displayName: "Vintage TV";
    readonly filterName: "Vintage TV";
    readonly category: "Simulate";
    readonly description: "Conventional 525/625-line receiver with separate luma/chroma bandwidth, tuning error, vertical hold, interlaced raster, interference, and phosphor bloom";
}, {
    readonly displayName: "Wavelet Codec";
    readonly filterName: "Wavelet Codec";
    readonly category: "Simulate";
    readonly description: "JPEG 2000-inspired undecimated decomposition with 5/3- or 9/7-derived kernels, quantization, bit-plane loss, and code-block damage";
}, {
    readonly displayName: "ZX Spectrum";
    readonly filterName: "ZX Spectrum";
    readonly category: "Simulate";
    readonly description: "ZX Spectrum 256×192 bitmap constrained to one INK/PAPER pair and brightness bit per 8×8 cell";
}, {
    readonly displayName: "Motion Analysis";
    readonly filterName: "Motion Analysis";
    readonly category: "Simulate";
    readonly description: "Analyze motion against the background model or previous frame and render it as a mask, highlight, or persistent heatmap";
}, {
    readonly displayName: "Long Exposure";
    readonly filterName: "Long Exposure";
    readonly category: "Simulate";
    readonly description: "Blend, average, or accumulate recent frames for ghost trails, slow-shutter smear, and long-exposure light painting";
}, {
    readonly displayName: "Phosphor decay";
    readonly filterName: "Phosphor Decay";
    readonly category: "Simulate";
    readonly description: "Refresh-aware phosphor persistence with measured P22 timing and explicit long-afterglow profiles";
}, {
    readonly displayName: "Bilateral blur";
    readonly filterName: "Bilateral Blur";
    readonly category: "Blur & Edges";
    readonly description: "Edge-preserving smooth — blurs flat areas while keeping edges crisp";
}, {
    readonly displayName: "Bloom";
    readonly filterName: "Bloom";
    readonly category: "Blur & Edges";
    readonly description: "Add a soft glow around bright areas";
}, {
    readonly displayName: "Bokeh";
    readonly filterName: "Bokeh";
    readonly category: "Blur & Edges";
    readonly description: "Simulate out-of-focus highlights with hexagonal or circular bokeh shapes";
}, {
    readonly displayName: "Orton";
    readonly filterName: "Orton";
    readonly category: "Blur & Edges";
    readonly description: "Dreamy photographic glow — screen-blends a blurred copy over the image for a painterly soft look";
}, {
    readonly displayName: "Halation";
    readonly filterName: "Halation";
    readonly category: "Blur & Edges";
    readonly description: "Red/pink bleed around bright highlights — emulates CineStill 800T and missing anti-halation film layers";
}, {
    readonly displayName: "Convolve";
    readonly filterName: "Convolve";
    readonly category: "Blur & Edges";
    readonly description: "Apply a custom convolution kernel — blur, sharpen, emboss, and more";
}, {
    readonly displayName: "Convolve (edge detection)";
    readonly filterName: "Convolve";
    readonly category: "Blur & Edges";
    readonly description: "Detect edges using a Laplacian convolution kernel";
}, {
    readonly displayName: "Despeckle";
    readonly filterName: "Despeckle";
    readonly category: "Blur & Edges";
    readonly description: "Adaptive noise removal — smooths noisy areas while preserving structured detail";
}, {
    readonly displayName: "Dilate / Erode";
    readonly filterName: "Dilate / Erode";
    readonly category: "Advanced";
    readonly description: "Morphological operations — expand or shrink bright regions";
}, {
    readonly displayName: "Emboss";
    readonly filterName: "Emboss";
    readonly category: "Blur & Edges";
    readonly description: "Directional relief effect with adjustable light angle and blend";
}, {
    readonly displayName: "Gaussian blur";
    readonly filterName: "Gaussian Blur";
    readonly category: "Blur & Edges";
    readonly description: "Smooth the image with a Gaussian kernel — adjustable sigma";
}, {
    readonly displayName: "Median filter";
    readonly filterName: "Median Filter";
    readonly category: "Blur & Edges";
    readonly description: "Non-linear noise removal — replaces each pixel with the median of its neighborhood";
}, {
    readonly displayName: "Motion blur";
    readonly filterName: "Motion Blur";
    readonly category: "Blur & Edges";
    readonly description: "Directional blur simulating camera or object motion";
}, {
    readonly displayName: "Relief Map / Faux Normal Lighting";
    readonly filterName: "Relief Map";
    readonly category: "Blur & Edges";
    readonly description: "Treat luminance like a height field and relight it with directional faux-surface shading";
}, {
    readonly displayName: "Radial blur";
    readonly filterName: "Radial Blur";
    readonly category: "Blur & Edges";
    readonly description: "Zoom blur radiating from center — speed/motion effect";
}, {
    readonly displayName: "Sharpen";
    readonly filterName: "Sharpen";
    readonly category: "Blur & Edges";
    readonly description: "Unsharp mask — enhance edges with adjustable strength and radius";
}, {
    readonly displayName: "Tilt shift";
    readonly filterName: "Tilt Shift";
    readonly category: "Blur & Edges";
    readonly description: "Miniature/toy camera effect — sharp focus band with progressive blur";
}, {
    readonly displayName: "Temporal Edge";
    readonly filterName: "Temporal Edge";
    readonly category: "Blur & Edges";
    readonly description: "Detect edges in time — moving edges glow, static edges invisible";
}, {
    readonly displayName: "After-image";
    readonly filterName: "After-Image";
    readonly category: "Simulate";
    readonly description: "Complementary-colored ghost when bright objects move — retinal fatigue";
}, {
    readonly displayName: "Scene Separation";
    readonly filterName: "Scene Separation";
    readonly category: "Color";
    readonly description: "Separate moving and static regions to isolate foreground, reconstruct the background, or freeze still parts of the scene";
}, {
    readonly displayName: "Chronophotography";
    readonly filterName: "Chronophotography";
    readonly category: "Stylize";
    readonly description: "Multiple ghosted exposures of moving subjects — stroboscopic photography";
}, {
    readonly displayName: "Freeze frame glitch";
    readonly filterName: "Freeze Frame Glitch";
    readonly category: "Glitch";
    readonly description: "Random blocks freeze in time — corrupted buffer aesthetic";
}, {
    readonly displayName: "Motion pixelate";
    readonly filterName: "Motion Pixelate";
    readonly category: "Stylize";
    readonly description: "Moving areas become pixelated — privacy or artistic motion effect";
}, {
    readonly displayName: "POV Bands";
    readonly filterName: "POV Bands";
    readonly category: "Stylize";
    readonly description: "Show different recent moments across horizontal bands like a persistence-of-vision display";
}, {
    readonly displayName: "Slit scan";
    readonly filterName: "Slit Scan";
    readonly category: "Distort";
    readonly description: "Each column shows a different point in time — surreal temporal stretching";
}, {
    readonly displayName: "Stop Motion";
    readonly filterName: "Stop Motion";
    readonly category: "Stylize";
    readonly description: "Hold each frame for several beats to create a choppy stop-motion cadence";
}, {
    readonly displayName: "ABA Bounce";
    readonly filterName: "ABA Bounce";
    readonly category: "Stylize";
    readonly description: "Three-beat A-B-A cadence that snaps the third beat back to the first frame in the triplet";
}, {
    readonly displayName: "ABA Ghost";
    readonly filterName: "ABA Ghost";
    readonly category: "Stylize";
    readonly description: "Three-beat A-B-A cadence with a double-exposed third beat that ghosts the skipped frame against the first";
}, {
    readonly displayName: "ABA Rebound";
    readonly filterName: "ABA Rebound";
    readonly category: "Distort";
    readonly description: "On the third beat, push motion away from the first frame in the triplet for a recoiling ABA judder";
}, {
    readonly displayName: "Flicker";
    readonly filterName: "Flicker";
    readonly category: "Stylize";
    readonly description: "Aggressive flicker/strobe filter with live ghosting and held-frame flash modes";
}, {
    readonly displayName: "Keyframe Smear";
    readonly filterName: "Keyframe Smear";
    readonly category: "Stylize";
    readonly description: "Capture sparse keyframes and drag them through in-between frames for compressed temporal smearing";
}, {
    readonly displayName: "Ink Drying";
    readonly filterName: "Ink Drying";
    readonly category: "Stylize";
    readonly description: "Fresh dark marks stay wet, bleed slightly, and then dry back toward the page";
}, {
    readonly displayName: "Time Median";
    readonly filterName: "Time Median";
    readonly category: "Simulate";
    readonly description: "Per-pixel median across recent frames to suppress brief motion and flicker while preserving stable structure";
}, {
    readonly displayName: "Temporal AA";
    readonly filterName: "Temporal AA";
    readonly category: "Blur & Edges";
    readonly description: "Blend previous output into the current frame with neighborhood color clamping — temporal anti-aliasing that smooths flicker and shimmer without ghosting";
}, {
    readonly displayName: "Color Cycle";
    readonly filterName: "Color Cycle";
    readonly category: "Color";
    readonly description: "Hue rotates over time — moving areas cycle faster into rainbow trails";
}, {
    readonly displayName: "Poster Hold";
    readonly filterName: "Poster Hold";
    readonly category: "Color";
    readonly description: "Posterized tone bands update with hysteresis so broad regions hold before snapping to new values";
}, {
    readonly displayName: "Motion Relief";
    readonly filterName: "Motion Relief";
    readonly category: "Blur & Edges";
    readonly description: "Turn recent change history into embossed grayscale relief shading";
}, {
    readonly displayName: "Time mosaic";
    readonly filterName: "Time Mosaic";
    readonly category: "Stylize";
    readonly description: "Tiles update at different rates — staggered surveillance-wall aesthetic";
}, {
    readonly displayName: "Infinite call windows";
    readonly filterName: "Infinite Call Windows";
    readonly category: "Advanced";
    readonly description: "Recursive video-call panes with digital UI chrome and compression-style decay";
}, {
    readonly displayName: "Video feedback";
    readonly filterName: "Video Feedback";
    readonly category: "Advanced";
    readonly description: "Camera-at-monitor effect — infinite recursive tunnels and fractal patterns";
}, {
    readonly displayName: "Wake turbulence";
    readonly filterName: "Wake Turbulence";
    readonly category: "Distort";
    readonly description: "Moving objects leave rippling distortion — heat shimmer effect";
}, {
    readonly displayName: "Cellular automata";
    readonly filterName: "Cellular Automata";
    readonly category: "Advanced";
    readonly description: "Conway's Game of Life and other rulesets applied to the image — animatable";
}, {
    readonly displayName: "Reaction-Diffusion";
    readonly filterName: "Reaction-Diffusion";
    readonly category: "Advanced";
    readonly description: "Gray-Scott reaction-diffusion seeded from image luminance — spots, stripes, coral, mitosis, labyrinth Turing patterns grow out of the picture";
}, {
    readonly displayName: "Stable Fluids";
    readonly filterName: "Stable Fluids";
    readonly category: "Advanced";
    readonly description: "Stam-style semi-Lagrangian fluid advection — smoke flows along the image's edges, picking up gradients as forcing each frame";
}, {
    readonly displayName: "Caustics";
    readonly filterName: "Caustics";
    readonly category: "Advanced";
    readonly description: "Refract light through the image as through a glass surface — bright caustic webs where gradients converge, shadows where they diverge";
}, {
    readonly displayName: "Heightfield Raymarch";
    readonly filterName: "Heightfield Raymarch";
    readonly category: "Advanced";
    readonly description: "Ray-march image luminance as a deep, self-shadowing 2.5D relief";
}, {
    readonly displayName: "Silhouette Extrusion";
    readonly filterName: "Silhouette Extrusion";
    readonly category: "Advanced";
    readonly description: "Ray-trace a luminance or alpha silhouette into a bevelled 3D slab";
}, {
    readonly displayName: "Voxel Landscape";
    readonly filterName: "Voxel Landscape";
    readonly category: "Advanced";
    readonly description: "Raycast source-colored voxel columns into a tiny image-derived landscape";
}, {
    readonly displayName: "Glass Surface";
    readonly filterName: "Glass Surface";
    readonly category: "Advanced";
    readonly description: "Trace refracted rays through image-shaped animated glass and droplets";
}, {
    readonly displayName: "Relief Reflections";
    readonly filterName: "Relief Reflections";
    readonly category: "Advanced";
    readonly description: "Trace screen-space reflections across a luminance-derived relief surface";
}, {
    readonly displayName: "Volumetric Light";
    readonly filterName: "Volumetric Light";
    readonly category: "Advanced";
    readonly description: "Integrate bright source pixels through animated fog into volumetric light shafts";
}, {
    readonly displayName: "SDF Melt";
    readonly filterName: "SDF Melt";
    readonly category: "Advanced";
    readonly description: "Inflate, erode, and melt a source-derived signed-distance silhouette";
}, {
    readonly displayName: "SDF Boolean Sculpt";
    readonly filterName: "SDF Boolean Sculpt";
    readonly category: "Advanced";
    readonly description: "Sculpt a source silhouette with analytic SDF union, intersection, subtraction, and smooth blending";
}, {
    readonly displayName: "Fractal Portal";
    readonly filterName: "Fractal Portal";
    readonly category: "Advanced";
    readonly description: "Sphere-trace a Mandelbulb or Julia bulb textured by the source image";
}, {
    readonly displayName: "Path-Traced Diorama";
    readonly filterName: "Path-Traced Diorama";
    readonly category: "Advanced";
    readonly description: "Progressively path-trace the source as a framed image inside a softly lit miniature room";
}, {
    readonly displayName: "Luminance Caverns";
    readonly filterName: "Luminance Caverns";
    readonly category: "Advanced";
    readonly description: "Fly through glowing cavern walls carved and colored by the source image";
}, {
    readonly displayName: "Black Hole Lens";
    readonly filterName: "Black Hole Lens";
    readonly category: "Advanced";
    readonly description: "Bend source-image rays around an event horizon and glowing accretion disc";
}, {
    readonly displayName: "Thin-Film Iridescence";
    readonly filterName: "Thin-Film Iridescence";
    readonly category: "Advanced";
    readonly description: "Simulate wavelength-dependent soap, oil, shell, and holographic-film interference";
}, {
    readonly displayName: "Subsurface Wax";
    readonly filterName: "Subsurface Wax";
    readonly category: "Advanced";
    readonly description: "Diffuse light beneath the source surface like wax, skin, jade, or stained resin";
}, {
    readonly displayName: "Cone-Traced AO";
    readonly filterName: "Cone-Traced AO";
    readonly category: "Advanced";
    readonly description: "Horizon-trace a luminance heightfield to deepen creases and contact shadows";
}, {
    readonly displayName: "Chromatic Prism Tracer";
    readonly filterName: "Chromatic Prism Tracer";
    readonly category: "Advanced";
    readonly description: "Trace separate red, green, and blue rays through a virtual triangular prism";
}, {
    readonly displayName: "Portal Hall";
    readonly filterName: "Portal Hall";
    readonly category: "Advanced";
    readonly description: "Travel through a source-textured corridor of twisting, scale-changing portals";
}, {
    readonly displayName: "Image Fossil";
    readonly filterName: "Image Fossil";
    readonly category: "Advanced";
    readonly description: "Compress source structure into cracked sediment, mineral veins, and fossil relief";
}, {
    readonly displayName: "Volumetric Cloud Sculpture";
    readonly filterName: "Volumetric Cloud Sculpture";
    readonly category: "Advanced";
    readonly description: "Integrate source luminance and color into an animated three-dimensional cloud statue";
}, {
    readonly displayName: "Raymarched Maze";
    readonly filterName: "Raymarched Maze";
    readonly category: "Advanced";
    readonly description: "Navigate a connected procedural maze with source-textured walls and an exit beacon";
}, {
    readonly displayName: "Color gradient noise";
    readonly filterName: "Color Gradient Noise";
    readonly category: "Advanced";
    readonly description: "Perlin noise mapped to a two-color gradient, blended with the input image";
}, {
    readonly displayName: "Displacement map XY";
    readonly filterName: "Displacement Map XY";
    readonly category: "Advanced";
    readonly description: "Use separate R/G channels as X/Y displacement maps for organic warping";
}, {
    readonly displayName: "Flow field";
    readonly filterName: "Flow Field";
    readonly category: "Advanced";
    readonly description: "Displace pixels along curl noise streamlines for organic swirling patterns";
}, {
    readonly displayName: "Frequency Filter";
    readonly filterName: "Frequency Filter";
    readonly category: "Advanced";
    readonly description: "Approximate low, high, or band-pass image frequencies in the spatial domain";
}, {
    readonly displayName: "FFT Bandpass";
    readonly filterName: "FFT Bandpass";
    readonly category: "Advanced";
    readonly description: "Real 2D FFT low/high/band-pass — radial frequency mask, not a blur proxy";
}, {
    readonly displayName: "FFT Phase Scramble";
    readonly filterName: "FFT Phase Scramble";
    readonly category: "Advanced";
    readonly description: "Randomise 2D FFT phase while keeping magnitude — same spectral energy, scrambled geometry";
}, {
    readonly displayName: "FFT Radial Notch";
    readonly filterName: "FFT Radial Notch";
    readonly category: "Advanced";
    readonly description: "Zero out a circular ring in the 2D FFT — kills periodic patterns (scan lines, dot screens, weaves)";
}, {
    readonly displayName: "FFT Spectral Gate";
    readonly filterName: "FFT Spectral Gate";
    readonly category: "Advanced";
    readonly description: "Keep only frequency bins above a magnitude threshold — frequency-domain denoise that preserves dominant structure";
}, {
    readonly displayName: "FFT Magnitude Plot";
    readonly filterName: "FFT Magnitude Plot";
    readonly category: "Advanced";
    readonly description: "Log-magnitude visualisation of the 2D FFT — DC centred, false-colour";
}, {
    readonly displayName: "FFT Phase Plot";
    readonly filterName: "FFT Phase Plot";
    readonly category: "Advanced";
    readonly description: "Hue-mapped phase of the 2D FFT";
}, {
    readonly displayName: "FFT Butterfly Plot";
    readonly filterName: "FFT Butterfly Plot";
    readonly category: "Advanced";
    readonly description: "Render the FFT at any intermediate pipeline stage — watch the spatial image crystallise into its Fourier representation";
}, {
    readonly displayName: "FFT Dephase";
    readonly filterName: "FFT Dephase";
    readonly category: "Advanced";
    readonly description: "Zero the FFT phase, keep magnitude — inverse transform becomes the image's autocorrelation (symmetric feature halo)";
}, {
    readonly displayName: "FFT Angular Wedge";
    readonly filterName: "FFT Angular Wedge";
    readonly category: "Advanced";
    readonly description: "Keep or kill FFT bins within a wedge of angles — isolates or removes directional patterns (horizontal lines, diagonal weaves, etc.)";
}, {
    readonly displayName: "FFT Component Plot";
    readonly filterName: "FFT Component Plot";
    readonly category: "Advanced";
    readonly description: "Diverging-colormap plot of the FFT's real or imaginary component — reveals even/odd symmetry in the source";
}, {
    readonly displayName: "FFT Phase Only";
    readonly filterName: "FFT Phase Only";
    readonly category: "Advanced";
    readonly description: "Keep FFT phase, replace all magnitudes with a constant — classic demo that phase carries structure";
}, {
    readonly displayName: "FFT Homomorphic";
    readonly filterName: "FFT Homomorphic";
    readonly category: "Advanced";
    readonly description: "Flatten uneven illumination while boosting local contrast — log(image) → FFT → high-freq emphasis → IFFT → exp";
}, {
    readonly displayName: "FFT Radial Profile";
    readonly filterName: "FFT Radial Profile";
    readonly category: "Advanced";
    readonly description: "1D graph of angular-averaged power spectrum vs spatial frequency — natural images show 1/f slope";
}, {
    readonly displayName: "FFT Cepstrum";
    readonly filterName: "FFT Cepstrum";
    readonly category: "Advanced";
    readonly description: "Cepstrum = IFFT(log |FFT|). Repeating patterns / echoes show up as bright points at their spatial period";
}, {
    readonly displayName: "FFT Log-Polar";
    readonly filterName: "FFT Log-Polar";
    readonly category: "Advanced";
    readonly description: "Log-polar remap of the FFT magnitude — rotation/scale invariance up to translation";
}, {
    readonly displayName: "FFT Polar Heatmap";
    readonly filterName: "FFT Polar Heatmap";
    readonly category: "Advanced";
    readonly description: "FFT magnitude on a polar disc — directional streaks become spokes, periodic patterns become rings";
}, {
    readonly displayName: "FFT Deconvolve";
    readonly filterName: "FFT Deconvolve";
    readonly category: "Advanced";
    readonly description: "Wiener deconvolution against a built-in Gaussian or motion-blur kernel — undoes blur";
}, {
    readonly displayName: "Fractal";
    readonly filterName: "Fractal";
    readonly category: "Advanced";
    readonly description: "Render Mandelbrot or Julia set fractals, optionally colored from the input image";
}, {
    readonly displayName: "Noise generator";
    readonly filterName: "Noise Generator";
    readonly category: "Advanced";
    readonly description: "Procedural noise patterns — Perlin, Simplex, or Worley — mixable with the input";
}, {
    readonly displayName: "Motion Vectors";
    readonly filterName: "Motion Vectors";
    readonly category: "Advanced";
    readonly description: "Estimate local motion between frames and render stable arrows, trails, or heat overlays for debugging and stylized analysis";
}, {
    readonly displayName: "Program";
    readonly filterName: "Program";
    readonly category: "Advanced";
    readonly description: "Write custom pixel-manipulation code in a built-in editor";
}];
