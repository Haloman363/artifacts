type GLCanvas = HTMLCanvasElement | OffscreenCanvas;
export type GLCtx = {
    gl: WebGL2RenderingContext;
    canvas: GLCanvas;
};
export declare const getGLCtx: () => GLCtx | null;
export declare const getExistingGLCtx: () => GLCtx | null;
export declare const glAvailable: () => boolean;
export declare const glUnavailableStub: (w: number, h: number) => GLCanvas;
export type GLStats = {
    programs: number;
    textures: number;
    framebuffers: number;
    readoutCanvases: number;
    readoutCanvasReuses: number;
};
export declare const getGLStats: () => Readonly<GLStats>;
export declare const resetGLStats: () => void;
export declare const getGLPoolSizes: () => {
    texPool: number;
    canvasPool: number;
};
export declare const STD_VS = "#version 300 es\nin vec2 a_pos;\nout vec2 v_uv;\nvoid main() {\n  v_uv = a_pos * 0.5 + 0.5;\n  gl_Position = vec4(a_pos, 0.0, 1.0);\n}\n";
export declare const READ_CLAMPED = "\nvec4 readClamped(sampler2D s, vec2 px, vec2 res) {\n  vec2 cp = clamp(px, vec2(0.0), res - vec2(1.0));\n  return texture(s, vec2(cp.x + 0.5, res.y - 0.5 - cp.y) / res);\n}\n";
export type Program = {
    prog: WebGLProgram;
    uniforms: Record<string, WebGLUniformLocation | null>;
};
export declare const linkProgram: (gl: WebGL2RenderingContext, fsSrc: string, uniformNames: readonly string[]) => Program;
export declare const createQuadVAO: (gl: WebGL2RenderingContext) => WebGLVertexArrayObject;
export declare const getQuadVAO: (gl: WebGL2RenderingContext) => WebGLVertexArrayObject;
export type TexEntry = {
    tex: WebGLTexture;
    fbo: WebGLFramebuffer;
    w: number;
    h: number;
};
export declare const ensureTexture: (gl: WebGL2RenderingContext, name: string, w: number, h: number) => TexEntry;
export declare const ensureFloatTexture: (gl: WebGL2RenderingContext, name: string, w: number, h: number) => TexEntry | null;
export declare const uploadFloatTexture: (gl: WebGL2RenderingContext, entry: TexEntry, width: number, height: number, data: Float32Array) => void;
export declare const releasePooledTextures: (prefix?: string) => number;
export declare const getTexPoolKeys: () => string[];
export declare const uploadSourceTexture: (gl: WebGL2RenderingContext, entry: TexEntry, source: HTMLCanvasElement | OffscreenCanvas | ImageBitmap | ImageData) => void;
export declare const drawPass: (gl: WebGL2RenderingContext, target: TexEntry | null, w: number, h: number, prog: Program, setUniforms: () => void, vao: WebGLVertexArrayObject) => void;
export declare const readoutToCanvas: (glCanvas: GLCanvas, w: number, h: number) => GLCanvas | null;
export declare const resizeGLCanvas: (canvas: GLCanvas, w: number, h: number) => void;
export {};
