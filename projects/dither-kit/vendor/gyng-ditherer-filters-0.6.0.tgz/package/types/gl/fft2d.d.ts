import { linkProgram, type Program, type TexEntry } from "./index";
export declare const nextPow2: (n: number) => number;
export declare const log2Int: (n: number) => number;
type FFTCache = {
    extract: Program;
    bitrev: Program;
    butterfly: Program;
    finalise: Program;
};
type ProgramLinker = typeof linkProgram;
export declare const createFFTProgramCache: (gl: WebGL2RenderingContext, linker?: ProgramLinker) => FFTCache;
type FloatEntry = {
    tex: WebGLTexture;
    fbo: WebGLFramebuffer;
    w: number;
    h: number;
};
export declare const ensureFloatTex: (gl: WebGL2RenderingContext, name: string, w: number, h: number) => FloatEntry | null;
export declare const releaseFloatTextures: (prefix?: string) => number;
export declare const getFloatPoolKeys: () => string[];
export declare const fft2dAvailable: () => boolean;
export type FFTResult = {
    /** Texture containing the padded frequency-domain data (RG=complex). */
    tex: WebGLTexture;
    fbo: WebGLFramebuffer;
    /** Padded width/height (power of 2). */
    paddedW: number;
    paddedH: number;
    /** Original (pre-padding) width/height. */
    srcW: number;
    srcH: number;
    /** log2 of the padded dims. */
    logW: number;
    logH: number;
};
export declare const forwardFFT2D: (gl: WebGL2RenderingContext, sourceTex: TexEntry, srcW: number, srcH: number) => FFTResult | null;
export declare const inverseFFT2D: (gl: WebGL2RenderingContext, input: {
    tex: WebGLTexture;
    fbo: WebGLFramebuffer;
}, paddedW: number, paddedH: number, logW: number, logH: number) => FloatEntry | null;
export declare const forwardFFT2DFromExtract: (gl: WebGL2RenderingContext, extracted: {
    tex: WebGLTexture;
    fbo: WebGLFramebuffer;
}, paddedW: number, paddedH: number) => FloatEntry | null;
export declare const forwardFFT2DToStage: (gl: WebGL2RenderingContext, sourceTex: TexEntry, srcW: number, srcH: number, stopStage: number) => FFTResult | null;
export declare const fft2dStageCount: (paddedW: number, paddedH: number) => number;
export declare const finaliseIFFT: (gl: WebGL2RenderingContext, ifftResult: FloatEntry, sourceTex: TexEntry, srcW: number, srcH: number, paddedW: number, paddedH: number, targetCanvasW: number, targetCanvasH: number) => void;
export {};
