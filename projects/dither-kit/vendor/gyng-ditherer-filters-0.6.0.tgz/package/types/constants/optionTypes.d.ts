export declare const PALETTE = "PALETTE";
export declare const UNKNOWN = "UNKNOWN";
export declare const SCALING_ALGORITHM: {
    AUTO: string;
    PIXELATED: string;
};
