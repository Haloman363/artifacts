export declare const ACTION = "ACTION";
export declare const BOOL = "BOOL";
export declare const ENUM = "ENUM";
export declare const RANGE = "RANGE";
export declare const STRING = "STRING";
export declare const TEXT = "TEXT";
export declare const PALETTE = "PALETTE";
export declare const COLOR = "COLOR";
export declare const COLOR_ARRAY = "COLOR_ARRAY";
export declare const CURVE = "CURVE";
export declare const THRESHOLD_MAP_PREVIEW = "THRESHOLD_MAP_PREVIEW";
export declare const COLOR_DISTANCE_ALGORITHM: {
    type: string;
    options: {
        name: string;
        value: string;
    }[];
    default: string;
};
export declare const SCALING_ALGORITHM_OPTIONS: {
    type: string;
    options: {
        name: string;
        value: string;
    }[];
    default: string;
};
