export declare const RGB_NEAREST = "RGB";
export declare const RGB_APPROX = "RGB_APPROX";
export declare const HSV_NEAREST = "HSV";
export declare const LAB_NEAREST = "LAB";
export declare const OKLAB_NEAREST = "OKLAB";
